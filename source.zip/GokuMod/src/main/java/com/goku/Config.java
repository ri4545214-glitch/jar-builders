package com.goku;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/** JSON settings storage (settings only, module on/off states are never restored). */
public final class Config {
    static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    static final Map<String, Object[]> DEFAULTS = new HashMap<>();

    static Path dir() { return FabricLoader.getInstance().getConfigDir().resolve("gokumod"); }

    static void captureDefaults() {
        if (!DEFAULTS.isEmpty()) return;
        for (Module m : Modules.EVERY) for (Setting s : m.settings) DEFAULTS.put(m.name + "/" + s.name, new Object[]{s.b, s.v, s.idx});
    }

    static JsonObject dump() {
        JsonObject root = new JsonObject();
        for (Module m : Modules.EVERY) {
            if (m == Modules.CONFIG) continue;
            JsonObject o = new JsonObject();
            for (Setting s : m.settings) {
                switch (s.type) {
                    case BOOL -> o.addProperty(s.name, s.b);
                    case NUM -> o.addProperty(s.name, s.v);
                    case MODE -> o.addProperty(s.name, s.idx);
                }
            }
            root.add(m.name, o);
        }
        return root;
    }

    public static boolean save(String profile) {
        try {
            Files.createDirectories(dir());
            String json = GSON.toJson(dump());
            Files.writeString(dir().resolve(profile + ".json"), json);
            if (!profile.equals("default")) Files.writeString(dir().resolve("default.json"), json);   // last saved = startup config
            return true;
        } catch (Exception e) { return false; }
    }

    public static boolean load(String profile) {
        try {
            Path f = dir().resolve(profile + ".json");
            if (!Files.exists(f)) return false;
            JsonObject root = GSON.fromJson(Files.readString(f), JsonObject.class);
            for (Module m : Modules.EVERY) {
                if (m == Modules.CONFIG || !root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                for (Setting s : m.settings) {
                    if (!o.has(s.name)) continue;
                    switch (s.type) {
                        case BOOL -> s.b = o.get(s.name).getAsBoolean();
                        case NUM -> s.v = Math.max(s.min, Math.min(s.max, o.get(s.name).getAsDouble()));
                        case MODE -> s.idx = Math.max(0, Math.min(s.modes.length - 1, o.get(s.name).getAsInt()));
                    }
                    s.anim = -1;
                }
            }
            return true;
        } catch (Exception e) { return false; }
    }

    public static void reset() {
        for (Module m : Modules.EVERY) {
            if (m == Modules.CONFIG) continue;
            for (Setting s : m.settings) {
                Object[] d = DEFAULTS.get(m.name + "/" + s.name);
                if (d == null) continue;
                s.b = (boolean) d[0]; s.v = (double) d[1]; s.idx = (int) d[2]; s.anim = -1;
            }
        }
    }
}
