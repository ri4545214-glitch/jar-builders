package com.goku;

public class Setting {
    public enum Type { BOOL, NUM, MODE }
    public final String name;
    public final Type type;
    public boolean b;
    public double v, min, max, step;
    public String[] modes;
    public int idx;

    private Setting(String n, Type t) { name = n; type = t; }

    public static Setting bool(String n, boolean d) { Setting s = new Setting(n, Type.BOOL); s.b = d; return s; }
    public static Setting num(String n, double d, double min, double max, double step) {
        Setting s = new Setting(n, Type.NUM); s.v = d; s.min = min; s.max = max; s.step = step; return s;
    }
    public static Setting mode(String n, int idx, String... m) {
        Setting s = new Setting(n, Type.MODE); s.idx = idx; s.modes = m; return s;
    }
    public String modeName() { return modes[idx]; }
    public void cycle() { idx = (idx + 1) % modes.length; }
    public int i() { return (int) Math.round(v); }
}
