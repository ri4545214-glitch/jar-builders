package com.goku;

public class Setting {
    public enum Type { BOOL, NUM, MODE, COLOR }
    public final String name;
    public final Type type;
    public boolean b;
    public double v, min, max, step;
    public String[] modes;
    public int idx;
    public float anim = -1; // GUI animation state
    /** COLOR settings: the 0xRRGGBB value lives in idx, hue/saturation/brightness (0..1) are the colour wheel state. */
    public float fh, fs, fv = 1;

    private Setting(String n, Type t) { name = n; type = t; }

    public static Setting bool(String n, boolean d) { Setting s = new Setting(n, Type.BOOL); s.b = d; return s; }
    public static Setting num(String n, double d, double min, double max, double step) {
        Setting s = new Setting(n, Type.NUM); s.v = d; s.min = min; s.max = max; s.step = step; return s;
    }
    public static Setting mode(String n, int idx, String... m) {
        Setting s = new Setting(n, Type.MODE); s.idx = idx; s.modes = m; return s;
    }
    public String modeName() { return modes[idx]; }
    public void cycle() { idx = (idx + 1) % modes.length; }
    public int i() { return (int) Math.round(v); }

    public static Setting color(String n, int rgb) { Setting s = new Setting(n, Type.COLOR); s.setRgb(rgb); return s; }
    public int rgb() { return idx & 0xFFFFFF; }
    public void setRgb(int rgb) { idx = rgb & 0xFFFFFF; syncHsv(); }
    public void setHsv(float h, float sat, float v) { fh = h; fs = sat; fv = v; idx = com.goku.util.Draw.hsv(h, sat, v) & 0xFFFFFF; }
    public void syncHsv() {
        float r = ((idx >> 16) & 255) / 255f, g = ((idx >> 8) & 255) / 255f, b = (idx & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min, h = 0;
        if (d > 1e-6f) {
            if (max == r) h = ((g - b) / d) % 6f; else if (max == g) h = (b - r) / d + 2f; else h = (r - g) / d + 4f;
            h /= 6f; if (h < 0) h += 1f;
        }
        fh = h; fs = max <= 0 ? 0 : d / max; fv = max;
    }
}
