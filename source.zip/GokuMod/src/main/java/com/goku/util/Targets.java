package com.goku.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class Targets {
    public static boolean valid(MinecraftClient mc, Entity e, double range, boolean players, boolean mobs, boolean walls) {
        if (!(e instanceof LivingEntity le) || e == mc.player || e == mc.getCameraEntity()) return false;
        if (!le.isAlive() || le.isSpectator() || le instanceof ArmorStandEntity) return false;
        boolean isP = e instanceof PlayerEntity;
        if (isP && !players) return false;
        if (!isP && (!mobs || !(e instanceof MobEntity))) return false;
        if (mc.player.distanceTo(e) > range) return false;
        return walls || mc.player.canSee(e);
    }

    public static List<LivingEntity> find(MinecraftClient mc, double range, boolean players, boolean mobs, boolean walls) {
        List<LivingEntity> out = new ArrayList<>();
        for (Entity e : mc.world.getEntities())
            if (valid(mc, e, range, players, mobs, walls)) out.add((LivingEntity) e);
        out.sort(Comparator.comparingDouble(mc.player::distanceTo));
        return out;
    }

    public static float[] rot(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        return new float[]{yaw, pitch};
    }

    public static float wrap(float a) { a %= 360f; if (a >= 180f) a -= 360f; if (a < -180f) a += 360f; return a; }
}
