package com.goku.util;

import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FallingBlock;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Shared respawn-anchor logic: air placing, charging, shield block, detonation. */
public final class AnchorOps {
    static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    public static BlockHitResult hit(BlockPos p) { return new BlockHitResult(Vec3d.ofCenter(p), Direction.UP, p, false); }

    /** Click the block position itself: for replaceable (air) positions the block is placed right there ("air place"). */
    public static void click(BlockPos p) {
        var mc = mc();
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit(p));
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    public static boolean canAirPlace(BlockPos p) {
        var mc = mc();
        if (!mc.world.getBlockState(p).isReplaceable()) return false;
        for (Entity e : mc.world.getOtherEntities(null, new Box(p)))
            if (!e.isSpectator() && e.isAlive()) return false;
        return true;
    }

    /** One macro run on a single anchor. step() returns false when the run is over. */
    public static final class Run {
        public BlockPos anchor;
        public int cd;
        int prevSlot = -1;
        boolean shielded;

        public void start(BlockPos p) { anchor = p; cd = 0; prevSlot = -1; shielded = false; }
        public void finish(boolean swapBack) {
            if (prevSlot >= 0 && swapBack) Inv.select(prevSlot);
            prevSlot = -1; anchor = null; shielded = false;
        }

        public boolean step(int charges, int chargeDelay, int explodeDelay, boolean totemOnly, boolean shield, double range, double minHp) {
            var mc = mc();
            if (cd > 0) { cd--; return true; }
            BlockState st = mc.world.getBlockState(anchor);
            if (!st.isOf(Blocks.RESPAWN_ANCHOR) || mc.player.getEyePos().distanceTo(Vec3d.ofCenter(anchor)) > range) return false;
            if (prevSlot < 0) prevSlot = Inv.selected();
            if (st.get(RespawnAnchorBlock.CHARGES) < charges) {
                int g = Inv.hotbar(s -> s.isOf(Items.GLOWSTONE));
                if (g < 0) return true;
                Inv.select(g); click(anchor); cd = chargeDelay;
                return true;
            }
            if (shield && !shielded) {
                shielded = true;
                BlockPos sp = shieldPos();
                if (sp != null) {
                    int b = Inv.hotbar(s -> s.isOf(Items.OBSIDIAN));
                    if (b < 0) b = Inv.hotbar(s -> s.getItem() instanceof BlockItem bi && !(bi.getBlock() instanceof FallingBlock)
                            && !(bi.getBlock() instanceof BlockEntityProvider) && !s.isOf(Items.GLOWSTONE) && !s.isOf(Items.RESPAWN_ANCHOR));
                    if (b >= 0) { Inv.select(b); click(sp); cd = 1; return true; }
                }
            }
            if (mc.player.getHealth() + mc.player.getAbsorptionAmount() <= minHp) return false;
            int e = Inv.hotbar(s -> totemOnly ? s.isOf(Items.TOTEM_OF_UNDYING) : (!s.isOf(Items.GLOWSTONE) && !s.isOf(Items.RESPAWN_ANCHOR)));
            if (e < 0) return true;
            Inv.select(e); click(anchor); cd = explodeDelay;
            return true;
        }

        /** The block next to the anchor on the side facing you: it soaks up the explosion. */
        BlockPos shieldPos() {
            var mc = mc();
            Vec3d v = mc.player.getEyePos().subtract(Vec3d.ofCenter(anchor));
            Direction[] order = new Direction[3];
            double[] a = {Math.abs(v.x), Math.abs(v.y), Math.abs(v.z)};
            Direction dx = v.x >= 0 ? Direction.EAST : Direction.WEST, dy = v.y >= 0 ? Direction.UP : Direction.DOWN, dz = v.z >= 0 ? Direction.SOUTH : Direction.NORTH;
            Direction[] ds = {dx, dy, dz};
            Integer[] idx = {0, 1, 2};
            java.util.Arrays.sort(idx, (i, j) -> Double.compare(a[j], a[i]));
            for (int i : idx) {
                BlockPos p = anchor.offset(ds[i]);
                BlockPos feet = mc.player.getBlockPos();
                if (p.equals(feet) || p.equals(feet.up())) continue;
                if (canAirPlace(p)) return p;
            }
            return null;
        }
    }
}
