package com.goku.util;

import com.goku.Module;
import com.goku.Modules;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Online Guard: the cheat modules (combat, movement, automation) only run in singleplayer, on LAN/localhost, or on servers you listed in
 * config/gokumod/allowed-servers.txt (one address per line, # = comment). Everywhere else they are switched off and refuse to turn on.
 */
public final class Guard {
    static List<String> list = new ArrayList<>();
    static long loaded;

    static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("gokumod").resolve("allowed-servers.txt"); }

    static void reload() {
        long now = System.currentTimeMillis();
        if (now - loaded < 3000) return;
        loaded = now;
        List<String> l = new ArrayList<>();
        try {
            Path f = file();
            if (!Files.exists(f)) {
                Files.createDirectories(f.getParent());
                Files.writeString(f, "# Servers where Goku's cheat modules may run (one address per line).\n# Singleplayer, LAN, localhost and 127.0.0.1 are always allowed.\n# Example:\n# play.myownserver.net\n");
            }
            for (String line : Files.readAllLines(f)) {
                line = line.trim().toLowerCase();
                if (!line.isEmpty() && !line.startsWith("#")) l.add(stripPort(line));
            }
        } catch (Exception ignored) {}
        list = l;
    }

    static String stripPort(String a) {
        if (a.startsWith("[")) return a;                    // IPv6 literal, leave as is
        int i = a.lastIndexOf(':');
        return i > 0 && a.indexOf(':') == i ? a.substring(0, i) : a;
    }

    static boolean local(String a) {
        return a.equals("localhost") || a.equals("127.0.0.1") || a.equals("[::1]") || a.startsWith("192.168.") || a.startsWith("10.") || a.endsWith(".local");
    }

    /** True when cheat modules may run in the current world. */
    public static boolean allowed() {
        var mc = MinecraftClient.getInstance();
        if (mc.isInSingleplayer()) return true;
        ServerInfo si = mc.getCurrentServerEntry();
        if (si == null) return mc.world == null;            // no world yet: nothing to block
        String a = stripPort(si.address.trim().toLowerCase());
        if (local(a)) return true;
        reload();
        for (String s : list) if (a.equals(s) || a.endsWith("." + s)) return true;
        return false;
    }

    /** Appends the current server address to allowed-servers.txt. Returns the address, or null if there is nothing to add. */
    public static String allowCurrent() {
        var mc = MinecraftClient.getInstance();
        ServerInfo si = mc.getCurrentServerEntry();
        if (si == null || mc.isInSingleplayer()) return null;
        String a = stripPort(si.address.trim().toLowerCase());
        try {
            reload();
            if (!list.contains(a)) Files.writeString(file(), "\n" + a + "\n", java.nio.file.StandardOpenOption.APPEND);
            loaded = 0;
            reload();
            return a;
        } catch (Exception e) { return null; }
    }

    public static boolean blocks(Module m) {
        return Modules.CONFIG.guard.b && Modules.CHEAT.contains(m) && !allowed();
    }
}
