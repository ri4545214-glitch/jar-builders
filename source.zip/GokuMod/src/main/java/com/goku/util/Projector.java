package com.goku.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** World -> HUD-space projection (no render-pipeline hooks, so ESP works through walls). */
public final class Projector {
    public static Vec3d cam = Vec3d.ZERO;
    static double fx, fy, fz, rx, ry, rz, ux, uy, uz, tan;
    static int W, H;
    public static boolean ok;

    public static void update(MinecraftClient mc, float td) {
        Entity e = mc.getCameraEntity();
        if (e == null) { ok = false; return; }
        cam = e.getCameraPosVec(td);
        double yaw = Math.toRadians(e.getYaw(td)), pitch = Math.toRadians(e.getPitch(td));
        fx = -Math.sin(yaw) * Math.cos(pitch); fy = -Math.sin(pitch); fz = Math.cos(yaw) * Math.cos(pitch);
        rx = -Math.cos(yaw); ry = 0; rz = -Math.sin(yaw);
        ux = ry * fz - rz * fy; uy = rz * fx - rx * fz; uz = rx * fy - ry * fx;
        tan = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        W = mc.getWindow().getScaledWidth();
        H = mc.getWindow().getScaledHeight();
        ok = true;
    }

    public static double[] to(Vec3d p) {
        double dx = p.x - cam.x, dy = p.y - cam.y, dz = p.z - cam.z;
        double z = dx * fx + dy * fy + dz * fz;
        if (z < 0.05) return null;
        double x = dx * rx + dy * ry + dz * rz;
        double y = dx * ux + dy * uy + dz * uz;
        double aspect = (double) W / H;
        return new double[]{ W / 2.0 + x / (z * tan * aspect) * W / 2.0, H / 2.0 - y / (z * tan) * H / 2.0, z };
    }

    /** 2D bounding rect {minX,minY,maxX,maxY} of a box, or null if any corner is behind the camera. */
    public static int[] box(Box b) {
        double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
        for (int i = 0; i < 8; i++) {
            Vec3d c = new Vec3d((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ);
            double[] s = to(c);
            if (s == null) return null;
            minX = Math.min(minX, s[0]); maxX = Math.max(maxX, s[0]);
            minY = Math.min(minY, s[1]); maxY = Math.max(maxY, s[1]);
        }
        if (maxX < 0 || maxY < 0 || minX > W || minY > H) return null;
        if (maxX - minX < 3) maxX = minX + 3;
        if (maxY - minY < 3) maxY = minY + 3;
        return new int[]{ (int) minX, (int) minY, (int) maxX, (int) maxY };
    }
}
