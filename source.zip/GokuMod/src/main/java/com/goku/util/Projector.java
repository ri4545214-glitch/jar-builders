package com.goku.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** World -> HUD-space projection (no render-pipeline hooks, so ESP works through walls). */
public final class Projector {
    public static Vec3d cam = Vec3d.ZERO;
    static double fx, fy, fz, rx, ry, rz, ux, uy, uz, tan;
    public static int W, H;
    public static boolean ok;

    public static void update(MinecraftClient mc, float td) {
        Entity e = mc.getCameraEntity();
        if (e == null) { ok = false; return; }
        cam = e.getCameraPosVec(td);
        double yaw = Math.toRadians(e.getYaw(td)), pitch = Math.toRadians(e.getPitch(td));
        fx = -Math.sin(yaw) * Math.cos(pitch); fy = -Math.sin(pitch); fz = Math.cos(yaw) * Math.cos(pitch);
        rx = -Math.cos(yaw); ry = 0; rz = -Math.sin(yaw);
        ux = ry * fz - rz * fy; uy = rz * fx - rx * fz; uz = rx * fy - ry * fx;
        tan = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        W = mc.getWindow().getScaledWidth();
        H = mc.getWindow().getScaledHeight();
        ok = true;
    }

    public static double[] to(Vec3d p) {
        double dx = p.x - cam.x, dy = p.y - cam.y, dz = p.z - cam.z;
        double z = dx * fx + dy * fy + dz * fz;
        if (z < 0.01) return null;
        double x = dx * rx + dy * ry + dz * rz;
        double y = dx * ux + dy * uy + dz * uz;
        double aspect = (double) W / H;
        return new double[]{ W / 2.0 + x / (z * tan * aspect) * W / 2.0, H / 2.0 - y / (z * tan) * H / 2.0, z };
    }

    public static double depth(Vec3d p) { return (p.x - cam.x) * fx + (p.y - cam.y) * fy + (p.z - cam.z) * fz; }

    /** Projects a 3D segment, clipped against the near plane. Returns {x1,y1,x2,y2} or null. */
    public static double[] clipLine(Vec3d a, Vec3d b) {
        double za = depth(a), zb = depth(b);
        if (za < 0.05 && zb < 0.05) return null;
        if (za < 0.05) a = a.lerp(b, (0.05 - za) / (zb - za));
        else if (zb < 0.05) b = b.lerp(a, (0.05 - zb) / (za - zb));
        double[] p = to(a), q = to(b);
        if (p == null || q == null) return null;
        return new double[]{ p[0], p[1], q[0], q[1] };
    }

    /** Like to(), but points behind the camera are pushed to the screen edge (for tracers). */
    public static double[] toEdge(Vec3d p) {
        double[] s = to(p);
        if (s != null) return s;
        double dx = p.x - cam.x, dy = p.y - cam.y, dz = p.z - cam.z;
        double x = dx * rx + dy * ry + dz * rz, y = dx * ux + dy * uy + dz * uz;
        double len = Math.hypot(x, y);
        if (len < 1e-6) { x = 0; y = -1; len = 1; }
        double k = Math.max(W, H);
        return new double[]{ W / 2.0 + x / len * k, H / 2.0 - y / len * k, 0 };
    }

    /** 2D bounding rect {minX,minY,maxX,maxY} of a box, or null if any corner is behind the camera. */
    public static int[] box(Box b) {
        double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
        for (int i = 0; i < 8; i++) {
            Vec3d c = new Vec3d((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ);
            double[] s = to(c);
            if (s == null) return null;
            minX = Math.min(minX, s[0]); maxX = Math.max(maxX, s[0]);
            minY = Math.min(minY, s[1]); maxY = Math.max(maxY, s[1]);
        }
        if (maxX < 0 || maxY < 0 || minX > W || minY > H) return null;
        if (maxX - minX < 3) maxX = minX + 3;
        if (maxY - minY < 3) maxY = minY + 3;
        return new int[]{ (int) minX, (int) minY, (int) maxX, (int) maxY };
    }
}
