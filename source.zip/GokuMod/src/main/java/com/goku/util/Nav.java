package com.goku.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Tiny walker: turns the player toward a point and holds the movement keys. */
public final class Nav {
    static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    public static void turnTo(Vec3d to, float maxStep, boolean pitchToo) {
        ClientPlayerEntity p = mc().player;
        float[] r = Targets.rot(p.getEyePos(), to);
        float dy = Targets.wrap(r[0] - p.getYaw());
        p.setYaw(p.getYaw() + Math.max(-maxStep, Math.min(maxStep, dy)));
        if (pitchToo) {
            float dp = r[1] - p.getPitch();
            p.setPitch(Math.max(-90f, Math.min(90f, p.getPitch() + Math.max(-maxStep, Math.min(maxStep, dp)))));
        }
    }

    /** Walk toward 'to'. Returns the horizontal distance left. */
    public static double walk(Vec3d to, boolean sprint, boolean jump, float turnStep) {
        var mc = mc(); ClientPlayerEntity p = mc.player;
        turnTo(new Vec3d(to.x, p.getEyeY(), to.z), turnStep, false);
        mc.options.forwardKey.setPressed(true);
        mc.options.sprintKey.setPressed(sprint);
        mc.options.jumpKey.setPressed(jump && ((p.horizontalCollision && p.isOnGround()) || p.isTouchingWater() || p.isInLava()));
        return Math.hypot(to.x - p.getX(), to.z - p.getZ());
    }

    public static void release() {
        var o = mc().options;
        o.forwardKey.setPressed(false); o.sprintKey.setPressed(false); o.jumpKey.setPressed(false);
    }
}
