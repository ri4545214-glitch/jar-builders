package com.goku.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class Draw {
    public static final int[] COLORS = {0xFFFF4444, 0xFF44FF44, 0xFF4488FF, 0xFFFFEE44, 0xFF44FFFF, 0xFFBB55FF, 0xFFFFFFFF, 0xFFFF9933};
    public static final String[] NAMES = {"Red", "Green", "Blue", "Yellow", "Cyan", "Purple", "White", "Orange"};

    public static void outline(DrawContext c, int x1, int y1, int x2, int y2, int col) {
        c.fill(x1, y1, x2, y1 + 1, col);
        c.fill(x1, y2 - 1, x2, y2, col);
        c.fill(x1, y1, x1 + 1, y2, col);
        c.fill(x2 - 1, y1, x2, y2, col);
    }

    public static void text(DrawContext c, String s, int cx, int y, int col) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        c.drawText(tr, s, cx - tr.getWidth(s) / 2, y, col, true);
    }
}
