package com.goku.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class Draw {
    public static final int[] COLORS = {0xFFFF4444, 0xFF44FF44, 0xFF4488FF, 0xFFFFEE44, 0xFF44FFFF, 0xFFBB55FF, 0xFFFFFFFF, 0xFFFF9933};
    public static final String[] NAMES = {"Red", "Green", "Blue", "Yellow", "Cyan", "Purple", "White", "Orange"};

    public static int hsv(float hue) {
        hue -= (float) Math.floor(hue);
        float f6 = hue * 6, f = f6 - (int) f6, q = 1 - f, r, g, b;
        switch ((int) f6 % 6) {
            case 0 -> { r = 1; g = f; b = 0; }
            case 1 -> { r = q; g = 1; b = 0; }
            case 2 -> { r = 0; g = 1; b = f; }
            case 3 -> { r = 0; g = q; b = 1; }
            case 4 -> { r = f; g = 0; b = 1; }
            default -> { r = 1; g = 0; b = q; }
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    /** Hue/saturation/brightness (all 0..1) -> 0xRRGGBB. */
    public static int hsv(float hue, float sat, float val) {
        int c = hsv(hue);
        sat = Math.max(0f, Math.min(1f, sat)); val = Math.max(0f, Math.min(1f, val));
        int r = (int) ((((c >> 16) & 255) / 255f * sat + (1 - sat)) * val * 255);
        int g = (int) ((((c >> 8) & 255) / 255f * sat + (1 - sat)) * val * 255);
        int b = (int) (((c & 255) / 255f * sat + (1 - sat)) * val * 255);
        return (r << 16) | (g << 8) | b;
    }

    public static void outline(DrawContext c, int x1, int y1, int x2, int y2, int col) {
        c.fill(x1, y1, x2, y1 + 1, col);
        c.fill(x1, y2 - 1, x2, y2, col);
        c.fill(x1, y1, x1 + 1, y2, col);
        c.fill(x2 - 1, y1, x2, y2, col);
    }

    public static void text(DrawContext c, String s, int cx, int y, int col) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        c.drawText(tr, s, cx - tr.getWidth(s) / 2, y, col, true);
    }

    /** Anti-gap line of given pixel width, drawn as a rotated rect. */
    public static void line(DrawContext c, double x1, double y1, double x2, double y2, int w, int col) {
        double dx = x2 - x1, dy = y2 - y1, len = Math.sqrt(dx * dx + dy * dy);
        if (len < 1 || Double.isNaN(len) || len > 20000) return;
        int h = Math.max(1, w), top = -(h / 2);
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate((float) x1, (float) y1);
        m.rotate((float) Math.atan2(dy, dx));
        c.fill(0, top, (int) Math.ceil(len), top + h, col);
        m.popMatrix();
    }
}
