package com.goku.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class Draw {
    public static final int[] COLORS = {0xFFFF4444, 0xFF44FF44, 0xFF4488FF, 0xFFFFEE44, 0xFF44FFFF, 0xFFBB55FF, 0xFFFFFFFF, 0xFFFF9933};
    public static final String[] NAMES = {"Red", "Green", "Blue", "Yellow", "Cyan", "Purple", "White", "Orange"};

    public static void outline(DrawContext c, int x1, int y1, int x2, int y2, int col) {
        c.fill(x1, y1, x2, y1 + 1, col);
        c.fill(x1, y2 - 1, x2, y2, col);
        c.fill(x1, y1, x1 + 1, y2, col);
        c.fill(x2 - 1, y1, x2, y2, col);
    }

    public static void text(DrawContext c, String s, int cx, int y, int col) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        c.drawText(tr, s, cx - tr.getWidth(s) / 2, y, col, true);
    }

    /** Anti-gap line of given pixel width, drawn as a rotated rect. */
    public static void line(DrawContext c, double x1, double y1, double x2, double y2, int w, int col) {
        double dx = x2 - x1, dy = y2 - y1, len = Math.sqrt(dx * dx + dy * dy);
        if (len < 1 || Double.isNaN(len) || len > 20000) return;
        int h = Math.max(1, w), top = -(h / 2);
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate((float) x1, (float) y1);
        m.rotate((float) Math.atan2(dy, dx));
        c.fill(0, top, (int) Math.ceil(len), top + h, col);
        m.popMatrix();
    }
}
