package com.goku.util;

import com.goku.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;

import java.util.HashMap;
import java.util.Map;

/** GUI sounds + music player (assets/gokumod/sounds.json). Events are not registered, only looked up by id. */
public final class Sfx {
    static final String[] TRACKS = {"phonk", "aura"};
    static final Map<String, SoundEvent> EV = new HashMap<>();
    static final java.util.Random RND = new java.util.Random();
    static Loop loop;
    static int loopMode = -1, lastTrack = -1;
    /** Set by the ClickGui while it is open. */
    public static boolean guiOpen;

    static SoundEvent ev(String n) { return EV.computeIfAbsent(n, k -> SoundEvent.of(Identifier.of("gokumod", k))); }

    public static void play(String n, float pitch) {
        if (!Modules.SOUND.sfx.b) return;
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(ev(n), pitch, (float) (Modules.SOUND.sfxVol.v / 100.0)));
    }

    /** Called every client tick: starts/stops/switches the music so it can play with or without the GUI. */
    public static void tick() {
        var s = Modules.SOUND;
        var sm = MinecraftClient.getInstance().getSoundManager();
        boolean want = s.music.b && (guiOpen || s.keep.b);
        if (!want) { stopMusic(); return; }
        int mode = s.track.idx;                       // 0 phonk, 1 aura, 2 shuffle
        if (loop != null) {
            boolean ended = loop.shuffle && System.nanoTime() - loop.started > 3_000_000_000L && !sm.isPlaying(loop);
            if (ended || mode != loopMode) stopMusic();
        }
        if (loop == null) {
            int t = mode == 2 ? (lastTrack < 0 ? RND.nextInt(TRACKS.length) : (lastTrack + 1) % TRACKS.length) : mode;
            lastTrack = t; loopMode = mode;
            loop = new Loop(TRACKS[t], mode == 2);
            sm.play(loop);
        }
    }

    public static void stopMusic() {
        if (loop != null) { MinecraftClient.getInstance().getSoundManager().stop(loop); loop = null; }
        loopMode = -1;
    }

    static class Loop extends MovingSoundInstance {
        final boolean shuffle;
        final long started = System.nanoTime();
        Loop(String track, boolean shuffle) {
            super(ev(track), SoundCategory.MASTER, Random.create());
            this.shuffle = shuffle;
            this.repeat = !shuffle; this.repeatDelay = 0; this.relative = true;
            this.attenuationType = SoundInstance.AttenuationType.NONE;
            tick();
        }
        @Override public void tick() {
            this.volume = (float) (Modules.SOUND.musicVol.v / 100.0);
            this.pitch = (float) Modules.SOUND.musicPitch.v;
        }
    }
}
