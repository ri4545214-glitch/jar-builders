package com.goku.util;

import com.goku.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;

import java.util.HashMap;
import java.util.Map;

/** GUI sounds (assets/gokumod/sounds.json). Events are not registered, only looked up by id. */
public final class Sfx {
    static final Map<String, SoundEvent> EV = new HashMap<>();
    static Loop loop;

    static SoundEvent ev(String n) { return EV.computeIfAbsent(n, k -> SoundEvent.of(Identifier.of("gokumod", k))); }

    public static void play(String n, float pitch) {
        if (!Modules.SOUND.sfx.b) return;
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(ev(n), pitch, (float) (Modules.SOUND.sfxVol.v / 100.0)));
    }

    public static void startMusic() {
        if (!Modules.SOUND.music.b || loop != null) return;
        loop = new Loop();
        MinecraftClient.getInstance().getSoundManager().play(loop);
    }

    public static void stopMusic() {
        if (loop != null) { MinecraftClient.getInstance().getSoundManager().stop(loop); loop = null; }
    }

    static class Loop extends MovingSoundInstance {
        Loop() {
            super(ev("phonk"), SoundCategory.MASTER, Random.create());
            this.repeat = true; this.repeatDelay = 0; this.relative = true;
            this.attenuationType = SoundInstance.AttenuationType.NONE;
            tick();
        }
        @Override public void tick() {
            this.volume = (float) (Modules.SOUND.musicVol.v / 100.0);
            this.pitch = (float) Modules.SOUND.musicPitch.v;
        }
    }
}
