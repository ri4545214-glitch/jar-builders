package com.goku.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;

import java.util.function.Predicate;

public final class Inv {
    static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    /** First hotbar index (0-8) whose stack matches, or -1. */
    public static int hotbar(Predicate<ItemStack> f) {
        for (int i = 0; i < 9; i++) if (f.test(mc().player.getInventory().getStack(i))) return i;
        return -1;
    }
    public static int selected() { return mc().player.getInventory().getSelectedSlot(); }
    public static void select(int i) { if (i >= 0 && i < 9) mc().player.getInventory().setSelectedSlot(i); }
    /** Player inventory index (0-8 hotbar, 9-35 main) -> slot id in the player screen handler. */
    public static int containerSlot(int invIndex) { return invIndex < 9 ? 36 + invIndex : invIndex; }
}
