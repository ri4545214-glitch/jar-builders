package com.goku.util;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.List;

public final class Scan {
    /** All block entities in loaded chunks around the active camera (the freecam camera when it is on). */
    public static List<BlockEntity> blockEntities(MinecraftClient mc) {
        List<BlockEntity> out = new ArrayList<>();
        if (mc.world == null || mc.getCameraEntity() == null) return out;
        ChunkPos cp = mc.getCameraEntity().getChunkPos();
        int vd = mc.options.getViewDistance().getValue() + 2;
        for (int dx = -vd; dx <= vd; dx++) for (int dz = -vd; dz <= vd; dz++) {
            WorldChunk ch = mc.world.getChunkManager().getWorldChunk(cp.x + dx, cp.z + dz);
            if (ch != null) out.addAll(ch.getBlockEntities().values());
        }
        return out;
    }
}
