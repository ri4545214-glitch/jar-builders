package com.goku.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Shared ESP drawing: boxes (2D / 3D wire / corners), tracer lines, labels and a stacked HUD text column. */
public final class Esp {
    public static final String[] STYLES = {"2D Box", "3D Box", "Corners"};
    public static final String[] ORIGINS = {"Bottom", "Center"};
    public static int hudY = 4;

    public static int a(int col, int alpha) { return (Math.max(0, Math.min(255, alpha)) << 24) | (col & 0xFFFFFF); }

    /** Fades colour alpha with distance (255 near -> ~100 at max range). */
    public static int fade(int col, double dist, double max) {
        double t = Math.max(0, Math.min(1, dist / (max > 0 ? max : 200)));
        return a(col, (int) (255 - 155 * t));
    }

    public static void hud(DrawContext c, String s, int col) {
        c.drawText(MinecraftClient.getInstance().textRenderer, s, 4, hudY, col, true);
        hudY += 10;
    }

    public static void label(DrawContext c, String s, int cx, int y, int col) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        int w = tr.getWidth(s);
        c.fill(cx - w / 2 - 2, y - 1, cx + w / 2 + 2, y + 9, 0x99000000);
        c.fill(cx - w / 2 - 2, y + 9, cx + w / 2 + 2, y + 10, a(col, 0xFF));
        c.drawText(tr, s, cx - w / 2, y, 0xFFFFFFFF, false);
    }

    public static void box(DrawContext c, Box b, int col, int style, boolean fill, int w) {
        if (style == 1) {
            if (fill) { int[] r = Projector.box(b); if (r != null) c.fill(r[0], r[1], r[2], r[3], a(col, 0x28)); }
            Vec3d[] v = new Vec3d[8];
            for (int i = 0; i < 8; i++)
                v[i] = new Vec3d((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ);
            for (int i = 0; i < 8; i++) for (int bit = 1; bit <= 4; bit <<= 1) {
                if ((i & bit) != 0) continue;
                double[] l = Projector.clipLine(v[i], v[i | bit]);
                if (l != null) Draw.line(c, l[0], l[1], l[2], l[3], w, col);
            }
            return;
        }
        int[] r = Projector.box(b);
        if (r == null) return;
        if (fill) c.fill(r[0], r[1], r[2], r[3], a(col, 0x2A));
        if (style == 0) { Draw.outline(c, r[0], r[1], r[2], r[3], col); return; }
        int len = Math.max(2, Math.min(r[2] - r[0], r[3] - r[1]) / 3);
        for (int i = 0; i < 4; i++) {
            int x = (i & 1) == 0 ? r[0] : r[2], y = (i & 2) == 0 ? r[1] : r[3];
            int sx = (i & 1) == 0 ? 1 : -1, sy = (i & 2) == 0 ? 1 : -1;
            int hx = x + sx * len, vy = y + sy * len;
            c.fill(Math.min(x, hx), (i & 2) == 0 ? y : y - 1, Math.max(x, hx), (i & 2) == 0 ? y + 1 : y, col);
            c.fill((i & 1) == 0 ? x : x - 1, Math.min(y, vy), (i & 1) == 0 ? x + 1 : x, Math.max(y, vy), col);
        }
    }

    public static void tracer(DrawContext c, Vec3d target, int col, int origin, int w) {
        double[] t = Projector.toEdge(target);
        if (t == null) return;
        double ox = Projector.W / 2.0, oy = origin == 0 ? Projector.H : Projector.H / 2.0;
        Draw.line(c, ox, oy, t[0], t[1], w, col);
    }
}
