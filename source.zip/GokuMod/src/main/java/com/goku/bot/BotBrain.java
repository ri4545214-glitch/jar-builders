package com.goku.bot;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/** Server-side logic of the practice bot (a Mannequin entity). Runs on the integrated server thread, singleplayer only. */
public final class BotBrain {
    static BotModule module;
    static final Random RND = new Random();

    // requests from the client thread
    static volatile boolean wantSpawn, wantRemove, wantRekit;
    static volatile RegistryKey<World> reqKey;
    static volatile UUID reqPlayer;
    static volatile double reqX, reqY, reqZ;
    static volatile String reqCape;     // texture asset id of a cape (e.g. gokumod:dyn/cape_x) or null
    static boolean warnedCreative; static int creativeWarnCd;
    static double bvy, kx, kz, wx, wz;   // own physics: vertical speed, knockback, wanted walk

    // state (server thread)
    static UUID botId;
    static ServerWorld world;
    static RegistryKey<World> key;
    static UUID playerId;
    static int attackCd, potCd, smashCd, launchCd, crystalCd, jumpCd, strafeT, deadTicks, totemCd, potsLeft, totemsLeft;
    static int strafeDir = 1;
    static boolean wasAir;
    static double apex;
    static final List<double[]> pending = new ArrayList<>();      // {crystal id hash unused, ticksLeft, x, y, z}
    static final List<EndCrystalEntity> pendingEnt = new ArrayList<>();

    private static boolean registered;

    public static void init() {
        if (registered) return;
        registered = true;
        ServerTickEvents.START_SERVER_TICK.register(BotBrain::tick);
    }

    public static void requestSpawn(RegistryKey<World> k, UUID p, double x, double y, double z, String cape) {
        reqKey = k; reqPlayer = p; reqX = x; reqY = y; reqZ = z; reqCape = cape; wantSpawn = true;
    }

    /** One-line state for /gokubot status. Reads server state from the client thread (display only). */
    public static String status() {
        LivingEntity b = bot();
        if (b == null) return world == null ? "no bot yet" : "no live bot (dead or removed)";
        ServerPlayerEntity t = target();
        String d = t == null ? "?" : String.format("%.1f", Math.sqrt(t.squaredDistanceTo(b)));
        return String.format("alive, hp %.0f/%.0f, %s blocks away, totems left %d, pots left %d", b.getHealth(), b.getMaxHealth(), d, totemsLeft, potsLeft);
    }
    public static void requestRemove() { wantRemove = true; }
    public static void requestRekit() { wantRekit = true; }

    // ---- helpers
    static void cmd(MinecraftServer s, String c) {
        try { s.getCommandManager().getDispatcher().execute(c, s.getCommandSource().withSilent()); } catch (Exception ignored) {}
    }

    static void tell(String m) {
        if (world == null || playerId == null) return;
        for (ServerPlayerEntity p : world.getPlayers()) if (p.getUuid().equals(playerId)) p.sendMessage(Text.literal("[Goku] " + m), false);
    }

    static LivingEntity bot() {
        if (world == null || botId == null) return null;
        Entity e = world.getEntity(botId);
        return e instanceof LivingEntity l && l.isAlive() ? l : null;
    }

    static ServerPlayerEntity target() {
        if (world == null || playerId == null) return null;
        for (ServerPlayerEntity p : world.getPlayers()) if (p.getUuid().equals(playerId)) return p;
        return null;
    }

    static final String SEL = "@e[tag=gokubot,limit=1]";

    static String ench(String... kv) {
        StringBuilder sb = new StringBuilder("[enchantments={");
        for (int i = 0; i < kv.length; i += 2) { if (i > 0) sb.append(','); sb.append("\"minecraft:").append(kv[i]).append("\":").append(kv[i + 1]); }
        return sb.append("}]").toString();
    }

    static void kit(MinecraftServer s) {
        var m = module;
        int p = m.prot.i();
        String armor = p > 0 ? ench("protection", String.valueOf(p), "unbreaking", "3", "mending", "1") : "";
        String[][] slots = {{"armor.head", "netherite_helmet"}, {"armor.chest", "netherite_chestplate"}, {"armor.legs", "netherite_leggings"}, {"armor.feet", "netherite_boots"}};
        for (String[] sl : slots) cmd(s, "item replace entity " + SEL + " " + sl[0] + " with minecraft:" + sl[1] + armor);
        String main;
        switch (m.mode.idx) {
            case 1 -> main = "mace" + ench("density", String.valueOf(m.density.i()), "breach", "4", "unbreaking", "3", "mending", "1");
            case 2 -> main = "netherite_sword" + (m.sharp.i() > 0 ? ench("sharpness", String.valueOf(m.sharp.i()), "fire_aspect", "2", "unbreaking", "3", "mending", "1") : "");
            default -> main = "netherite_sword" + (m.sharp.i() > 0 ? ench("sharpness", String.valueOf(m.sharp.i()), "unbreaking", "3", "mending", "1") : "");
        }
        cmd(s, "item replace entity " + SEL + " weapon.mainhand with minecraft:" + main);
        if (m.totem.b) cmd(s, "item replace entity " + SEL + " weapon.offhand with minecraft:totem_of_undying");
        else cmd(s, "item replace entity " + SEL + " weapon.offhand with minecraft:air");
    }

    static void remove(MinecraftServer s) {
        if (world != null) {
            Entity e = botId == null ? null : world.getEntity(botId);
            if (e != null) e.discard();
            for (EndCrystalEntity c : pendingEnt) c.discard();
        }
        pending.clear(); pendingEnt.clear();
        botId = null;
        if (s != null) cmd(s, "kill @e[tag=gokubot]");   // leftovers from a crash / old session
    }

    static void spawn(MinecraftServer s) {
        remove(s);
        var m = module;
        if (m == null || reqKey == null) return;
        ServerWorld w = s.getWorld(reqKey);
        if (w == null) return;
        world = w; key = reqKey; playerId = reqPlayer;
        double x = reqX, y = reqY, z = reqZ;
        String nameTag = BotConfig.showName ? "CustomName:{text:\"" + BotConfig.name + "\"},CustomNameVisible:1b," : "";
        String cape = reqCape;
        String prof = cape != null ? "profile:{name:\"" + BotConfig.skin + "\",cape:\"" + cape + "\"}" : "profile:\"" + BotConfig.skin + "\"";
        String[] tries = {prof, "profile:\"" + BotConfig.skin + "\"", ""};
        LivingEntity found = null;
        for (String pr : tries) {
            String nbt = "{Tags:[\"gokubot\"]," + nameTag + (pr.isEmpty() ? "" : pr + ",") + "hide_description:1b}";
            cmd(s, "execute in " + key.getValue() + " run summon minecraft:mannequin " + x + " " + y + " " + z + " " + nbt);
            found = find(w, x, y, z);
            if (found != null) break;
        }
        if (found == null) { tell("Could not spawn the bot (this needs Minecraft 1.21.9 or newer)."); return; }
        botId = found.getUuid();
        var hp = found.getAttributeInstance(EntityAttributes.MAX_HEALTH);
        if (hp != null) hp.setBaseValue(m.health.v);
        found.setHealth((float) m.health.v);
        found.setNoGravity(true);
        bvy = kx = kz = wx = wz = 0; warnedCreative = false; creativeWarnCd = 0;
        kit(s);
        potsLeft = m.pots.i(); totemsLeft = m.totems.i();
        attackCd = 20; potCd = launchCd = smashCd = crystalCd = jumpCd = strafeT = totemCd = deadTicks = 0;
        wasAir = false;
        if (m.mode.idx == 2 && m.buffs.b) buff(found);
    }

    static LivingEntity find(ServerWorld w, double x, double y, double z) {
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, new Box(x - 3, y - 3, z - 3, x + 3, y + 4, z + 3), e -> e.getCommandTags().contains("gokubot"))) return e;
        return null;
    }

    static void buff(LivingEntity bot) {
        if (!bot.hasStatusEffect(StatusEffects.SPEED) && potsLeft > 0) { bot.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 20 * 60 * 8, 1)); potsLeft--; }
        if (!bot.hasStatusEffect(StatusEffects.STRENGTH) && potsLeft > 0) { bot.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 20 * 60 * 8, 1)); potsLeft--; }
    }

    static void face(LivingEntity bot, ServerPlayerEntity t) {
        double dx = t.getX() - bot.getX(), dz = t.getZ() - bot.getZ();
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        bot.setYaw(yaw); bot.setHeadYaw(yaw); bot.setBodyYaw(yaw);
    }

    /** Set the wanted horizontal movement for this tick (applied by physics()). */
    static void walk(LivingEntity bot, double dirX, double dirZ, double speed) {
        double len = Math.sqrt(dirX * dirX + dirZ * dirZ);
        if (len > 1) { dirX /= len; dirZ /= len; }
        wx = dirX * speed; wz = dirZ * speed;
    }

    /** Own movement: a Mannequin has no AI/travel of its own, so gravity, jumping, knockback and collisions are done here. */
    static void physics(LivingEntity bot) {
        var v = bot.getVelocity();
        if (Math.abs(v.x) + Math.abs(v.z) > 0.08) { kx += v.x; kz += v.z; }   // pushed by the player's hits
        if (v.y > bvy + 0.2) bvy = v.y;
        bot.setNoGravity(true);
        boolean ground = bot.isOnGround();
        if (ground && bvy < 0) bvy = -0.0784; else bvy = Math.max(-3.0, (bvy - 0.08) * 0.98);
        double mx = wx + kx, mz = wz + kz;
        kx *= ground ? 0.55 : 0.92; kz *= ground ? 0.55 : 0.92;
        if (Math.abs(kx) < 0.003) kx = 0;
        if (Math.abs(kz) < 0.003) kz = 0;
        bot.move(MovementType.SELF, new Vec3d(mx, bvy, mz));
        if (bot.horizontalCollision && bot.isOnGround() && (wx != 0 || wz != 0)) bvy = 0.42;   // hop over blocks
        if (bot.verticalCollision && bvy > 0) bvy = 0;
        bot.setVelocity(Vec3d.ZERO);
        wx = wz = 0;
    }

    static void hit(ServerPlayerEntity t, LivingEntity bot, float dmg) {
        t.damage(world, world.getDamageSources().generic(), dmg);   // not difficulty-scaled, so it also hurts on Peaceful/Easy
        t.takeKnockback(0.5, bot.getX() - t.getX(), bot.getZ() - t.getZ());
        t.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(t));
        bot.swingHand(Hand.MAIN_HAND);
    }

    // ---- main tick
    static void tick(MinecraftServer s) {
        var m = module;
        if (m == null) return;
        if (wantRemove) { wantRemove = false; remove(s); }
        if (wantSpawn) { wantSpawn = false; spawn(s); }
        if (wantRekit) { wantRekit = false; if (bot() != null) kit(s); }
        if (world == null || botId == null) return;

        // pending crystal detonations
        for (int i = pending.size() - 1; i >= 0; i--) {
            double[] c = pending.get(i);
            if (--c[0] <= 0) {
                EndCrystalEntity ce = pendingEnt.get(i);
                LivingEntity b = bot();
                world.createExplosion(b, c[1], c[2], c[3], (float) m.crystalPower.v, World.ExplosionSourceType.NONE);
                ce.discard();
                pending.remove(i); pendingEnt.remove(i);
            }
        }

        LivingEntity bot = bot();
        if (bot == null) {
            if (++deadTicks >= m.respawnDelay.i() * 20 && m.respawn.b) {
                ServerPlayerEntity t0 = target();
                if (t0 != null) {
                    double yaw = Math.toRadians(t0.getYaw()), d = m.spawnDist.v;
                    reqKey = key; reqPlayer = playerId; reqX = t0.getX() - Math.sin(yaw) * d; reqY = t0.getY() + 0.5; reqZ = t0.getZ() + Math.cos(yaw) * d;
                    spawn(s);
                }
            }
            return;
        }
        ServerPlayerEntity t = target();
        if (t == null || t.isSpectator()) { wx = wz = 0; physics(bot); return; }

        if (attackCd > 0) attackCd--;
        if (potCd > 0) potCd--;
        if (smashCd > 0) smashCd--;
        if (launchCd > 0) launchCd--;
        if (crystalCd > 0) crystalCd--;
        if (jumpCd > 0) jumpCd--;
        if (totemCd > 0) totemCd--;

        int diff = m.difficulty.i();
        double speed = 0.16 + diff * 0.012;
        int interval = 18 - diff;
        double dx = t.getX() - bot.getX(), dz = t.getZ() - bot.getZ(), dy = t.getY() - bot.getY();
        double hd = Math.sqrt(dx * dx + dz * dz), d3 = Math.sqrt(hd * hd + dy * dy);
        double nx = hd > 1e-4 ? dx / hd : 0, nz = hd > 1e-4 ? dz / hd : 0;
        boolean ground = bot.isOnGround();
        boolean creative = t.isCreative();
        boolean canHurt = !m.passive.b && !creative;
        if (creative && !m.passive.b && creativeWarnCd-- <= 0) { tell("You are in Creative mode, so the bot cannot damage you. Switch to Survival (/gamemode survival)."); creativeWarnCd = 400; }
        face(bot, t);

        if (--strafeT <= 0) { strafeT = 20 + RND.nextInt(30); strafeDir = RND.nextBoolean() ? 1 : -1; }
        double px = -nz * strafeDir, pz = nx * strafeDir;   // perpendicular
        double sf = m.strafe.b ? 0.6 : 0;

        // totem refill
        if (m.totem.b && totemsLeft > 0 && totemCd <= 0 && !bot.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
            cmd(s, "item replace entity " + SEL + " weapon.offhand with minecraft:totem_of_undying");
            totemsLeft--; totemCd = 30;
        }

        switch (m.mode.idx) {
            case 0 -> crystal(bot, t, hd, d3, nx, nz, px, pz, sf, speed, interval, ground, canHurt);
            case 1 -> mace(bot, t, hd, d3, nx, nz, px, pz, sf, speed, interval, ground, canHurt);
            default -> pot(s, bot, t, hd, d3, nx, nz, px, pz, sf, speed, interval, ground, canHurt);
        }
        if (m.mode.idx != 1 && m.hop.b && ground && jumpCd <= 0 && hd < 8) {
            bvy = 0.42;
            jumpCd = 10 + RND.nextInt(14);
        }
        physics(bot);
    }

    static void crystal(LivingEntity bot, ServerPlayerEntity t, double hd, double d3, double nx, double nz, double px, double pz, double sf, double speed, int interval, boolean ground, boolean canHurt) {
        var m = module;
        double want = 4.5;
        double fwd = hd > want + 1.5 ? 1 : hd < want - 1.5 ? -0.8 : 0;
        walk(bot, nx * fwd + px * sf, nz * fwd + pz * sf, speed);
        if (canHurt && crystalCd <= 0 && hd < 10 && pending.size() < 3) {
            double ang = RND.nextDouble() * Math.PI * 2, r = 1.3 + RND.nextDouble() * 0.8;
            double cx = t.getX() + Math.cos(ang) * r, cz = t.getZ() + Math.sin(ang) * r, cy = t.getY();
            if (!world.getBlockState(BlockPos.ofFloored(cx, cy, cz)).isAir()) { cx = t.getX() + 1.5; cz = t.getZ(); }
            EndCrystalEntity ce = new EndCrystalEntity(world, cx, cy, cz);
            ce.setShowBottom(false);
            world.spawnEntity(ce);
            pending.add(new double[]{3, cx, cy, cz});
            pendingEnt.add(ce);
            bot.swingHand(Hand.MAIN_HAND);
            crystalCd = Math.max(4, m.crystalRate.i() + 4 - m.difficulty.i() / 2);
        }
        if (canHurt && d3 <= 3.0 && attackCd <= 0) { hit(t, bot, sword(bot, ground)); attackCd = interval; }
    }

    static float sword(LivingEntity bot, boolean ground) {
        var m = module;
        float d = 8f + m.sharp.i() * 0.5f + (m.sharp.i() > 0 ? 0.5f : 0f);
        var str = bot.getStatusEffect(StatusEffects.STRENGTH);
        if (str != null) d += 3f * (str.getAmplifier() + 1);
        if (!ground && bvy < 0) d *= 1.5f;
        if (RND.nextDouble() > 0.6 + 0.04 * m.difficulty.i()) d = 0f;   // miss
        return d;
    }

    static void pot(MinecraftServer s, LivingEntity bot, ServerPlayerEntity t, double hd, double d3, double nx, double nz, double px, double pz, double sf, double speed, int interval, boolean ground, boolean canHurt) {
        var m = module;
        double fwd = hd > 2.6 ? 1 : hd < 1.6 ? -0.5 : 0.1;
        walk(bot, nx * fwd + px * sf, nz * fwd + pz * sf, speed);
        if (m.buffs.b) buff(bot);
        if (bot.getHealth() <= m.healAt.v && potsLeft > 0 && potCd <= 0) {
            cmd(s, "execute as " + SEL + " at @s run summon minecraft:splash_potion ~ ~0.3 ~ {Item:{id:\"minecraft:splash_potion\",count:1,components:{\"minecraft:potion_contents\":{potion:\"minecraft:strong_healing\"}}}}");
            potsLeft--; potCd = 14;
        }
        if (canHurt && d3 <= 3.0 && attackCd <= 0) {
            float d = sword(bot, ground);
            if (d > 0) hit(t, bot, d); else bot.swingHand(Hand.MAIN_HAND);
            attackCd = interval;
        }
    }

    static void mace(LivingEntity bot, ServerPlayerEntity t, double hd, double d3, double nx, double nz, double px, double pz, double sf, double speed, int interval, boolean ground, boolean canHurt) {
        var m = module;
        if (ground) {
            wasAir = false;
            walk(bot, nx + px * sf * 0.4, nz + pz * sf * 0.4, speed);
            if (canHurt && hd <= 9 && hd >= 2 && launchCd <= 0) {
                bvy = Math.sqrt(2 * 0.08 * m.launch.v) * 1.12;   // ~ the apex requested
                kx = nx * 0.25; kz = nz * 0.25;
                apex = bot.getY(); wasAir = true;
                launchCd = 60 - m.difficulty.i() * 3;
            } else if (canHurt && d3 <= 3.0 && attackCd <= 0) { hit(t, bot, 6f); attackCd = interval + 8; }
        } else {
            wasAir = true;
            apex = Math.max(apex, bot.getY());
            walk(bot, nx, nz, 0.22 + m.difficulty.i() * 0.008);
            double fall = apex - bot.getY();
            if (canHurt && bvy < 0 && d3 <= 3.4 && fall >= 1.5 && smashCd <= 0) {
                double f = fall;
                double bonus = Math.min(f, 3) * 4 + Math.max(0, Math.min(f - 3, 5)) * 2 + Math.max(0, f - 8) + f * 0.5 * m.density.i();
                if (RND.nextDouble() <= 0.65 + 0.035 * m.difficulty.i()) hit(t, bot, (float) (6 + bonus)); else bot.swingHand(Hand.MAIN_HAND);
                bvy = 0.35; kx = kz = 0;
                apex = bot.getY();
                smashCd = 12;
            }
        }
        bot.fallDistance = 0;   // the mace cancels fall damage
    }
}
