package com.goku;

import com.goku.gui.ClickGui;
import com.goku.util.Esp;
import com.goku.util.Projector;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public class GokuMod implements ClientModInitializer {
    boolean altWas, ctrlWas;

    @Override public void onInitializeClient() {
        Config.captureDefaults();
        Config.load("default");
        ClientTickEvents.START_CLIENT_TICK.register(mc -> {
            if (mc.player == null || mc.world == null) return;
            for (Module m : Modules.ALL) if (m.enabled) m.onPreTick();
        });
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_ALT) == GLFW.GLFW_PRESS;
            Modules.CONFIG.poll();
            long h = mc.getWindow().getHandle();
            boolean ctrl = GLFW.glfwGetKey(h, GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS;
            if (ctrl && !ctrlWas && mc.currentScreen == null && Modules.SOUND.hotkey.b) {
                Modules.SOUND.keep.b = !Modules.SOUND.keep.b;
                if (mc.player != null) mc.player.sendMessage(net.minecraft.text.Text.literal("[Goku] Music " + (Modules.SOUND.keep.b ? "on" : "off")), true);
            }
            ctrlWas = ctrl;
            com.goku.util.Sfx.tick();
            if (down && !altWas && mc.currentScreen == null && mc.player != null) mc.setScreen(new ClickGui());
            altWas = down;
            if (mc.player == null || mc.world == null) { Modules.FREECAM.setEnabled(false); return; }
            if (Modules.CONFIG.guard.b && !com.goku.util.Guard.allowed()) for (Module m : Modules.CHEAT) if (m.enabled) m.setEnabled(false);
            for (Module m : Modules.ALL) if (m.enabled) m.onTick();
        });
        HudRenderCallback.EVENT.register((ctx, tc) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null) return;
            float td = tc.getTickProgress(false);
            Projector.update(mc, td);
            Esp.hudY = 4;
            for (Module m : Modules.ALL) if (m.enabled) m.onRender(ctx, td);
        });
    }
}
