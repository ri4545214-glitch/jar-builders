package com.goku;

import com.goku.gui.ClickGui;
import com.goku.util.Esp;
import com.goku.util.Projector;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public class GokuMod implements ClientModInitializer {
    boolean altWas;

    @Override public void onInitializeClient() {
        ClientTickEvents.START_CLIENT_TICK.register(mc -> {
            if (mc.player == null || mc.world == null) return;
            for (Module m : Modules.ALL) if (m.enabled) m.onPreTick();
        });
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_ALT) == GLFW.GLFW_PRESS;
            if (down && !altWas && mc.currentScreen == null && mc.player != null) mc.setScreen(new ClickGui());
            altWas = down;
            if (mc.player == null || mc.world == null) { Modules.FREECAM.setEnabled(false); return; }
            for (Module m : Modules.ALL) if (m.enabled) m.onTick();
        });
        HudRenderCallback.EVENT.register((ctx, tc) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null) return;
            float td = tc.getTickProgress(false);
            Projector.update(mc, td);
            Esp.hudY = 4;
            for (Module m : Modules.ALL) if (m.enabled) m.onRender(ctx, td);
        });
    }
}
