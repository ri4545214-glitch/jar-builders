package com.goku.mixin;

import com.goku.skin.SkinOverride;
import net.minecraft.client.network.PlayerListEntry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Swaps the skin/cape of YOUR player entry on your own screen. Kept in its own non-required mixin config so a mapping change
 * can never stop the game from starting; the worst case is that the skin simply does not change.
 */
@Mixin(PlayerListEntry.class)
public abstract class PlayerListEntryMixin {
    @SuppressWarnings({"rawtypes", "unchecked"})
    @Inject(method = {"getSkinTextures", "getSkin"}, at = @At("RETURN"), cancellable = true, require = 0)
    private void goku$skin(CallbackInfoReturnable cir) {
        Object o = SkinOverride.apply(this, cir.getReturnValue());
        if (o != null) cir.setReturnValue(o);
    }
}
