package com.goku.mixin;

import com.goku.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Same idea as the Freecam mod: mouse/touch look is redirected from the real player to the free camera. */
@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void goku$freecamLook(double cursorDeltaX, double cursorDeltaY, CallbackInfo ci) {
        if (!Modules.FREECAM.enabled) return;
        if ((Object) this != MinecraftClient.getInstance().player) return;
        if (Modules.FREECAM.turn(cursorDeltaX, cursorDeltaY)) ci.cancel();
    }
}
