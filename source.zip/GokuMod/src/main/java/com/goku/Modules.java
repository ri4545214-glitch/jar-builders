package com.goku;

import com.goku.modules.*;
import java.util.ArrayList;
import java.util.List;

public final class Modules {
    public static final StorageEsp STORAGE = new StorageEsp();
    public static final SpawnerEsp SPAWNER = new SpawnerEsp();
    public static final BaseEsp BASE_FINDER = new BaseEsp();
    public static final EntityEsp ENTITY_FINDER = new EntityEsp();
    public static final ChunkLog CHUNK_LOG = new ChunkLog();
    public static final ParticleModule PARTICLES = new ParticleModule();
    public static final SusChunk SUS = new SusChunk();
    public static final Freecam FREECAM = new Freecam();
    public static final PlayerEsp PLAYER_ESP = new PlayerEsp();
    public static final AutoAim AUTO_AIM = new AutoAim();
    public static final AutoAttack AUTO_ATTACK = new AutoAttack();
    public static final KillAura KILL_AURA = new KillAura();
    public static final AnchorMacro ANCHOR = new AnchorMacro();
    public static final AutoCrystal CRYSTAL = new AutoCrystal();
    public static final AutoTotem TOTEM = new AutoTotem();
    public static final HoverTotem HOVER_TOTEM = new HoverTotem();
    public static final Speed SPEED = new Speed();
    public static final AutoBridge BRIDGE = new AutoBridge();
    public static final SoundModule SOUND = new SoundModule();
    public static final ThemeModule THEME = new ThemeModule();

    public static final List<Module> BASE = List.of(STORAGE, SPAWNER, BASE_FINDER, ENTITY_FINDER, SUS, CHUNK_LOG, FREECAM);
    public static final List<Module> COMBAT = List.of(PLAYER_ESP, AUTO_AIM, AUTO_ATTACK, KILL_AURA, CRYSTAL, ANCHOR, TOTEM, HOVER_TOTEM);
    public static final List<Module> MOVEMENT = List.of(SPEED, BRIDGE);
    public static final List<Module> ALL = new ArrayList<>();
    static { ALL.addAll(BASE); ALL.addAll(COMBAT); ALL.addAll(MOVEMENT); }

    public static int accent() { return THEME.accent(); }
    public static int accent2() { return THEME.accent2(); }
}
