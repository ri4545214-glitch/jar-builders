package com.goku;

import com.goku.modules.*;
import java.util.ArrayList;
import java.util.List;

public final class Modules {
    public static final StorageEsp STORAGE = new StorageEsp();
    public static final SusChunk SUS = new SusChunk();
    public static final Freecam FREECAM = new Freecam();
    public static final PlayerEsp PLAYER_ESP = new PlayerEsp();
    public static final AutoAim AUTO_AIM = new AutoAim();
    public static final AutoAttack AUTO_ATTACK = new AutoAttack();
    public static final KillAura KILL_AURA = new KillAura();
    public static final ThemeModule THEME = new ThemeModule();

    public static final List<Module> BASE = List.of(STORAGE, SUS, FREECAM);
    public static final List<Module> COMBAT = List.of(PLAYER_ESP, AUTO_AIM, AUTO_ATTACK, KILL_AURA);
    public static final List<Module> ALL = new ArrayList<>();
    static { ALL.addAll(BASE); ALL.addAll(COMBAT); }

    public static int accent() { return THEME.accent(); }
}
