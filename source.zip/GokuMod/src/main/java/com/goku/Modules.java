package com.goku;

import com.goku.modules.*;
import java.util.ArrayList;
import java.util.List;

public final class Modules {
    public static final StorageEsp STORAGE = new StorageEsp();
    public static final SpawnerEsp SPAWNER = new SpawnerEsp();
    public static final BaseEsp BASE_FINDER = new BaseEsp();
    public static final EntityEsp ENTITY_FINDER = new EntityEsp();
    public static final ChunkLog CHUNK_LOG = new ChunkLog();
    public static final ParticleModule PARTICLES = new ParticleModule();
    public static final SusChunk SUS = new SusChunk();
    public static final Freecam FREECAM = new Freecam();
    public static final PlayerEsp PLAYER_ESP = new PlayerEsp();
    public static final AutoAim AUTO_AIM = new AutoAim();
    public static final AutoAttack AUTO_ATTACK = new AutoAttack();
    public static final KillAura KILL_AURA = new KillAura();
    public static final AnchorMacro ANCHOR = new AnchorMacro();
    public static final AutoCrystal CRYSTAL = new AutoCrystal();
    public static final AutoTotem TOTEM = new AutoTotem();
    public static final HoverTotem HOVER_TOTEM = new HoverTotem();
    public static final Speed SPEED = new Speed();
    public static final AutoBridge BRIDGE = new AutoBridge();
    public static final SilentAim SILENT_AIM = new SilentAim();
    public static final Keystrokes KEYSTROKES = new Keystrokes();
    public static final Fly FLY = new Fly();
    public static final Sprint SPRINT = new Sprint();
    public static final Step STEP = new Step();
    public static final Fullbright FULLBRIGHT = new Fullbright();
    public static final AutoArmor AUTO_ARMOR = new AutoArmor();
    public static final ChestStealer STEALER = new ChestStealer();
    public static final BaseAi BASE_AI = new BaseAi();
    public static final CrystalPvp CRYSTAL_PVP = new CrystalPvp();
    public static final AutoClicker AUTO_CLICKER = new AutoClicker();
    public static final AutoWalk AUTO_WALK = new AutoWalk();
    public static final AutoMine AUTO_MINE = new AutoMine();
    public static final AutoFind AUTO_FIND = new AutoFind();
    public static final PlayerHunter HUNTER = new PlayerHunter();
    public static final AutoDTap DTAP = new AutoDTap();
    public static final ConfigModule CONFIG = new ConfigModule();
    public static final SoundModule SOUND = new SoundModule();
    public static final ThemeModule THEME = new ThemeModule();

    public static final List<Module> BASE = List.of(BASE_AI, STORAGE, SPAWNER, BASE_FINDER, ENTITY_FINDER, SUS, CHUNK_LOG, FREECAM, FULLBRIGHT, KEYSTROKES);
    public static final List<Module> COMBAT = List.of(PLAYER_ESP, CRYSTAL_PVP, DTAP, AUTO_AIM, SILENT_AIM, AUTO_ATTACK, KILL_AURA, CRYSTAL, ANCHOR, TOTEM, HOVER_TOTEM, AUTO_ARMOR);
    public static final List<Module> MOVEMENT = List.of(FLY, SPEED, SPRINT, STEP, BRIDGE);
    public static final List<Module> AUTOMATION = List.of(AUTO_CLICKER, AUTO_WALK, AUTO_MINE, AUTO_FIND, HUNTER, STEALER);
    /** Modules the Online Guard switches off on servers that are not in allowed-servers.txt. */
    public static final List<Module> CHEAT = new ArrayList<>();
    public static final List<Module> ALL = new ArrayList<>();
    public static final List<Module> EVERY = new ArrayList<>();
    static { CHEAT.addAll(COMBAT); CHEAT.remove(PLAYER_ESP); CHEAT.addAll(MOVEMENT); CHEAT.addAll(AUTOMATION);
        ALL.addAll(BASE); ALL.addAll(COMBAT); ALL.addAll(MOVEMENT); ALL.addAll(AUTOMATION);
        EVERY.addAll(ALL); EVERY.add(THEME); EVERY.add(PARTICLES); EVERY.add(SOUND); EVERY.add(CONFIG); }

    public static int accent() { return THEME.accent(); }
    public static int accent2() { return THEME.accent2(); }
}
