package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.AnchorOps;
import net.minecraft.block.Blocks;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** Anchor macro that protects you: puts a block between you and the anchor before it detonates and aborts if your health is too low. */
public class SafeAnchor extends Module {
    final Setting charges = add(Setting.num("Charges", 1, 1, 4, 1));
    final Setting chargeDelay = add(Setting.num("Charge Delay", 1, 0, 10, 1));
    final Setting explodeDelay = add(Setting.num("Explode Delay", 1, 0, 10, 1));
    final Setting explodeWith = add(Setting.mode("Explode With", 0, "Totem", "Any Item"));
    final Setting shield = add(Setting.bool("Shield Block", true));
    final Setting minHp = add(Setting.num("Abort Below HP", 8, 0, 20, 1));
    final Setting autoPlace = add(Setting.bool("Auto Place (hold anchor)", false));
    final Setting range = add(Setting.num("Range", 4.5, 2, 6, 0.5));
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    final AnchorOps.Run run = new AnchorOps.Run();
    int wait;

    public SafeAnchor() { super("Safe Anchor"); }

    @Override public void onDisable() { if (mc.player != null) run.finish(swapBack.b); }

    @Override public void onTick() {
        if (Modules.FREECAM.enabled || mc.currentScreen != null) return;
        if (run.anchor != null) {
            if (!run.step(charges.i(), chargeDelay.i(), explodeDelay.i(), explodeWith.idx == 0, shield.b, range.v, minHp.v)) { run.finish(swapBack.b); wait = 4; }
            return;
        }
        if (wait > 0) { wait--; return; }
        if (!(mc.crosshairTarget instanceof BlockHitResult hr) || hr.getType() != HitResult.Type.BLOCK) return;
        BlockPos p = hr.getBlockPos();
        if (mc.world.getBlockState(p).isOf(Blocks.RESPAWN_ANCHOR)) run.start(p);
        else if (autoPlace.b && mc.player.getMainHandStack().isOf(Items.RESPAWN_ANCHOR)) {
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hr);
            mc.player.swingHand(Hand.MAIN_HAND);
            run.start(p.offset(hr.getSide()));
            run.cd = 2;
        }
    }
}
