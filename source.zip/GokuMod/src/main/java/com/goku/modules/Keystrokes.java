package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;

/** HUD overlay showing WASD, Space and the mouse buttons with live CPS. */
public class Keystrokes extends Module {
    final Setting pos = add(Setting.mode("Position", 0, "Bottom Left", "Bottom Right", "Top Right", "Top Left"));
    final Setting scale = add(Setting.num("Size", 18, 12, 32, 2));
    final Setting mouse = add(Setting.bool("Mouse Buttons + CPS", true));
    final Setting space = add(Setting.bool("Space Bar", true));
    final Setting opacity = add(Setting.num("Opacity", 150, 40, 255, 10));
    final ArrayDeque<Long> lc = new ArrayDeque<>(), rc = new ArrayDeque<>();
    boolean lWas, rWas;

    public Keystrokes() { super("Keystrokes"); }

    static int cps(ArrayDeque<Long> q, long now) {
        while (!q.isEmpty() && now - q.peekFirst() > 1000) q.pollFirst();
        return q.size();
    }

    void key(DrawContext c, int x, int y, int w, int h, String label, boolean down, int accent) {
        int a = opacity.i();
        c.fill(x, y, x + w, y + h, down ? (accent & 0xFFFFFF) | (Math.min(255, a + 60) << 24) : (0x101018 | (a << 24)));
        c.fill(x, y, x + w, y + 1, (accent & 0xFFFFFF) | (0x90 << 24));
        c.drawText(mc.textRenderer, label, x + (w - mc.textRenderer.getWidth(label)) / 2, y + (h - 8) / 2, 0xFFFFFFFF, true);
    }

    @Override public void onRender(DrawContext c, float td) {
        long now = System.currentTimeMillis();
        long h = mc.getWindow().getHandle();
        boolean l = GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS, r = GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (mc.currentScreen == null) {
            if (l && !lWas) lc.add(now);
            if (r && !rWas) rc.add(now);
        }
        lWas = l; rWas = r;
        int u = scale.i(), g = 2, bw = 3 * u + 2 * g;
        int bh = 2 * u + g + (space.b ? u / 2 + g : 0) + (mouse.b ? u + g : 0);
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        int x = (pos.idx == 1 || pos.idx == 2) ? sw - bw - 8 : 8;
        int y = (pos.idx == 0 || pos.idx == 1) ? sh - bh - 8 : 8;
        int acc = Modules.accent();
        var o = mc.options;
        key(c, x + u + g, y, u, u, "W", o.forwardKey.isPressed(), acc);
        key(c, x, y + u + g, u, u, "A", o.leftKey.isPressed(), acc);
        key(c, x + u + g, y + u + g, u, u, "S", o.backKey.isPressed(), acc);
        key(c, x + 2 * (u + g), y + u + g, u, u, "D", o.rightKey.isPressed(), acc);
        int yy = y + 2 * u + 2 * g;
        if (space.b) { key(c, x, yy, bw, u / 2, "-", o.jumpKey.isPressed(), acc); yy += u / 2 + g; }
        if (mouse.b) {
            int mw = (bw - g) / 2;
            key(c, x, yy, mw, u, "LMB " + cps(lc, now), l, acc);
            key(c, x + mw + g, yy, bw - mw - g, u, "RMB " + cps(rc, now), r, acc);
        }
    }
}
