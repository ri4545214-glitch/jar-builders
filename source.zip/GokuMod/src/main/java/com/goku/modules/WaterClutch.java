package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Inv;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** MLG water bucket: places water just before you hit the ground, then picks it back up. */
public class WaterClutch extends Module {
    final Setting minFall = add(Setting.num("Min Fall Distance", 4, 2, 30, 1));
    final Setting reach = add(Setting.num("Trigger Height", 2.8, 1.5, 3.0, 0.1));
    final Setting pickup = add(Setting.bool("Pick Water Back Up", true));
    final Setting pickDelay = add(Setting.num("Pickup Delay (ticks)", 3, 0, 10, 1));
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    boolean placed;
    int wait, timeout;

    public WaterClutch() { super("Water Clutch"); }

    @Override public void onDisable() { placed = false; wait = timeout = 0; }

    private boolean use(int slot) {
        if (slot < 0) return false;
        var p = mc.player;
        int prev = Inv.selected();
        float pitch = p.getPitch();
        Inv.select(slot);
        p.setPitch(90f);
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.swingHand(Hand.MAIN_HAND);
        p.setPitch(pitch);
        if (swapBack.b) Inv.select(prev);
        return true;
    }

    @Override public void onTick() {
        if (mc.currentScreen != null || Modules.FREECAM.enabled) return;
        var p = mc.player;
        if (placed) {
            if (p.isOnGround() || p.isTouchingWater()) {
                if (++wait >= pickDelay.i()) {
                    if (pickup.b) use(Inv.hotbar(s -> s.isOf(Items.BUCKET)));
                    placed = false; wait = timeout = 0;
                }
            } else if (++timeout > 80) { placed = false; timeout = 0; }
            return;
        }
        if (p.isOnGround() || p.isTouchingWater() || p.isClimbing() || p.isGliding() || p.getAbilities().flying) return;
        if (p.getVelocity().y > -0.3 || p.fallDistance < minFall.v) return;
        Vec3d from = p.getEntityPos();
        var hit = mc.world.raycast(new RaycastContext(from, from.add(0, -reach.v, 0), RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
        if (hit.getType() != HitResult.Type.BLOCK) return;
        if (use(Inv.hotbar(s -> s.isOf(Items.WATER_BUCKET)))) { placed = true; wait = timeout = 0; }
    }
}
