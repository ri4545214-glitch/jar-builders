package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;

/** Keeps you sprinting while you move. */
public class Sprint extends Module {
    final Setting omni = add(Setting.bool("All Directions", false));

    public Sprint() { super("Sprint"); }

    @Override public void onPreTick() {
        if (Modules.FREECAM.enabled || mc.currentScreen != null) return;
        var o = mc.options; var p = mc.player;
        boolean moving = omni.b ? (o.forwardKey.isPressed() || o.backKey.isPressed() || o.leftKey.isPressed() || o.rightKey.isPressed()) : o.forwardKey.isPressed();
        if (moving && !p.isSneaking() && !p.horizontalCollision && p.getHungerManager().getFoodLevel() > 6) p.setSprinting(true);
    }
}
