package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Targets;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/** Places end crystals on obsidian/bedrock and breaks them. Aura mode picks spots next to the nearest target; Macro mode follows the crosshair. */
public class AutoCrystal extends Module {
    final Setting mode = add(Setting.mode("Mode", 0, "Aura", "Macro"));
    final Setting place = add(Setting.bool("Place", true));
    final Setting breakC = add(Setting.bool("Break", true));
    final Setting placeRange = add(Setting.num("Place Range", 4.5, 2, 6, 0.5));
    final Setting breakRange = add(Setting.num("Break Range", 4.5, 2, 6, 0.5));
    final Setting targetRange = add(Setting.num("Target Range", 8, 3, 12, 1));
    final Setting placeDelay = add(Setting.num("Place Delay", 2, 0, 10, 1));
    final Setting breakDelay = add(Setting.num("Break Delay", 1, 0, 10, 1));
    final Setting autoSwitch = add(Setting.bool("Auto Switch", true));
    final Setting rotate = add(Setting.bool("Rotate", false));
    final Setting nearTarget = add(Setting.bool("Break Near Target Only", false));
    final Setting minHealth = add(Setting.num("Stop Below HP", 6, 0, 20, 1));
    final Setting minSelf = add(Setting.num("Min Self Distance", 2, 0, 4, 0.5));
    int pc, bc;

    public AutoCrystal() { super("Auto Crystal"); }

    @Override public void onTick() {
        if (Modules.FREECAM.enabled || mc.currentScreen != null) return;
        if (pc > 0) pc--;
        if (bc > 0) bc--;
        if (mc.player.getHealth() <= minHealth.v) return;
        Vec3d eye = mc.player.getEyePos();
        LivingEntity target = null;
        var list = Targets.find(mc, targetRange.v, true, false, true);
        if (!list.isEmpty()) target = list.get(0);

        if (breakC.b && bc == 0) {
            EndCrystalEntity best = null; double bd = 1e9;
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof EndCrystalEntity ec)) continue;
                double d = eye.distanceTo(ec.getEntityPos());
                if (d > breakRange.v || d >= bd) continue;
                if (nearTarget.b && target != null && ec.distanceTo(target) > 6) continue;
                best = ec; bd = d;
            }
            if (best != null) {
                aim(best.getEntityPos());
                mc.interactionManager.attackEntity(mc.player, best);
                mc.player.swingHand(Hand.MAIN_HAND);
                bc = breakDelay.i();
            }
        }

        if (!place.b || pc > 0) return;
        BlockPos spot = null;
        if (mode.idx == 1) {
            if (mc.crosshairTarget instanceof BlockHitResult hr && hr.getType() == HitResult.Type.BLOCK && valid(hr.getBlockPos(), eye)) spot = hr.getBlockPos();
        } else if (target != null) {
            double bd = 1e9; int r = (int) Math.ceil(placeRange.v);
            BlockPos c = mc.player.getBlockPos();
            for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
                BlockPos p = c.add(x, y, z);
                if (!valid(p, eye)) continue;
                double d = target.getEntityPos().distanceTo(Vec3d.ofCenter(p).add(0, 0.5, 0));
                if (d > 5 || d >= bd) continue;
                bd = d; spot = p;
            }
        }
        if (spot == null) return;
        Hand hand = null; int prev = Inv.selected();
        if (mc.player.getOffHandStack().isOf(Items.END_CRYSTAL)) hand = Hand.OFF_HAND;
        else if (mc.player.getMainHandStack().isOf(Items.END_CRYSTAL)) hand = Hand.MAIN_HAND;
        else if (autoSwitch.b) { int s = Inv.hotbar(st -> st.isOf(Items.END_CRYSTAL)); if (s >= 0) { Inv.select(s); hand = Hand.MAIN_HAND; } }
        if (hand == null) return;
        aim(Vec3d.ofCenter(spot).add(0, 0.5, 0));
        mc.interactionManager.interactBlock(mc.player, hand, new BlockHitResult(new Vec3d(spot.getX() + 0.5, spot.getY() + 1.0, spot.getZ() + 0.5), Direction.UP, spot, false));
        mc.player.swingHand(hand);
        pc = placeDelay.i();
    }

    boolean valid(BlockPos p, Vec3d eye) {
        var b = mc.world.getBlockState(p);
        if (!b.isOf(Blocks.OBSIDIAN) && !b.isOf(Blocks.BEDROCK)) return false;
        if (!mc.world.isAir(p.up()) || !mc.world.isAir(p.up(2))) return false;
        Vec3d c = new Vec3d(p.getX() + 0.5, p.getY() + 1, p.getZ() + 0.5);
        if (eye.distanceTo(c) > placeRange.v || mc.player.getEntityPos().distanceTo(c) < minSelf.v) return false;
        Box box = new Box(p.getX(), p.getY() + 1, p.getZ(), p.getX() + 1, p.getY() + 3, p.getZ() + 1);
        List<Entity> in = mc.world.getOtherEntities(null, box);
        return in.isEmpty();
    }

    void aim(Vec3d to) {
        if (!rotate.b) return;
        float[] r = Targets.rot(mc.player.getEyePos(), to);
        mc.player.setYaw(r[0]); mc.player.setPitch(r[1]);
    }
}
