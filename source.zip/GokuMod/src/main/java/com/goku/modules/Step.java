package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import net.minecraft.entity.attribute.EntityAttributes;

/** Walk up blocks without jumping (raises the step-height attribute client-side). */
public class Step extends Module {
    final Setting height = add(Setting.num("Height", 1.0, 0.6, 2.5, 0.1));

    public Step() { super("Step"); }

    @Override public void onTick() {
        var a = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
        if (a != null && a.getBaseValue() != height.v) a.setBaseValue(height.v);
    }

    @Override public void onDisable() {
        if (mc.player == null) return;
        var a = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
        if (a != null) a.setBaseValue(0.6);
    }
}
