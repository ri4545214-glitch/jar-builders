package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import net.minecraft.client.option.GameOptions;

public class Speed extends Module {
    final Setting mode = add(Setting.mode("Mode", 0, "Strafe", "BHop", "Ground"));
    final Setting speed = add(Setting.num("Speed (b/tick)", 0.5, 0.1, 2.0, 0.01));
    final Setting hop = add(Setting.num("Hop Height", 0.42, 0.2, 0.6, 0.01));
    final Setting sprint = add(Setting.bool("Auto Sprint", true));
    final Setting liquids = add(Setting.bool("Skip In Liquid", true));

    public Speed() { super("Speed"); }

    @Override public void onPreTick() {
        if (Modules.FREECAM.enabled || mc.currentScreen != null) return;
        if (Modules.FLY.enabled) return;
        var p = mc.player;
        if (p.getAbilities().flying || p.isGliding() || p.isClimbing() || (liquids.b && (p.isTouchingWater() || p.isInLava()))) return;
        GameOptions o = mc.options;
        double f = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
        double s = (o.leftKey.isPressed() ? 1 : 0) - (o.rightKey.isPressed() ? 1 : 0);
        if (f == 0 && s == 0) return;
        if (mode.idx == 2 && !p.isOnGround()) return;
        float yaw = p.getYaw();
        if (f != 0) {
            if (s > 0) yaw += f > 0 ? -45 : 45; else if (s < 0) yaw += f > 0 ? 45 : -45;
            s = 0; f = f > 0 ? 1 : -1;
        }
        double rad = Math.toRadians(yaw + (s != 0 ? (s > 0 ? -90 : 90) : 0));
        if (sprint.b && f > 0) p.setSprinting(true);
        double vy = p.getVelocity().y;
        if (mode.idx == 1 && p.isOnGround()) vy = hop.v;
        p.setVelocity(-Math.sin(rad) * speed.v, vy, Math.cos(rad) * speed.v);
    }
}
