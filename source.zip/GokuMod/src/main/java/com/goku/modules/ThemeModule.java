package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Draw;

public class ThemeModule extends Module {
    public final Setting mode = add(Setting.mode("Mode", 3, "Static", "Rainbow", "Pulse", "Gradient"));
    public final Setting speed = add(Setting.num("Anim Speed", 5, 1, 20, 1));
    public final Setting r = add(Setting.num("Red", 130, 0, 255, 1));
    public final Setting g = add(Setting.num("Green", 70, 0, 255, 1));
    public final Setting b = add(Setting.num("Blue", 230, 0, 255, 1));

    public ThemeModule() { super("GUI Color"); toggleable = false; open = true; }

    double t() { return (System.nanoTime() % 1_000_000_000_000L) / 1e9 * speed.v * 0.05; }
    static int scale(int rgb, double k) {
        int r = (int) (((rgb >> 16) & 255) * k), g = (int) (((rgb >> 8) & 255) * k), b = (int) ((rgb & 255) * k);
        return 0xFF000000 | (Math.min(255, r) << 16) | (Math.min(255, g) << 8) | Math.min(255, b);
    }

    public int accent() {
        int base = (r.i() << 16) | (g.i() << 8) | b.i();
        return switch (mode.idx) {
            case 1 -> 0xFF000000 | Draw.hsv((float) t());
            case 2 -> scale(base, 0.7 + 0.3 * Math.sin(t() * 8));
            default -> 0xFF000000 | base;
        };
    }

    public int accent2() {
        int base = (r.i() << 16) | (g.i() << 8) | b.i();
        return switch (mode.idx) {
            case 0 -> scale(base, 0.55);
            case 1 -> 0xFF000000 | Draw.hsv((float) t() + 0.2f);
            case 2 -> scale(base, 0.45);
            default -> 0xFF000000 | (g.i() << 16) | (b.i() << 8) | r.i();
        };
    }
}
