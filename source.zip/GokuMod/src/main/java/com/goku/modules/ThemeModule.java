package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Draw;

public class ThemeModule extends Module {
    static final String[] PRESETS = {"Custom", "Goku", "Saiyan Gold", "Ultra Instinct", "Blue God", "Crimson", "Matrix", "Ocean", "Sakura", "Rainbow"};
    //                                    r    g    b   mode
    static final int[][] COLORS = {{}, {130, 70, 230, 3}, {255, 190, 40, 2}, {190, 200, 255, 2}, {40, 140, 255, 3}, {230, 40, 70, 3}, {40, 230, 100, 3}, {20, 190, 200, 3}, {255, 120, 180, 3}, {130, 70, 230, 1}};
    public final Setting preset = add(Setting.mode("Color Preset", 1, PRESETS));
    public final Setting mode = add(Setting.mode("Mode", 3, "Static", "Rainbow", "Pulse", "Gradient"));
    public final Setting speed = add(Setting.num("Anim Speed", 5, 1, 20, 1));
    public final Setting r = add(Setting.num("Red", 130, 0, 255, 1));
    public final Setting g = add(Setting.num("Green", 70, 0, 255, 1));
    public final Setting b = add(Setting.num("Blue", 230, 0, 255, 1));

    public ThemeModule() { super("GUI Color"); toggleable = false; open = true; }

    private int last = -1, sig;

    private int signature() { return r.i() * 1000003 + g.i() * 1009 + b.i() * 7 + mode.idx; }

    /** Applies a chosen colour preset; editing the colours by hand switches the preset to "Custom". */
    public void sync() {
        if (last < 0) { last = preset.idx; sig = signature(); return; }
        if (preset.idx != last) {
            last = preset.idx;
            if (last > 0 && last < COLORS.length) { int[] c = COLORS[last]; r.v = c[0]; g.v = c[1]; b.v = c[2]; mode.idx = c[3]; }
            sig = signature();
        } else if (last > 0 && signature() != sig) { preset.idx = 0; last = 0; }
    }

    double t() { return (System.nanoTime() % 1_000_000_000_000L) / 1e9 * speed.v * 0.05; }
    static int scale(int rgb, double k) {
        int r = (int) (((rgb >> 16) & 255) * k), g = (int) (((rgb >> 8) & 255) * k), b = (int) ((rgb & 255) * k);
        return 0xFF000000 | (Math.min(255, r) << 16) | (Math.min(255, g) << 8) | Math.min(255, b);
    }

    public int accent() {
        int base = (r.i() << 16) | (g.i() << 8) | b.i();
        return switch (mode.idx) {
            case 1 -> 0xFF000000 | Draw.hsv((float) t());
            case 2 -> scale(base, 0.7 + 0.3 * Math.sin(t() * 8));
            default -> 0xFF000000 | base;
        };
    }

    public int accent2() {
        int base = (r.i() << 16) | (g.i() << 8) | b.i();
        return switch (mode.idx) {
            case 0 -> scale(base, 0.55);
            case 1 -> 0xFF000000 | Draw.hsv((float) t() + 0.2f);
            case 2 -> scale(base, 0.45);
            default -> 0xFF000000 | (g.i() << 16) | (b.i() << 8) | r.i();
        };
    }
}
