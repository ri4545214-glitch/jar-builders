package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;

public class ThemeModule extends Module {
    public final Setting r = add(Setting.num("Red", 130, 0, 255, 1));
    public final Setting g = add(Setting.num("Green", 70, 0, 255, 1));
    public final Setting b = add(Setting.num("Blue", 230, 0, 255, 1));

    public ThemeModule() { super("GUI Color"); toggleable = false; open = true; }

    public int accent() { return 0xFF000000 | (r.i() << 16) | (g.i() << 8) | b.i(); }
}
