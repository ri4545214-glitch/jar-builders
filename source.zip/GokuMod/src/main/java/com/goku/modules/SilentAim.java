package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Targets;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.List;

/**
 * Silent aim: at the start of the tick your rotation is turned to the target so the movement packet of that tick carries the aimed
 * rotation, then at the end of the tick your camera is put back. You never see the camera move; the server does.
 */
public class SilentAim extends Module {
    final Setting range = add(Setting.num("Range", 4.5, 2, 8, 0.5));
    final Setting fov = add(Setting.num("FOV", 120, 10, 360, 10));
    final Setting players = add(Setting.bool("Players", true));
    final Setting mobs = add(Setting.bool("Mobs", false));
    final Setting walls = add(Setting.bool("Through Walls", false));
    final Setting priority = add(Setting.mode("Priority", 0, "Closest", "Lowest HP", "Closest To Crosshair"));
    final Setting point = add(Setting.mode("Aim At", 0, "Head", "Chest"));
    final Setting attack = add(Setting.bool("Attack", true));
    final Setting cooldown = add(Setting.bool("Wait For Cooldown", true));
    final Setting onlyClick = add(Setting.bool("Only While Attack Key Held", false));
    float sy, sp;
    boolean aimed;
    LivingEntity tgt;

    public SilentAim() { super("Silent Aim"); }

    @Override public void onDisable() { restore(); }

    void restore() {
        if (!aimed || mc.player == null) { aimed = false; return; }
        var p = mc.player;
        p.setYaw(sy); p.setPitch(sp);
        p.lastYaw = sy; p.lastPitch = sp;         // no one-frame camera flick
        aimed = false;
    }

    float angle(LivingEntity t) {
        float[] r = Targets.rot(mc.player.getEyePos(), aimPoint(t));
        return (float) Math.hypot(Targets.wrap(r[0] - mc.player.getYaw()), r[1] - mc.player.getPitch());
    }

    Vec3d aimPoint(LivingEntity t) {
        return point.idx == 0 ? t.getEyePos() : t.getEntityPos().add(0, t.getHeight() * 0.6, 0);
    }

    @Override public void onPreTick() {
        aimed = false; tgt = null;
        if (Modules.FREECAM.enabled || mc.currentScreen != null) return;
        if (onlyClick.b && !mc.options.attackKey.isPressed()) return;
        List<LivingEntity> l = Targets.find(mc, range.v, players.b, mobs.b, walls.b);
        l.removeIf(t -> angle(t) > fov.v / 2.0);
        if (l.isEmpty()) return;
        if (priority.idx == 1) l.sort(Comparator.comparingDouble(t -> t.getHealth() + t.getAbsorptionAmount()));
        else if (priority.idx == 2) l.sort(Comparator.comparingDouble(this::angle));
        tgt = l.get(0);
        var p = mc.player;
        sy = p.getYaw(); sp = p.getPitch();
        float[] r = Targets.rot(p.getEyePos(), aimPoint(tgt));
        p.setYaw(r[0]); p.setPitch(Math.max(-90f, Math.min(90f, r[1])));
        aimed = true;
    }

    @Override public void onTick() {
        if (!aimed) return;
        if (attack.b && tgt != null && tgt.isAlive() && mc.player.distanceTo(tgt) <= range.v
                && (!cooldown.b || mc.player.getAttackCooldownProgress(0.5f) >= 1f)) {
            mc.interactionManager.attackEntity(mc.player, tgt);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
        restore();
    }
}
