package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

/** Equips the best armor from your inventory (by armor + toughness value). */
public class AutoArmor extends Module {
    final Setting delay = add(Setting.num("Delay (ticks)", 3, 0, 20, 1));
    final Setting inGui = add(Setting.bool("Only In Inventory Screen", false));
    int cd;
    static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    static final int[] MENU = {5, 6, 7, 8};   // armor slot ids in the player screen handler

    public AutoArmor() { super("Auto Armor"); }

    static EquipmentSlot slotOf(ItemStack s) {
        var eq = s.get(DataComponentTypes.EQUIPPABLE);
        return eq == null ? null : eq.slot();
    }

    static double value(ItemStack s) {
        if (s.isEmpty()) return -1;
        var attrs = s.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
        double v = 0.5;
        if (attrs != null) for (var e : attrs.modifiers()) {
            String id = e.attribute().getIdAsString();
            if (id.endsWith("armor")) v += e.modifier().value();
            else if (id.endsWith("armor_toughness")) v += e.modifier().value() * 0.5;
        }
        return v;
    }

    @Override public void onTick() {
        if (cd > 0) { cd--; return; }
        if (mc.currentScreen != null && !(mc.currentScreen instanceof net.minecraft.client.gui.screen.ingame.InventoryScreen)) return;
        if (inGui.b && mc.currentScreen == null) return;
        var inv = mc.player.getInventory();
        for (int k = 0; k < 4; k++) {
            ItemStack worn = mc.player.getEquippedStack(SLOTS[k]);
            double best = value(worn); int from = -1;
            for (int i = 0; i < 36; i++) {
                ItemStack st = inv.getStack(i);
                if (st.isEmpty() || slotOf(st) != SLOTS[k]) continue;
                double v = value(st);
                if (v > best + 0.01) { best = v; from = i; }
            }
            if (from < 0) continue;
            int sid = from < 9 ? 36 + from : from;
            int syncId = mc.player.playerScreenHandler.syncId;
            if (worn.isEmpty()) mc.interactionManager.clickSlot(syncId, sid, 0, SlotActionType.QUICK_MOVE, mc.player);
            else {                                    // swap through the armor slot: pick up, place on armor slot, put the old piece back
                mc.interactionManager.clickSlot(syncId, sid, 0, SlotActionType.PICKUP, mc.player);
                mc.interactionManager.clickSlot(syncId, MENU[k], 0, SlotActionType.PICKUP, mc.player);
                mc.interactionManager.clickSlot(syncId, sid, 0, SlotActionType.PICKUP, mc.player);
            }
            cd = delay.i();
            return;
        }
    }
}
