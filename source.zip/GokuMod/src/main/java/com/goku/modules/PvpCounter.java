package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Esp;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** HUD counters for PvP supplies (healing pots, totems, gapples, crystals, pearls, TNT minecarts...). Turns red when low. */
public class PvpCounter extends Module {
    final Setting heal = add(Setting.bool("Healing Pots", true));
    final Setting totems = add(Setting.bool("Totems", true));
    final Setting gapples = add(Setting.bool("Golden Apples", false));
    final Setting crystals = add(Setting.bool("End Crystals", false));
    final Setting pearls = add(Setting.bool("Ender Pearls", false));
    final Setting carts = add(Setting.bool("TNT Minecarts / Rails", false));
    final Setting wind = add(Setting.bool("Wind Charges", false));
    final Setting warn = add(Setting.num("Red Below", 3, 1, 10, 1));

    public PvpCounter() { super("PvP Counter"); }

    int count(Item item) {
        int n = 0;
        var inv = mc.player.getInventory();
        for (int i = 0; i < inv.size(); i++) { ItemStack s = inv.getStack(i); if (s.isOf(item)) n += s.getCount(); }
        return n;
    }

    int healPots() {
        int n = 0;
        var inv = mc.player.getInventory();
        for (int i = 0; i < inv.size(); i++) { ItemStack s = inv.getStack(i); if (s.isOf(Items.SPLASH_POTION) && AutoPot.has(s, StatusEffects.INSTANT_HEALTH)) n += s.getCount(); }
        return n;
    }

    void line(DrawContext c, String name, int n) {
        Esp.hud(c, name + ": " + n, n < warn.v ? 0xFFFF5555 : 0xFFEEEEEE);
    }

    @Override public void onRender(DrawContext c, float td) {
        if (mc.player == null) return;
        if (heal.b) line(c, "Heal Pots", healPots());
        if (totems.b) line(c, "Totems", count(Items.TOTEM_OF_UNDYING));
        if (gapples.b) line(c, "Gapples", count(Items.GOLDEN_APPLE) + count(Items.ENCHANTED_GOLDEN_APPLE));
        if (crystals.b) line(c, "Crystals", count(Items.END_CRYSTAL));
        if (pearls.b) line(c, "Pearls", count(Items.ENDER_PEARL));
        if (carts.b) { line(c, "TNT Carts", count(Items.TNT_MINECART)); line(c, "Rails", count(Items.RAIL) + count(Items.POWERED_RAIL) + count(Items.ACTIVATOR_RAIL) + count(Items.DETECTOR_RAIL)); }
        if (wind.b) line(c, "Wind Charges", count(Items.WIND_CHARGE));
    }
}
