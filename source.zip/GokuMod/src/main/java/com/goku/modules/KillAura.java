package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Targets;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;

import java.util.List;

public class KillAura extends Module {
    final Setting players = add(Setting.bool("Players", true));
    final Setting mobs = add(Setting.bool("Mobs", true));
    final Setting range = add(Setting.num("Range", 4, 1, 6, 0.1));
    final Setting maxTargets = add(Setting.num("Max Targets", 1, 1, 5, 1));
    final Setting waitCd = add(Setting.bool("Wait Cooldown", true));
    final Setting delay = add(Setting.num("Delay (ticks)", 10, 1, 20, 1));
    final Setting rotate = add(Setting.bool("Rotate", true));
    final Setting walls = add(Setting.bool("Through Walls", false));

    int ticks;

    public KillAura() { super("Kill Aura"); }

    @Override public void onTick() {
        if (mc.currentScreen != null) return;
        ticks++;
        boolean ready = waitCd.b ? mc.player.getAttackCooldownProgress(0.5f) >= 1f : ticks >= delay.i();
        if (!ready) return;
        List<LivingEntity> t = Targets.find(mc, range.v, players.b, mobs.b, walls.b);
        if (t.isEmpty()) return;
        ticks = 0;
        for (int i = 0; i < Math.min(t.size(), maxTargets.i()); i++) {
            LivingEntity e = t.get(i);
            if (rotate.b && i == 0) {
                float[] r = Targets.rot(mc.player.getEyePos(), e.getPos().add(0, e.getHeight() * 0.7, 0));
                mc.player.setYaw(r[0]); mc.player.setPitch(r[1]);
            }
            mc.interactionManager.attackEntity(mc.player, e);
        }
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
