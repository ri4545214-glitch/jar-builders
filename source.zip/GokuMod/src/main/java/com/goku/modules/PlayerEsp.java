package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Draw;
import com.goku.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;

public class PlayerEsp extends Module {
    final Setting box = add(Setting.bool("Box", true));
    final Setting name = add(Setting.bool("Name", true));
    final Setting health = add(Setting.bool("Health Bar", true));
    final Setting dist = add(Setting.bool("Distance", true));
    final Setting self = add(Setting.bool("Show Self (Freecam)", true));
    final Setting range = add(Setting.num("Range (0=inf)", 0, 0, 500, 10));
    final Setting color = add(Setting.mode("Color", 0, Draw.NAMES));

    public PlayerEsp() { super("Player ESP"); }

    @Override public void onRender(DrawContext c, float td) {
        if (!Projector.ok) return;
        int col = Draw.COLORS[color.idx];
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof PlayerEntity p) || p == mc.getCameraEntity()) continue;
            if (p == mc.player && !self.b) continue;
            double d = p.getLerpedPos(td).distanceTo(Projector.cam);
            if (range.v > 0 && d > range.v) continue;
            Box b = p.getBoundingBox().offset(p.getLerpedPos(td).subtract(p.getPos()));
            int[] r = Projector.box(b);
            if (r == null) continue;
            if (box.b) { c.fill(r[0], r[1], r[2], r[3], (col & 0xFFFFFF) | 0x22000000); Draw.outline(c, r[0], r[1], r[2], r[3], col); }
            if (health.b) {
                float f = Math.max(0, Math.min(1, p.getHealth() / p.getMaxHealth()));
                int hc = 0xFF000000 | ((int) (255 * (1 - f)) << 16) | ((int) (255 * f) << 8);
                c.fill(r[0] - 4, r[1], r[0] - 2, r[3], 0xAA000000);
                c.fill(r[0] - 4, r[3] - (int) ((r[3] - r[1]) * f), r[0] - 2, r[3], hc);
            }
            if (name.b) Draw.text(c, p.getName().getString(), (r[0] + r[2]) / 2, r[1] - 10, 0xFFFFFFFF);
            if (dist.b) Draw.text(c, (int) d + "m", (r[0] + r[2]) / 2, r[3] + 2, col);
        }
    }
}
