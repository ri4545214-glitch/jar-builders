package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;

public class SoundModule extends Module {
    public final Setting music = add(Setting.bool("Music", true));
    public final Setting track = add(Setting.mode("Track", 0, "Phonk", "Aura Phonk", "Montagem Perigosa", "Luz Roja", "Fight Back", "Shuffle"));
    /** Play the music even when the GUI is closed. */
    public final Setting keep = add(Setting.bool("Play Without GUI", false));
    public final Setting hotkey = add(Setting.bool("Hotkey: Right Ctrl", true));
    public final Setting musicVol = add(Setting.num("Music Volume", 35, 0, 100, 5));
    public final Setting musicPitch = add(Setting.num("Music Pitch", 1.0, 0.5, 1.5, 0.05));
    public final Setting sfx = add(Setting.bool("Click Sounds", true));
    public final Setting sfxVol = add(Setting.num("Sfx Volume", 70, 0, 100, 5));

    public SoundModule() { super("Sound"); toggleable = false; open = true; }
}
