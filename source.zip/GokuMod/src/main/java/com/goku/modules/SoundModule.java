package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;

public class SoundModule extends Module {
    public final Setting music = add(Setting.bool("Phonk Music", true));
    public final Setting musicVol = add(Setting.num("Music Volume", 35, 0, 100, 5));
    public final Setting musicPitch = add(Setting.num("Music Pitch", 1.0, 0.5, 1.5, 0.05));
    public final Setting keep = add(Setting.bool("Keep Playing", false));
    public final Setting sfx = add(Setting.bool("Click Sounds", true));
    public final Setting sfxVol = add(Setting.num("Sfx Volume", 70, 0, 100, 5));

    public SoundModule() { super("Sound"); toggleable = false; open = true; }
}
