package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;

/** Hover a totem in any inventory screen and it moves to the offhand / chosen hotbar slot automatically. */
public class HoverTotem extends Module {
    final Setting target = add(Setting.mode("Move To", 0, "Offhand", "Hotbar"));
    final Setting hotbarSlot = add(Setting.num("Hotbar Slot", 9, 1, 9, 1));
    final Setting replace = add(Setting.bool("Replace Offhand", false));
    final Setting delay = add(Setting.num("Delay (ticks)", 1, 0, 10, 1));
    int cd;

    public HoverTotem() { super("Hover Totem"); }

    @Override public void onTick() {
        if (cd > 0) { cd--; return; }
        if (!(mc.currentScreen instanceof HandledScreen<?> hs)) return;
        ScreenHandler h = hs.getScreenHandler();
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        int maxY = 0;
        for (Slot s : h.slots) maxY = Math.max(maxY, s.y);
        int gx = (sw - 176) / 2, gy = (sh - (maxY + 24)) / 2;   // vanilla container layout: hotbar row sits 24px above the bottom
        double mx = mc.mouse.getX() * sw / mc.getWindow().getWidth(), my = mc.mouse.getY() * sh / mc.getWindow().getHeight();
        for (Slot s : h.slots) {
            if (mx < gx + s.x - 1 || mx >= gx + s.x + 17 || my < gy + s.y - 1 || my >= gy + s.y + 17) continue;
            if (!s.getStack().isOf(Items.TOTEM_OF_UNDYING)) return;
            if (target.idx == 0) {
                if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
                if (!mc.player.getOffHandStack().isEmpty() && !replace.b) return;
                mc.interactionManager.clickSlot(h.syncId, s.id, 40, SlotActionType.SWAP, mc.player);
            } else {
                int hb = hotbarSlot.i() - 1;
                if (s.inventory == mc.player.getInventory() && s.getIndex() == hb) return;
                if (mc.player.getInventory().getStack(hb).isOf(Items.TOTEM_OF_UNDYING)) return;
                mc.interactionManager.clickSlot(h.syncId, s.id, hb, SlotActionType.SWAP, mc.player);
            }
            cd = delay.i();
            return;
        }
    }
}
