package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.AnchorOps;
import com.goku.util.Inv;
import com.goku.util.Targets;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** Places a respawn anchor in mid-air (no support block needed), charges it and blows it up. One shot per toggle unless Repeat is on. */
public class AirAnchor extends Module {
    final Setting where = add(Setting.mode("Position", 0, "Crosshair Air", "Above Target", "Beside Target", "Under Target"));
    final Setting dist = add(Setting.num("Air Distance", 4, 2, 5, 0.5));
    final Setting targetRange = add(Setting.num("Target Range", 8, 3, 16, 1));
    final Setting charges = add(Setting.num("Charges", 1, 1, 4, 1));
    final Setting placeDelay = add(Setting.num("Place Delay", 1, 1, 10, 1));
    final Setting chargeDelay = add(Setting.num("Charge Delay", 1, 0, 10, 1));
    final Setting explodeDelay = add(Setting.num("Explode Delay", 1, 0, 10, 1));
    final Setting explodeWith = add(Setting.mode("Explode With", 0, "Totem", "Any Item"));
    final Setting shield = add(Setting.bool("Shield Block", true));
    final Setting minSelf = add(Setting.num("Min Self Distance", 2.5, 1, 5, 0.5));
    final Setting minHp = add(Setting.num("Abort Below HP", 6, 0, 20, 1));
    final Setting repeat = add(Setting.bool("Repeat", false));
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    final AnchorOps.Run run = new AnchorOps.Run();
    int wait, fails;

    public AirAnchor() { super("Air Anchor"); }

    @Override public void onEnable() { fails = 0; wait = 0; }
    @Override public void onDisable() { if (mc.player != null) run.finish(swapBack.b); }

    BlockPos pick() {
        Vec3d eye = mc.player.getEyePos();
        if (where.idx == 0) {
            if (mc.crosshairTarget instanceof BlockHitResult hr && hr.getType() == HitResult.Type.BLOCK && eye.distanceTo(hr.getPos()) < dist.v)
                return hr.getBlockPos().offset(hr.getSide());
            return BlockPos.ofFloored(eye.add(mc.player.getRotationVec(1f).multiply(dist.v)));
        }
        var l = Targets.find(mc, targetRange.v, true, false, true);
        if (l.isEmpty()) return null;
        LivingEntity t = l.get(0);
        BlockPos feet = t.getBlockPos();
        return switch (where.idx) {
            case 1 -> feet.up(2);
            case 2 -> {
                Vec3d d = mc.player.getEntityPos().subtract(t.getEntityPos());
                yield Math.abs(d.x) > Math.abs(d.z) ? feet.add(d.x > 0 ? 1 : -1, 1, 0) : feet.add(0, 1, d.z > 0 ? 1 : -1);
            }
            default -> feet.down();
        };
    }

    @Override public void onTick() {
        if (Modules.FREECAM.enabled || mc.currentScreen != null) return;
        if (run.anchor != null) {
            if (!run.step(charges.i(), chargeDelay.i(), explodeDelay.i(), explodeWith.idx == 0, shield.b, 5.5, minHp.v)) {
                boolean placedOk = mc.world.getBlockState(run.anchor).isOf(net.minecraft.block.Blocks.RESPAWN_ANCHOR);
                run.finish(swapBack.b);
                wait = 6;
                if (!repeat.b) { setEnabled(false); mc.player.sendMessage(Text.literal("[Goku] Air Anchor done"), true); }
            }
            return;
        }
        if (wait > 0) { wait--; return; }
        int slot = Inv.hotbar(s -> s.isOf(Items.RESPAWN_ANCHOR));
        if (slot < 0) return;
        BlockPos p = pick();
        if (p == null || !AnchorOps.canAirPlace(p)) return;
        if (mc.player.getEyePos().distanceTo(Vec3d.ofCenter(p)) > 4.5 || mc.player.getEntityPos().distanceTo(Vec3d.ofCenter(p)) < minSelf.v) return;
        Inv.select(slot);
        AnchorOps.click(p);
        run.start(p);
        run.cd = placeDelay.i();
        if (++fails > 40) { setEnabled(false); mc.player.sendMessage(Text.literal("[Goku] Air Anchor: server refused air placing"), true); }
    }
}
