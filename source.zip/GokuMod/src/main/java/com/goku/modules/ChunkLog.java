package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Draw;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.ChunkPos;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/** Logs every chunk the camera (or freecam) passes through and shows a live loaded/unloaded chunk map. */
public class ChunkLog extends Module {
    final Setting radius = add(Setting.num("Map Radius", 7, 3, 12, 1));
    final Setting cell = add(Setting.num("Cell Size", 5, 3, 8, 1));
    final Setting corner = add(Setting.mode("Position", 0, "Top Right", "Top Left", "Bottom Right", "Bottom Left"));
    final Setting logR = add(Setting.num("Log Radius", 1, 0, 6, 1));
    final Setting showPlayer = add(Setting.bool("Show Player", true));
    final Setting export = add(Setting.bool("Export On Off", true));
    final Setting clear = add(Setting.bool("Clear Log", false));

    /** chunk key -> was it loaded when logged (true = cyan, false = red "ghost" chunk) */
    final Map<Long, Boolean> log = new LinkedHashMap<>();
    Object world;

    public ChunkLog() { super("Chunk Log"); }

    static long key(int x, int z) { return ((long) x << 32) | (z & 0xFFFFFFFFL); }

    boolean loaded(int x, int z) { return mc.world.getChunkManager().getWorldChunk(x, z) != null; }

    @Override public void onTick() {
        if (clear.b) { log.clear(); clear.b = false; }
        if (mc.world != world) { log.clear(); world = mc.world; }
        if (mc.getCameraEntity() == null) return;
        ChunkPos cp = mc.getCameraEntity().getChunkPos();
        int r = logR.i();
        for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
            int x = cp.x + dx, z = cp.z + dz;
            boolean l = loaded(x, z);
            Boolean old = log.get(key(x, z));
            if (old == null || (!old && l)) log.put(key(x, z), l);
        }
    }

    @Override public void onRender(DrawContext c, float td) {
        if (mc.getCameraEntity() == null) return;
        int accent = Modules.accent();
        ChunkPos cam = mc.getCameraEntity().getChunkPos();
        ChunkPos ply = mc.player.getChunkPos();
        int R = radius.i(), cs = cell.i(), size = (2 * R + 1) * cs;
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        boolean right = corner.idx == 0 || corner.idx == 2, bottom = corner.idx >= 2;
        int x0 = right ? sw - size - 6 : 6;
        int y0 = bottom ? sh - size - 30 : 16;

        c.fill(x0 - 2, y0 - 2, x0 + size + 2, y0 + size + 2, 0xAA000000);
        Draw.outline(c, x0 - 2, y0 - 2, x0 + size + 2, y0 + size + 2, accent);
        for (int dz = -R; dz <= R; dz++) for (int dx = -R; dx <= R; dx++) {
            int cx = cam.x + dx, cz = cam.z + dz;
            int px = x0 + (dx + R) * cs, py = y0 + (dz + R) * cs;
            c.fill(px, py, px + cs - 1, py + cs - 1, loaded(cx, cz) ? 0xCC2E8B3A : 0x66333333);
            Boolean v = log.get(key(cx, cz));
            if (v != null) c.fill(px + 1, py + 1, px + cs - 2, py + cs - 2, v ? 0xFF3DE0FF : 0xFFFF4444);
            if (dx == 0 && dz == 0) c.fill(px, py, px + cs - 1, py + cs - 1, 0xFFFFFFFF);
            else if (showPlayer.b && cx == ply.x && cz == ply.z) c.fill(px, py, px + cs - 1, py + cs - 1, 0xFF4488FF);
        }
        String st = loaded(cam.x, cam.z) ? "loaded" : "NOT LOADED";
        String t = "[" + cam.x + "," + cam.z + "] " + st + " | logged " + log.size();
        int ty = bottom ? y0 - 12 : y0 + size + 4;
        c.drawText(mc.textRenderer, t, right ? x0 + size - mc.textRenderer.getWidth(t) : x0, ty, accent, true);
    }

    @Override public void onDisable() {
        if (export.b) export();
    }

    void export() {
        if (log.isEmpty()) return;
        try {
            Path dir = FabricLoader.getInstance().getConfigDir().resolve("gokumod");
            Files.createDirectories(dir);
            StringBuilder sb = new StringBuilder("# chunkX chunkZ blockX blockZ loaded\n");
            for (var e : log.entrySet()) {
                int x = (int) (e.getKey() >> 32), z = (int) (long) e.getKey();
                sb.append(x).append(' ').append(z).append(' ').append(x * 16).append(' ').append(z * 16).append(' ').append(e.getValue()).append('\n');
            }
            Files.writeString(dir.resolve("chunklog-" + System.currentTimeMillis() / 1000 + ".txt"), sb.toString());
        } catch (Exception ignored) {}
    }
}
