package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import net.minecraft.util.math.Vec3d;

/** Flight. Velocity = full 3D control with the movement keys (Jump up, Sneak down); Creative = client-side flying ability (works only where the server allows flight); Glide = slow fall. */
public class Fly extends Module {
    final Setting mode = add(Setting.mode("Mode", 0, "Velocity", "Creative", "Glide"));
    final Setting speed = add(Setting.num("Horizontal Speed", 0.6, 0.1, 3.0, 0.05));
    final Setting vspeed = add(Setting.num("Vertical Speed", 0.4, 0.1, 2.0, 0.05));
    final Setting glideFall = add(Setting.num("Glide Fall Speed", 0.05, 0.0, 0.3, 0.01));
    final Setting hold = add(Setting.bool("Hover When Idle", true));
    boolean hadAllow, hadFly;

    public Fly() { super("Fly"); }

    @Override public void onEnable() {
        if (mc.player == null) return;
        hadAllow = mc.player.getAbilities().allowFlying; hadFly = mc.player.getAbilities().flying;
    }

    @Override public void onDisable() {
        if (mc.player == null) return;
        if (mode.idx == 1 && !mc.player.isCreative() && !mc.player.isSpectator()) {
            mc.player.getAbilities().flying = false;
            mc.player.getAbilities().allowFlying = hadAllow;
        }
    }

    @Override public void onPreTick() {
        if (Modules.FREECAM.enabled || mc.currentScreen != null) return;
        var p = mc.player;
        if (p.isGliding() || p.isSpectator()) return;
        var o = mc.options;
        if (mode.idx == 1) {
            p.getAbilities().allowFlying = true;
            p.getAbilities().flying = true;
            return;
        }
        double f = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
        double s = (o.leftKey.isPressed() ? 1 : 0) - (o.rightKey.isPressed() ? 1 : 0);
        double vy = p.getVelocity().y;
        if (mode.idx == 2) {
            if (vy < -glideFall.v) vy = -glideFall.v;
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, vy, v.z);
            return;
        }
        double up = (o.jumpKey.isPressed() ? 1 : 0) - (o.sneakKey.isPressed() ? 1 : 0);
        vy = up != 0 ? up * vspeed.v : (hold.b ? 0 : vy);
        double vx = 0, vz = 0;
        if (f != 0 || s != 0) {
            double len = Math.sqrt(f * f + s * s);
            f /= len; s /= len;
            double rad = Math.toRadians(p.getYaw());
            vx = (-Math.sin(rad) * f + Math.cos(rad) * s * -1) * speed.v;
            vz = (Math.cos(rad) * f + Math.sin(rad) * s * -1) * speed.v;
        }
        p.setVelocity(vx, vy, vz);
        p.fallDistance = 0;
    }
}
