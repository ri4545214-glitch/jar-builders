package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Targets;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class AutoAim extends Module {
    final Setting players = add(Setting.bool("Players", true));
    final Setting mobs = add(Setting.bool("Mobs", false));
    final Setting range = add(Setting.num("Range", 5, 1, 12, 0.5));
    final Setting fov = add(Setting.num("FOV", 90, 10, 360, 5));
    final Setting smooth = add(Setting.num("Smoothness", 6, 1, 20, 1));
    final Setting aim = add(Setting.mode("Aim At", 1, "Head", "Body"));
    final Setting walls = add(Setting.bool("Through Walls", false));
    final Setting needClick = add(Setting.bool("Only While Clicking", false));

    public AutoAim() { super("Auto Aim"); }

    @Override public void onTick() {
        if (mc.currentScreen != null) return;
        if (needClick.b && GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) != GLFW.GLFW_PRESS) return;
        Vec3d eye = mc.player.getEyePos();
        LivingEntity best = null; float bestDiff = 1e9f; float[] bestRot = null;
        for (LivingEntity e : Targets.find(mc, range.v, players.b, mobs.b, walls.b)) {
            Vec3d p = aim.idx == 0 ? e.getEyePos() : e.getPos().add(0, e.getHeight() / 2, 0);
            float[] r = Targets.rot(eye, p);
            float dy = Targets.wrap(r[0] - mc.player.getYaw()), dp = r[1] - mc.player.getPitch();
            float diff = (float) Math.sqrt(dy * dy + dp * dp);
            if (diff <= fov.v / 2 && diff < bestDiff) { best = e; bestDiff = diff; bestRot = r; }
        }
        if (best == null) return;
        float s = (float) smooth.v;
        mc.player.setYaw(mc.player.getYaw() + Targets.wrap(bestRot[0] - mc.player.getYaw()) / s);
        mc.player.setPitch(Math.max(-90, Math.min(90, mc.player.getPitch() + (bestRot[1] - mc.player.getPitch()) / s)));
    }
}
