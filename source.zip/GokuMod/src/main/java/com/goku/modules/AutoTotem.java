package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Inv;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/** Keeps a totem of undying in the offhand. */
public class AutoTotem extends Module {
    final Setting minHealth = add(Setting.num("Health <= (0=always)", 0, 0, 20, 1));
    final Setting delay = add(Setting.num("Delay (ticks)", 2, 0, 20, 1));
    final Setting hotbarFirst = add(Setting.bool("Prefer Hotbar", false));
    final Setting inGui = add(Setting.bool("Work In Inventory", true));
    int cd;

    public AutoTotem() { super("Auto Totem"); }

    @Override public void onTick() {
        if (cd > 0) { cd--; return; }
        if (mc.currentScreen != null && !(inGui.b && mc.currentScreen instanceof InventoryScreen)) return;
        if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        if (minHealth.v > 0 && mc.player.getHealth() + mc.player.getAbsorptionAmount() > minHealth.v) return;
        int slot = -1;
        int[] order = hotbarFirst.b ? new int[]{0, 9} : new int[]{9, 0};
        for (int o : order) {
            for (int i = o; i < o + (o == 0 ? 9 : 27) && slot < 0; i++)
                if (mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) slot = i;
            if (slot >= 0) break;
        }
        if (slot < 0) return;
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, Inv.containerSlot(slot), 40, SlotActionType.SWAP, mc.player);
        cd = delay.i();
    }
}
