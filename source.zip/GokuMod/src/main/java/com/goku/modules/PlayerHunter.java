package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Esp;
import com.goku.util.Nav;
import com.goku.util.Targets;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;

/** Finds the nearest player, runs at them and attacks. */
public class PlayerHunter extends Module {
    final Setting range = add(Setting.num("Search Range", 64, 8, 256, 8));
    final Setting attackRange = add(Setting.num("Attack Range", 3.0, 2, 6, 0.1));
    final Setting attack = add(Setting.bool("Attack", true));
    final Setting cooldown = add(Setting.bool("Wait Cooldown", true));
    final Setting aimPitch = add(Setting.bool("Aim Pitch", true));
    final Setting turn = add(Setting.num("Turn Speed", 40, 5, 180, 5));
    final Setting sprint = add(Setting.bool("Sprint", true));
    final Setting jump = add(Setting.bool("Auto Jump Obstacles", true));
    final Setting walls = add(Setting.bool("Through Walls", true));
    final Setting keepDist = add(Setting.num("Keep Distance", 2.0, 0, 5, 0.5));
    LivingEntity target;

    public PlayerHunter() { super("Player Hunter"); }

    @Override public void onDisable() { if (mc.player != null) Nav.release(); target = null; }

    @Override public void onPreTick() {
        if (mc.currentScreen != null || Modules.FREECAM.enabled) return;
        var l = Targets.find(mc, range.v, true, false, walls.b);
        target = l.isEmpty() ? null : l.get(0);
        if (target == null) { Nav.release(); return; }
        var aim = target.getBoundingBox().getCenter();
        double dist = mc.player.distanceTo(target);
        Nav.turnTo(aim, (float) turn.v, aimPitch.b);
        if (dist > keepDist.v) Nav.walk(target.getEntityPos(), sprint.b, jump.b, (float) turn.v); else Nav.release();
        if (attack.b && dist <= attackRange.v && (!cooldown.b || mc.player.getAttackCooldownProgress(0f) >= 0.95f)) {
            mc.interactionManager.attackEntity(mc.player, target);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }

    @Override public void onRender(DrawContext c, float td) {
        Esp.hud(c, "Hunter: " + (target == null ? "no player" : target.getName().getString() + " " + (int) mc.player.distanceTo(target) + "m"), Modules.accent());
    }
}
