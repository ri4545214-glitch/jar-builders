package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Esp;
import com.goku.util.Nav;
import com.goku.util.Targets;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Vec3d;

/** Walks to the nearest player or to the best Base Finder AI result. */
public class AutoFind extends Module {
    final Setting what = add(Setting.mode("Find", 0, "Nearest Player", "Base AI"));
    final Setting range = add(Setting.num("Player Range", 96, 16, 256, 8));
    final Setting stop = add(Setting.num("Stop Distance", 4, 1, 30, 1));
    final Setting sprint = add(Setting.bool("Sprint", true));
    final Setting jump = add(Setting.bool("Auto Jump Obstacles", true));
    final Setting turn = add(Setting.num("Turn Speed", 25, 5, 90, 5));
    Vec3d target;

    public AutoFind() { super("Auto Find"); }

    @Override public void onDisable() { if (mc.player != null) Nav.release(); target = null; }

    @Override public void onPreTick() {
        if (mc.currentScreen != null || Modules.FREECAM.enabled) return;
        target = null;
        if (what.idx == 0) {
            var l = Targets.find(mc, range.v, true, false, true);
            if (!l.isEmpty()) target = l.get(0).getEntityPos();
        } else target = Modules.BASE_AI.best();
        if (target == null) { Nav.release(); return; }
        if (Nav.walk(target, sprint.b, jump.b, (float) turn.v) <= stop.v) Nav.release();
    }

    @Override public void onRender(DrawContext c, float td) {
        Esp.hud(c, "Auto Find: " + (target == null ? "searching..." : (int) mc.player.getEntityPos().distanceTo(target) + "m"), Modules.accent());
    }
}
