package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Nav;

public class AutoWalk extends Module {
    final Setting sprint = add(Setting.bool("Sprint", true));
    final Setting jump = add(Setting.bool("Auto Jump Obstacles", true));
    final Setting lockDir = add(Setting.bool("Lock Direction", false));
    final Setting stopHp = add(Setting.num("Stop Below HP (0=off)", 0, 0, 20, 1));
    float yaw0;

    public AutoWalk() { super("Auto Walk"); }

    @Override public void onEnable() { if (mc.player != null) yaw0 = mc.player.getYaw(); }
    @Override public void onDisable() { if (mc.player != null) Nav.release(); }

    @Override public void onPreTick() {
        if (mc.currentScreen != null || Modules_freecam()) { return; }
        if (stopHp.v > 0 && mc.player.getHealth() <= stopHp.v) { setEnabled(false); return; }
        if (lockDir.b) mc.player.setYaw(yaw0);
        mc.options.forwardKey.setPressed(true);
        mc.options.sprintKey.setPressed(sprint.b);
        mc.options.jumpKey.setPressed(jump.b && ((mc.player.horizontalCollision && mc.player.isOnGround()) || mc.player.isTouchingWater()));
    }

    static boolean Modules_freecam() { return com.goku.Modules.FREECAM.enabled; }
}
