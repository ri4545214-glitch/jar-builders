package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Esp;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.UUID;

/**
 * Freecam with its own view angles: full 360 yaw, +-90 pitch, mouse/touch look or arrow keys,
 * the real player is not turned (nothing is sent to the server), smooth acceleration, boost, chunk log + terrain refresh.
 */
public class Freecam extends Module {
    final Setting speed = add(Setting.num("Speed", 5, 1, 40, 1));
    final Setting mode = add(Setting.mode("Mode", 0, "Free", "Orbit Player"));
    final Setting orbitDist = add(Setting.num("Orbit Distance", 6, 2, 40, 1));
    final Setting sens = add(Setting.num("Look Sens x", 1.0, 0.2, 3.0, 0.1));
    final Setting lookSmooth = add(Setting.num("Look Smoothing", 0, 0, 10, 1));
    final Setting loadRadius = add(Setting.num("Load Chunks (radius)", 10, 2, 32, 1));
    final Setting boost = add(Setting.num("Boost x (Ctrl)", 3, 1, 8, 1));
    final Setting smooth = add(Setting.num("Smoothing", 4, 0, 10, 1));
    final Setting vertical = add(Setting.bool("Space/Shift Up-Down", true));
    final Setting moveMode = add(Setting.mode("Move", 0, "Look", "Flat"));
    final Setting arrows = add(Setting.bool("Arrow Keys Look", true));
    final Setting arrowSpeed = add(Setting.num("Arrow Turn Speed", 120, 30, 300, 10));
    final Setting lock = add(Setting.bool("Lock Player Rot", true));
    final Setting noClicks = add(Setting.bool("Block Clicks", true));
    final Setting autoLoad = add(Setting.bool("Refresh Terrain", true));
    final Setting autoLog = add(Setting.bool("Auto Chunk Log", true));
    final Setting info = add(Setting.bool("Info Overlay", true));

    OtherClientPlayerEntity cam;
    double x, y, z, vx, vy, vz;
    float yaw, pitch, rYaw, rPitch, lockYaw, lockPitch, origPitch;
    long last;
    int lastCx, lastCz, still;
    Vec3d lastPlayerPos = Vec3d.ZERO;
    boolean startedLog;
    int prevView = -1;

    public Freecam() { super("Freecam"); }

    @Override public void onEnable() {
        if (mc.player == null || mc.world == null) { enabled = false; return; }
        Vec3d eye = mc.player.getEyePos();
        x = eye.x; y = eye.y - 1.62; z = eye.z; vx = vy = vz = 0;
        yaw = mc.player.getYaw(); pitch = mc.player.getPitch(); rYaw = yaw; rPitch = pitch;
        lockYaw = yaw; origPitch = pitch; lockPitch = Math.max(-30f, Math.min(30f, pitch));
        cam = new OtherClientPlayerEntity(mc.world, new GameProfile(UUID.randomUUID(), "Freecam"));
        cam.refreshPositionAndAngles(x, y, z, yaw, pitch);
        mc.world.addEntity(cam);
        mc.setCameraEntity(cam);
        lastPlayerPos = mc.player.getEntityPos();
        lastCx = (int) Math.floor(x) >> 4; lastCz = (int) Math.floor(z) >> 4;
        last = System.nanoTime();
        startedLog = false;
        // ask the server for more chunks around us: view distance is what the server uses to decide how far to send
        prevView = mc.options.getViewDistance().getValue();
        if (prevView < loadRadius.i()) { mc.options.getViewDistance().setValue(loadRadius.i()); mc.options.sendClientSettings(); mc.worldRenderer.scheduleTerrainUpdate(); }
        else prevView = -1;
        if (autoLog.b && !Modules.CHUNK_LOG.enabled) { Modules.CHUNK_LOG.setEnabled(true); startedLog = true; }
    }

    @Override public void onDisable() {
        if (mc.player != null) {
            mc.setCameraEntity(mc.player);
            if (lock.b) { mc.player.setYaw(lockYaw); mc.player.setPitch(origPitch); }
        }
        if (cam != null && mc.world != null) mc.world.removeEntity(cam.getId(), Entity.RemovalReason.DISCARDED);
        cam = null;
        if (prevView > 0) { mc.options.getViewDistance().setValue(prevView); mc.options.sendClientSettings(); }
        prevView = -1;
        KeyBinding.updatePressedStates();
        if (startedLog) Modules.CHUNK_LOG.setEnabled(false);
        startedLog = false;
    }

    /** Called by EntityMixin with the raw mouse/touch delta. Returns true when the camera consumed it. */
    public boolean turn(double dx, double dy) {
        if (cam == null || !lock.b) return false;
        yaw += (float) (dx * 0.15 * sens.v);
        pitch = Math.max(-90f, Math.min(90f, pitch + (float) (dy * 0.15 * sens.v)));
        return true;
    }

    /** Runs before the player tick: the real player must not walk or click while the camera flies. */
    @Override public void onPreTick() {
        GameOptions o = mc.options;
        for (KeyBinding k : new KeyBinding[]{o.forwardKey, o.backKey, o.leftKey, o.rightKey, o.jumpKey, o.sneakKey, o.sprintKey})
            k.setPressed(false);
        if (noClicks.b) { o.attackKey.setPressed(false); o.useKey.setPressed(false); }
    }

    @Override public void onTick() {
        if (cam == null) return;
        if (mc.player.getEntityPos().squaredDistanceTo(lastPlayerPos) < 1e-4) still++; else still = 0;
        lastPlayerPos = mc.player.getEntityPos();
        int cx = (int) Math.floor(x) >> 4, cz = (int) Math.floor(z) >> 4;
        boolean moved = cx != lastCx || cz != lastCz;
        lastCx = cx; lastCz = cz;
        // The client can only show chunks the server sent; re-mesh whenever the camera enters a new chunk or while idle.
        if (autoLoad.b && (moved || (still > 20 && still % 20 == 0))) mc.worldRenderer.scheduleTerrainUpdate();
    }

    @Override public void onRender(DrawContext ctx, float td) {
        if (cam == null) return;
        long now = System.nanoTime();
        double dt = Math.min((now - last) / 1e9, 0.1);
        last = now;
        long h = mc.getWindow().getHandle();

        // --- look: the game applies mouse/touch deltas to the player (and possibly the camera entity); move them onto our own angles
        if (lock.b) {
            float dyaw = (mc.player.getYaw() - lockYaw) + (cam.getYaw() - rYaw);
            float dpitch = (mc.player.getPitch() - lockPitch) + (cam.getPitch() - rPitch);
            yaw += dyaw * (float) sens.v; pitch += dpitch * (float) sens.v;
            mc.player.setYaw(lockYaw); mc.player.setPitch(lockPitch);
        } else {
            yaw = mc.player.getYaw(); pitch = mc.player.getPitch();
        }
        if (mc.currentScreen == null && arrows.b) {
            float s = (float) (arrowSpeed.v * dt);
            if (down(h, GLFW.GLFW_KEY_LEFT)) yaw -= s;
            if (down(h, GLFW.GLFW_KEY_RIGHT)) yaw += s;
            if (down(h, GLFW.GLFW_KEY_UP)) pitch -= s;
            if (down(h, GLFW.GLFW_KEY_DOWN)) pitch += s;
        }
        pitch = Math.max(-90f, Math.min(90f, pitch));
        double lk = lookSmooth.v <= 0 ? 1 : 1 - Math.exp(-dt * 40.0 / lookSmooth.v);
        rYaw += (yaw - rYaw) * (float) lk; rPitch += (pitch - rPitch) * (float) lk;
        if (mode.idx == 1) {   // orbit: circle the real player, full 360 around and above/below
            Vec3d f = Vec3d.fromPolar(rPitch, rYaw), t = mc.player.getEyePos();
            x = t.x - f.x * orbitDist.v; y = t.y - f.y * orbitDist.v - 1.62; z = t.z - f.z * orbitDist.v;
            vx = vy = vz = 0;
            cam.refreshPositionAndAngles(x, y, z, rYaw, rPitch);
            hud(ctx);
            return;
        }

        // --- move
        double dx = 0, dy = 0, dz = 0;
        if (mc.currentScreen == null) {
            Vec3d f = Vec3d.fromPolar(moveMode.idx == 0 ? rPitch : 0f, rYaw);
            double yr = Math.toRadians(rYaw);
            Vec3d r = new Vec3d(-Math.cos(yr), 0, -Math.sin(yr));
            if (down(h, GLFW.GLFW_KEY_W)) { dx += f.x; dy += f.y; dz += f.z; }
            if (down(h, GLFW.GLFW_KEY_S)) { dx -= f.x; dy -= f.y; dz -= f.z; }
            if (down(h, GLFW.GLFW_KEY_D)) { dx += r.x; dz += r.z; }
            if (down(h, GLFW.GLFW_KEY_A)) { dx -= r.x; dz -= r.z; }
            if (vertical.b) {
                if (down(h, GLFW.GLFW_KEY_SPACE)) dy += 1;
                if (down(h, GLFW.GLFW_KEY_LEFT_SHIFT)) dy -= 1;
            }
        }
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double top = speed.v * 2.0 * (down(h, GLFW.GLFW_KEY_LEFT_CONTROL) ? boost.v : 1.0);
        double tx = 0, ty = 0, tz = 0;
        if (len > 0) { tx = dx / len * top; ty = dy / len * top; tz = dz / len * top; }
        double k = smooth.v <= 0 ? 1 : 1 - Math.exp(-dt * 30.0 / smooth.v);
        vx += (tx - vx) * k; vy += (ty - vy) * k; vz += (tz - vz) * k;
        x += vx * dt; y += vy * dt; z += vz * dt;
        cam.refreshPositionAndAngles(x, y, z, rYaw, rPitch);
        hud(ctx);
    }

    void hud(DrawContext ctx) {
        if (info.b) {
            int cx = (int) Math.floor(x) >> 4, cz = (int) Math.floor(z) >> 4;
            boolean ok = mc.world.getChunkManager().getWorldChunk(cx, cz) != null;
            Esp.hud(ctx, String.format("Freecam  %.1f %.1f %.1f  chunk [%d,%d]%s", x, y, z, cx, cz, ok ? "" : "  NOT LOADED"), Modules.accent());
        }
    }

    static boolean down(long h, int key) { return GLFW.glfwGetKey(h, key) == GLFW.GLFW_PRESS; }
}
