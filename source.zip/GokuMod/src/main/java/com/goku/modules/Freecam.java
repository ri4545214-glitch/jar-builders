package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.UUID;

public class Freecam extends Module {
    final Setting speed = add(Setting.num("Speed", 5, 1, 30, 1));
    final Setting vertical = add(Setting.bool("Space/Shift Up-Down", true));
    final Setting autoLoad = add(Setting.bool("Auto Load Chunks (still)", true));

    OtherClientPlayerEntity cam;
    double x, y, z;
    long last;
    Vec3d lastPlayerPos = Vec3d.ZERO;
    int still;

    public Freecam() { super("Freecam"); }

    @Override public void onEnable() {
        if (mc.player == null || mc.world == null) { enabled = false; return; }
        Vec3d eye = mc.player.getEyePos();
        x = eye.x; y = eye.y - 1.62; z = eye.z;
        cam = new OtherClientPlayerEntity(mc.world, new GameProfile(UUID.randomUUID(), "Freecam"));
        cam.refreshPositionAndAngles(x, y, z, mc.player.getYaw(), mc.player.getPitch());
        mc.world.addEntity(cam);
        mc.setCameraEntity(cam);
        lastPlayerPos = mc.player.getEntityPos();
        last = System.nanoTime();
    }

    @Override public void onDisable() {
        if (mc.player != null) mc.setCameraEntity(mc.player);
        if (cam != null && mc.world != null) mc.world.removeEntity(cam.getId(), Entity.RemovalReason.DISCARDED);
        cam = null;
        KeyBinding.updatePressedStates();
    }

    /** Runs before the player tick: stop the real player from walking while the camera flies. */
    @Override public void onPreTick() {
        GameOptions o = mc.options;
        for (KeyBinding k : new KeyBinding[]{o.forwardKey, o.backKey, o.leftKey, o.rightKey, o.jumpKey, o.sneakKey, o.sprintKey})
            k.setPressed(false);
    }

    @Override public void onTick() {
        if (cam == null) return;
        if (mc.player.getEntityPos().squaredDistanceTo(lastPlayerPos) < 1e-4) still++; else still = 0;
        lastPlayerPos = mc.player.getEntityPos();
        // The client can only render chunks the server sent; this just keeps meshing fresh while you stand still.
        if (autoLoad.b && still > 20 && still % 20 == 0) mc.worldRenderer.scheduleTerrainUpdate();
    }

    @Override public void onRender(DrawContext ctx, float td) {
        if (cam == null) return;
        long now = System.nanoTime();
        double dt = Math.min((now - last) / 1e9, 0.1);
        last = now;
        float yaw = mc.player.getYaw(), pitch = mc.player.getPitch();
        if (mc.currentScreen == null) {
            long h = mc.getWindow().getHandle();
            Vec3d f = Vec3d.fromPolar(pitch, yaw);
            double yr = Math.toRadians(yaw);
            Vec3d r = new Vec3d(-Math.cos(yr), 0, -Math.sin(yr));
            double dx = 0, dy = 0, dz = 0;
            if (down(h, GLFW.GLFW_KEY_W)) { dx += f.x; dy += f.y; dz += f.z; }
            if (down(h, GLFW.GLFW_KEY_S)) { dx -= f.x; dy -= f.y; dz -= f.z; }
            if (down(h, GLFW.GLFW_KEY_D)) { dx += r.x; dz += r.z; }
            if (down(h, GLFW.GLFW_KEY_A)) { dx -= r.x; dz -= r.z; }
            if (vertical.b) {
                if (down(h, GLFW.GLFW_KEY_SPACE)) dy += 1;
                if (down(h, GLFW.GLFW_KEY_LEFT_SHIFT)) dy -= 1;
            }
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (len > 0) {
                double s = speed.v * 2.0 * dt / len;
                x += dx * s; y += dy * s; z += dz * s;
            }
        }
        cam.refreshPositionAndAngles(x, y, z, yaw, pitch);
    }

    static boolean down(long h, int key) { return GLFW.glfwGetKey(h, key) == GLFW.GLFW_PRESS; }
}
