package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Esp;
import com.goku.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.vehicle.ChestMinecartEntity;
import net.minecraft.entity.vehicle.HopperMinecartEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Entity Finder: stash entities that block ESPs can't see (minecarts, item frames, dropped loot, villager halls). */
public class EntityEsp extends Module {
    final Setting items = add(Setting.bool("Dropped Items", true));
    final Setting minStack = add(Setting.num("Min Stack", 1, 1, 64, 1));
    final Setting frames = add(Setting.bool("Item Frames", true));
    final Setting carts = add(Setting.bool("Storage Minecarts", true));
    final Setting stands = add(Setting.bool("Armor Stands", false));
    final Setting villagers = add(Setting.bool("Villagers", false));
    final Setting style = add(Setting.mode("Box Style", 1, Esp.STYLES));
    final Setting fill = add(Setting.bool("Fill", true));
    final Setting tracers = add(Setting.bool("Tracers", false));
    final Setting origin = add(Setting.mode("Tracer From", 0, Esp.ORIGINS));
    final Setting range = add(Setting.num("Range (0=inf)", 64, 0, 500, 10));

    public EntityEsp() { super("Entity Finder"); }

    @Override public void onRender(DrawContext c, float td) {
        if (!Projector.ok) return;
        int shown = 0;
        for (Entity e : mc.world.getEntities()) {
            String label; int col;
            if (e instanceof ItemEntity ie) {
                int n = ie.getStack().getCount();
                if (!items.b || n < minStack.i()) continue;
                label = ie.getStack().getName().getString() + " x" + n; col = 0xFFFFEE44;
            } else if (e instanceof ItemFrameEntity f) {
                if (!frames.b) continue;
                label = f.getHeldItemStack().isEmpty() ? "Item Frame" : "Frame: " + f.getHeldItemStack().getName().getString(); col = 0xFFFF9933;
            } else if (e instanceof ChestMinecartEntity) {
                if (!carts.b) continue; label = "Chest Minecart"; col = 0xFFFF4444;
            } else if (e instanceof HopperMinecartEntity) {
                if (!carts.b) continue; label = "Hopper Minecart"; col = 0xFFBBBBBB;
            } else if (e instanceof ArmorStandEntity) {
                if (!stands.b) continue; label = "Armor Stand"; col = 0xFF44FFFF;
            } else if (e instanceof VillagerEntity) {
                if (!villagers.b) continue; label = "Villager"; col = 0xFF66EE88;
            } else continue;

            Vec3d lp = e.getLerpedPos(td);
            double dist = lp.distanceTo(Projector.cam);
            if (range.v > 0 && dist > range.v) continue;
            Box b = e.getBoundingBox().offset(lp.subtract(e.getEntityPos()));
            int fc = Esp.fade(col, dist, range.v);
            Esp.box(c, b, fc, style.idx, fill.b, 1);
            if (tracers.b) Esp.tracer(c, b.getCenter(), fc, origin.idx, 1);
            double[] p = Projector.to(new Vec3d(b.getCenter().x, b.maxY + 0.2, b.getCenter().z));
            if (p != null) Esp.label(c, label + " " + (int) dist + "m", (int) p[0], (int) p[1] - 11, fc);
            shown++;
        }
        if (shown > 0) Esp.hud(c, "Entity Finder: " + shown, Modules.accent());
    }
}
