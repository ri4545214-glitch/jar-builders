package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Draw;
import com.goku.util.Esp;
import com.goku.util.Projector;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.enums.ChestType;
import net.minecraft.block.entity.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Scores every loaded chunk by weighted player-placed block entities and outlines the whole chunk column when it passes the threshold. */
public class SusChunk extends Module {
    final Setting threshold = add(Setting.num("Min Score", 6, 2, 60, 1));
    final Setting containers = add(Setting.bool("Containers", true));
    final Setting utility = add(Setting.bool("Furnaces/Hoppers", true));
    final Setting signs = add(Setting.bool("Signs", false));
    final Setting beds = add(Setting.bool("Beds", true));
    final Setting spawners = add(Setting.bool("Count Spawners", false));
    final Setting style = add(Setting.mode("Box Style", 1, Esp.STYLES));
    final Setting fill = add(Setting.bool("Fill", true));
    final Setting labels = add(Setting.bool("Labels", true));
    final Setting tracers = add(Setting.bool("Tracers", false));
    final Setting origin = add(Setting.mode("Tracer From", 0, Esp.ORIGINS));
    final Setting range = add(Setting.num("Range (0=all)", 0, 0, 1000, 10));
    final Setting color = add(Setting.mode("Color", 3, Draw.NAMES));
    final Setting list = add(Setting.bool("Top List HUD", true));

    record Sus(ChunkPos pos, double score, Box box, Vec3d center) {}
    List<Sus> sus = List.of();

    public SusChunk() { super("Sus Chunk"); }

    @Override public void onEnable() { if (mc.player != null && mc.world != null) scan(); }

    @Override public void onTick() { if (mc.player.age % 20 == 0) scan(); }

    double weight(BlockEntity be) {
        if (containers.b) {
            if (be instanceof ChestBlockEntity) {
                var s = be.getCachedState();
                boolean dbl = s.contains(ChestBlock.CHEST_TYPE) && s.get(ChestBlock.CHEST_TYPE) != ChestType.SINGLE;
                return dbl ? 0.5 : 1;                      // a double chest is two block entities
            }
            if (be instanceof BarrelBlockEntity) return 1;
            if (be instanceof ShulkerBoxBlockEntity) return 2;
            if (be instanceof EnderChestBlockEntity) return 0.5;
        }
        if (utility.b) {
            if (be instanceof HopperBlockEntity) return 1.5;
            if (be instanceof AbstractFurnaceBlockEntity || be instanceof DispenserBlockEntity || be instanceof BrewingStandBlockEntity) return 1;
        }
        if (signs.b && be instanceof SignBlockEntity) return 0.5;
        if (beds.b && be instanceof BedBlockEntity) return 0.5;     // two halves per bed
        if (spawners.b && be instanceof MobSpawnerBlockEntity) return 3;
        return 0;
    }

    void scan() {
        List<Sus> out = new ArrayList<>();
        if (mc.getCameraEntity() == null) return;
        ChunkPos cp = mc.getCameraEntity().getChunkPos();
        int vd = mc.options.getViewDistance().getValue() + 2;
        for (int dx = -vd; dx <= vd; dx++) for (int dz = -vd; dz <= vd; dz++) {
            WorldChunk ch = mc.world.getChunkManager().getWorldChunk(cp.x + dx, cp.z + dz);
            if (ch == null) continue;
            double score = 0; int minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
            for (BlockEntity be : ch.getBlockEntities().values()) {
                double w = weight(be);
                if (w <= 0) continue;
                score += w; minY = Math.min(minY, be.getPos().getY()); maxY = Math.max(maxY, be.getPos().getY());
            }
            if (score < threshold.v) continue;
            ChunkPos p = ch.getPos();
            Box box = new Box(p.getStartX(), minY, p.getStartZ(), p.getStartX() + 16, maxY + 1, p.getStartZ() + 16);
            out.add(new Sus(p, score, box, box.getCenter()));
        }
        out.sort(Comparator.comparingDouble((Sus s) -> -s.score));
        sus = out;
    }

    @Override public void onRender(DrawContext c, float td) {
        if (!Projector.ok) return;
        int col = Draw.COLORS[color.idx];
        if (list.b) {
            Esp.hud(c, "Sus chunks: " + sus.size(), col);
            for (int i = 0; i < Math.min(3, sus.size()); i++) {
                Sus s = sus.get(i);
                Esp.hud(c, " [" + s.pos.x + "," + s.pos.z + "] score " + (int) s.score + "  @ " + s.pos.getStartX() + "," + s.pos.getStartZ(), col);
            }
        }
        for (Sus s : sus) {
            double dist = s.center.distanceTo(Projector.cam);
            if (range.v > 0 && dist > range.v) continue;
            int cl = Esp.fade(col, dist, range.v > 0 ? range.v : 400);
            Esp.box(c, s.box, cl, style.idx, fill.b, 1);
            if (tracers.b) Esp.tracer(c, s.center, cl, origin.idx, 1);
            if (labels.b) {
                double[] p = Projector.to(new Vec3d(s.center.x, s.box.maxY + 0.5, s.center.z));
                if (p != null) Esp.label(c, "SUS [" + s.pos.x + "," + s.pos.z + "] " + (int) s.score + "  " + (int) dist + "m", (int) p[0], (int) p[1] - 11, cl);
            }
        }
    }

    @Override public void onDisable() { sus = List.of(); }
}
