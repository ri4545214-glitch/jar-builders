package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Draw;
import com.goku.util.Projector;
import net.minecraft.block.entity.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.List;

/** Flags chunks holding unusually many player-placed block entities (bases / stashes). */
public class SusChunk extends Module {
    final Setting threshold = add(Setting.num("Threshold", 6, 2, 40, 1));
    final Setting containers = add(Setting.bool("Containers", true));
    final Setting signs = add(Setting.bool("Signs", false));
    final Setting beds = add(Setting.bool("Beds", false));
    final Setting range = add(Setting.num("Range (0=all)", 0, 0, 1000, 10));
    final Setting color = add(Setting.mode("Color", 3, Draw.NAMES));
    final Setting list = add(Setting.bool("Count Overlay", true));

    record Sus(ChunkPos pos, int count, Vec3d center) {}
    List<Sus> sus = List.of();

    public SusChunk() { super("Sus Chunk"); }

    @Override public void onTick() {
        if (mc.player.age % 40 != 0) return;
        List<Sus> out = new ArrayList<>();
        ChunkPos cp = mc.getCameraEntity().getChunkPos();
        int vd = mc.options.getViewDistance().getValue() + 2;
        for (int dx = -vd; dx <= vd; dx++) for (int dz = -vd; dz <= vd; dz++) {
            WorldChunk ch = mc.world.getChunkManager().getWorldChunk(cp.x + dx, cp.z + dz);
            if (ch == null) continue;
            int n = 0; double sx = 0, sy = 0, sz = 0;
            for (BlockEntity be : ch.getBlockEntities().values()) {
                boolean hit = (containers.b && (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity
                        || be instanceof HopperBlockEntity || be instanceof ShulkerBoxBlockEntity
                        || be instanceof AbstractFurnaceBlockEntity || be instanceof DispenserBlockEntity
                        || be instanceof EnderChestBlockEntity))
                        || (signs.b && be instanceof SignBlockEntity) || (beds.b && be instanceof BedBlockEntity);
                if (!hit) continue;
                n++; sx += be.getPos().getX() + .5; sy += be.getPos().getY() + .5; sz += be.getPos().getZ() + .5;
            }
            if (n >= threshold.i()) out.add(new Sus(ch.getPos(), n, new Vec3d(sx / n, sy / n, sz / n)));
        }
        sus = out;
    }

    @Override public void onRender(DrawContext c, float td) {
        if (!Projector.ok) return;
        int col = Draw.COLORS[color.idx];
        if (list.b) c.drawText(mc.textRenderer, "Sus chunks: " + sus.size(), 4, 4, col, true);
        for (Sus s : sus) {
            double dist = s.center.distanceTo(Projector.cam);
            if (range.v > 0 && dist > range.v) continue;
            double[] p = Projector.to(s.center);
            if (p == null) continue;
            int x = (int) p[0], y = (int) p[1];
            c.fill(x - 3, y - 3, x + 3, y + 3, col);
            Draw.text(c, "SUS [" + s.pos.x + "," + s.pos.z + "] x" + s.count + " " + (int) dist + "m", x, y - 14, col);
        }
    }

    @Override public void onDisable() { sus = List.of(); }
}
