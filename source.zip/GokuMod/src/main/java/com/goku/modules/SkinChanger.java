package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.skin.SkinFetch;
import com.goku.skin.SkinOverride;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Local skin / cape changer: you see the skin or cape of any Minecraft account name (looked up from Mojang), nobody else does.
 * The library lives in config/gokumod/skins.json: {"skins": ["Notch"], "capes": ["jeb_"]}.
 */
public class SkinChanger extends Module {
    static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    static final String OFF = "(keep mine)";

    final Setting skin = add(Setting.mode("Skin", 0, OFF));
    final Setting cape = add(Setting.mode("Cape", 0, OFF));
    final Setting reload = add(Setting.bool("> Reload Library + Apply", false));

    private final List<String> skins = new ArrayList<>(), capes = new ArrayList<>();
    private int lastSkin = -1, lastCape = -1;
    private Identifier skinId, capeId;
    private boolean slim;

    public SkinChanger() { super("Skin & Cape (Local)"); loadLibrary(); }

    static Path file() { return com.goku.Config.dir().resolve("skins.json"); }

    private void loadLibrary() {
        skins.clear(); capes.clear();
        try {
            Path f = file();
            if (!Files.exists(f)) {
                Files.createDirectories(f.getParent());
                JsonObject o = new JsonObject();
                JsonArray s = new JsonArray(), c = new JsonArray();
                s.add("Notch"); s.add("jeb_"); c.add("jeb_");
                o.add("skins", s); o.add("capes", c);
                Files.writeString(f, GSON.toJson(o));
            }
            JsonObject o = GSON.fromJson(Files.readString(f), JsonObject.class);
            if (o.has("skins")) for (var e : o.getAsJsonArray("skins")) skins.add(e.getAsString().replaceAll("[^A-Za-z0-9_]", ""));
            if (o.has("capes")) for (var e : o.getAsJsonArray("capes")) capes.add(e.getAsString().replaceAll("[^A-Za-z0-9_]", ""));
        } catch (Exception ignored) {}
        rebuildModes();
    }

    private void rebuildModes() {
        String curS = skin.idx > 0 && skin.idx < skin.modes.length ? skin.modes[skin.idx] : null;
        String curC = cape.idx > 0 && cape.idx < cape.modes.length ? cape.modes[cape.idx] : null;
        skin.modes = new String[skins.size() + 1]; skin.modes[0] = OFF;
        for (int i = 0; i < skins.size(); i++) skin.modes[i + 1] = skins.get(i);
        cape.modes = new String[capes.size() + 1]; cape.modes[0] = OFF;
        for (int i = 0; i < capes.size(); i++) cape.modes[i + 1] = capes.get(i);
        skin.idx = curS == null ? 0 : Math.max(0, skins.indexOf(curS) + 1);
        cape.idx = curC == null ? 0 : Math.max(0, capes.indexOf(curC) + 1);
    }

    // ---- API used by the Manager GUI
    public List<String> skinList() { return skins; }
    public List<String> capeList() { return capes; }
    public String currentSkin() { return skin.idx == 0 ? null : skin.modeName(); }
    public String currentCape() { return cape.idx == 0 ? null : cape.modeName(); }

    private static String clean(String n) { return n == null ? "" : n.replaceAll("[^A-Za-z0-9_]", ""); }

    private void saveLibrary() {
        try {
            JsonObject o = new JsonObject();
            JsonArray s = new JsonArray(), c = new JsonArray();
            for (String x : skins) s.add(x);
            for (String x : capes) c.add(x);
            o.add("skins", s); o.add("capes", c);
            Files.createDirectories(file().getParent());
            Files.writeString(file(), GSON.toJson(o));
        } catch (Exception ignored) {}
    }

    public boolean addEntry(boolean isCape, String name) {
        String n = clean(name);
        List<String> l = isCape ? capes : skins;
        if (n.isEmpty() || n.length() > 16) return false;
        for (String x : l) if (x.equalsIgnoreCase(n)) return false;
        l.add(n); saveLibrary(); rebuildModes();
        return true;
    }

    public void removeEntry(boolean isCape, String name) {
        (isCape ? capes : skins).remove(name); saveLibrary(); rebuildModes();
    }

    /** Wear this skin/cape (null = keep mine). Switches the module on when something is picked. */
    public void use(boolean isCape, String name) {
        Setting st = isCape ? cape : skin;
        List<String> l = isCape ? capes : skins;
        st.idx = name == null ? 0 : Math.max(0, l.indexOf(name) + 1);
        if (name != null && !enabled) setEnabled(true);
    }

    private void msg(String s) { if (mc.player != null) mc.execute(() -> mc.player.sendMessage(Text.literal("[Goku] " + s), false)); }

    private void apply() {
        lastSkin = skin.idx; lastCape = cape.idx;
        SkinOverride.active = true;
        if (skin.idx == 0) { skinId = null; SkinOverride.skin = null; }
        else {
            String n = skin.modeName();
            SkinFetch.load(n, l -> { skinId = l.skin(); slim = l.slim(); SkinOverride.skin = skinId; SkinOverride.slim = slim; msg("Skin: " + n); },
                    err -> msg("Skin '" + n + "' failed: " + err));
        }
        if (cape.idx == 0) { capeId = null; SkinOverride.cape = null; }
        else {
            String n = cape.modeName();
            SkinFetch.load(n, l -> { capeId = l.cape(); SkinOverride.cape = capeId; msg(capeId == null ? "'" + n + "' has no cape" : "Cape: " + n); },
                    err -> msg("Cape '" + n + "' failed: " + err));
        }
    }

    @Override public void onEnable() { loadLibrary(); apply(); }

    @Override public void onDisable() { SkinOverride.active = false; SkinOverride.skin = null; SkinOverride.cape = null; }

    private boolean warned;

    @Override public void onTick() {
        if (reload.b) { reload.b = false; loadLibrary(); apply(); }
        else if (skin.idx != lastSkin || cape.idx != lastCape) apply();
        if (!warned && SkinOverride.problem != null) { warned = true; msg("Skin override not supported on this version: " + SkinOverride.problem); }
    }
}
