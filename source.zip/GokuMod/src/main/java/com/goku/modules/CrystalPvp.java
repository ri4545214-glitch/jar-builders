package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Esp;
import com.goku.util.Inv;
import com.goku.util.Targets;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Difficulty;
import net.minecraft.world.RaycastContext;

import java.util.List;

/**
 * Crystal PvP suite: damage-calculated placing and breaking (target damage vs. self damage with block exposure, armor and difficulty),
 * face-place when the target is low, anti-suicide, lethal priority, auto switch / offhand, obsidian surround, eating pause.
 */
public class CrystalPvp extends Module {
    final Setting targetRange = add(Setting.num("Target Range", 10, 3, 16, 1));
    final Setting priority = add(Setting.mode("Target Priority", 0, "Closest", "Lowest HP"));
    final Setting place = add(Setting.bool("Place", true));
    final Setting breakC = add(Setting.bool("Break", true));
    final Setting placeRange = add(Setting.num("Place Range", 4.5, 2, 6, 0.5));
    final Setting breakRange = add(Setting.num("Break Range", 4.5, 2, 6, 0.5));
    final Setting minDmg = add(Setting.num("Min Target Dmg", 5, 1, 20, 1));
    final Setting maxSelf = add(Setting.num("Max Self Dmg", 6, 1, 20, 1));
    final Setting faceHp = add(Setting.num("Face Place HP", 8, 0, 20, 1));
    final Setting suicide = add(Setting.num("Anti-Suicide HP", 4, 1, 20, 1));
    final Setting placeDelay = add(Setting.num("Place Delay", 1, 0, 10, 1));
    final Setting breakDelay = add(Setting.num("Break Delay", 0, 0, 10, 1));
    final Setting autoSwitch = add(Setting.bool("Auto Switch", true));
    final Setting switchBack = add(Setting.bool("Switch Back", false));
    final Setting rotate = add(Setting.bool("Rotate", false));
    final Setting breakAny = add(Setting.bool("Break Any Safe Crystal", false));
    final Setting pauseEat = add(Setting.bool("Pause When Eating", true));
    final Setting surround = add(Setting.bool("Obsidian Surround", false));
    final Setting surroundDelay = add(Setting.num("Surround Delay", 1, 0, 6, 1));
    final Setting info = add(Setting.bool("Info HUD", true));
    int pc, bc, sc;
    public int lastBreak = -100;
    public EndCrystalEntity lastCrystal;
    LivingEntity target;
    double lastDmg;

    public CrystalPvp() { super("Crystal PvP"); }

    // ---- damage model
    double exposure(Vec3d from, LivingEntity e) {
        Box b = e.getBoundingBox();
        double[] xs = {b.minX, b.maxX}, ys = {b.minY, (b.minY + b.maxY) / 2, b.maxY}, zs = {b.minZ, b.maxZ};
        int vis = 0, tot = 0;
        for (double x : xs) for (double y : ys) for (double z : zs) {
            tot++;
            var hit = mc.world.raycast(new RaycastContext(from, new Vec3d(x, y, z), RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, e));
            if (hit.getType() == HitResult.Type.MISS) vis++;
        }
        return vis / (double) tot;
    }

    double damage(LivingEntity e, Vec3d c, boolean checkExposure) {
        double dist = e.getEntityPos().distanceTo(c) / 12.0;
        if (dist > 1) return 0;
        double impact = (1 - dist) * (checkExposure ? exposure(c, e) : 1.0);
        double dmg = (impact * impact + impact) / 2 * 7 * 12 + 1;
        Difficulty d = mc.world.getDifficulty();
        if (d == Difficulty.PEACEFUL) return 0;
        if (d == Difficulty.EASY) dmg = Math.min(dmg / 2 + 1, dmg); else if (d == Difficulty.HARD) dmg *= 1.5;
        double armor = e.getArmor(), tough = e.getAttributeValue(EntityAttributes.ARMOR_TOUGHNESS);
        double f = 2 + tough / 4, g = Math.max(armor * 0.2, Math.min(20, armor - dmg / f));
        return dmg * (1 - g / 25.0);
    }

    double hp(LivingEntity e) { return e.getHealth() + e.getAbsorptionAmount(); }
    double needed(LivingEntity t) { return hp(t) <= faceHp.v ? 1 : minDmg.v; }

    @Override public void onDisable() { target = null; }

    @Override public void onTick() {
        target = null;
        if (Modules.FREECAM.enabled || mc.currentScreen != null) return;
        if (pc > 0) pc--; if (bc > 0) bc--; if (sc > 0) sc--;
        if (pauseEat.b && mc.player.isUsingItem()) return;
        List<LivingEntity> ts = Targets.find(mc, targetRange.v, true, false, true);
        if (priority.idx == 1) ts.sort(java.util.Comparator.comparingDouble(this::hp));
        if (!ts.isEmpty()) target = ts.get(0);
        double selfHp = hp(mc.player);
        Vec3d eye = mc.player.getEyePos();

        if (breakC.b && bc == 0) {
            EndCrystalEntity best = null; double bestScore = -1e9;
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof EndCrystalEntity ec) || eye.distanceTo(ec.getEntityPos()) > breakRange.v) continue;
                Vec3d cp = ec.getEntityPos();
                double self = damage(mc.player, cp, true);
                if (self > maxSelf.v || self >= selfHp - suicide.v) continue;
                double dT = 0;
                for (LivingEntity t : ts) dT = Math.max(dT, damage(t, cp, true));
                if (dT < 1 && !breakAny.b) continue;
                double score = dT - self * 0.5;
                if (score > bestScore) { bestScore = score; best = ec; lastDmg = dT; }
            }
            if (best != null) {
                if (rotate.b) face(best.getEntityPos());
                mc.interactionManager.attackEntity(mc.player, best);
                mc.player.swingHand(Hand.MAIN_HAND);
                bc = breakDelay.i();
                lastBreak = mc.player.age; lastCrystal = best;
            }
        }

        if (place.b && pc == 0 && !ts.isEmpty()) placeBest(ts, eye, selfHp);
        if (surround.b && sc == 0) doSurround();
    }

    void placeBest(List<LivingEntity> ts, Vec3d eye, double selfHp) {
        BlockPos bestPos = null; double bestScore = -1e9;
        int r = (int) Math.ceil(placeRange.v);
        BlockPos c0 = BlockPos.ofFloored(eye);
        for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
            BlockPos p = c0.add(x, y, z);
            var st = mc.world.getBlockState(p);
            if (!st.isOf(Blocks.OBSIDIAN) && !st.isOf(Blocks.BEDROCK)) continue;
            if (!mc.world.isAir(p.up()) || !mc.world.isAir(p.up(2))) continue;
            Vec3d cp = new Vec3d(p.getX() + 0.5, p.getY() + 1.0, p.getZ() + 0.5);
            if (eye.distanceTo(cp) > placeRange.v) continue;
            if (!mc.world.getOtherEntities(null, new Box(p.getX(), p.getY() + 1, p.getZ(), p.getX() + 1, p.getY() + 3, p.getZ() + 1)).isEmpty()) continue;
            double dT = 0; boolean lethal = false;
            for (LivingEntity t : ts) {
                if (damage(t, cp, false) < needed(t)) continue;          // cheap upper-bound prune
                double d = damage(t, cp, true);
                if (d >= needed(t)) { dT = Math.max(dT, d); if (d >= hp(t)) lethal = true; }
            }
            if (dT <= 0) continue;
            double self = damage(mc.player, cp, true);
            if (self > maxSelf.v || self >= selfHp - suicide.v) continue;
            double score = dT - self * 0.5 + (lethal ? 100 : 0);
            if (score > bestScore) { bestScore = score; bestPos = p; lastDmg = dT; }
        }
        if (bestPos == null) return;
        Hand hand = null;
        if (mc.player.getOffHandStack().isOf(Items.END_CRYSTAL)) hand = Hand.OFF_HAND;
        else if (mc.player.getMainHandStack().isOf(Items.END_CRYSTAL)) hand = Hand.MAIN_HAND;
        int prev = Inv.selected();
        if (hand == null && autoSwitch.b) { int s = Inv.hotbar(st -> st.isOf(Items.END_CRYSTAL)); if (s >= 0) { Inv.select(s); hand = Hand.MAIN_HAND; } }
        if (hand == null) return;
        if (rotate.b) face(Vec3d.ofCenter(bestPos).add(0, 0.5, 0));
        mc.interactionManager.interactBlock(mc.player, hand, new BlockHitResult(new Vec3d(bestPos.getX() + 0.5, bestPos.getY() + 1.0, bestPos.getZ() + 0.5), Direction.UP, bestPos, false));
        mc.player.swingHand(hand);
        if (switchBack.b && hand == Hand.MAIN_HAND) Inv.select(prev);
        pc = placeDelay.i();
    }

    void doSurround() {
        int slot = Inv.hotbar(st -> st.isOf(Items.OBSIDIAN));
        if (slot < 0) return;
        BlockPos feet = mc.player.getBlockPos();
        for (Direction d : Direction.Type.HORIZONTAL) {
            BlockPos p = feet.offset(d), floor = p.down();
            if (!mc.world.getBlockState(p).isReplaceable() || mc.world.getBlockState(floor).isReplaceable()) continue;
            int prev = Inv.selected();
            Inv.select(slot);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(new Vec3d(floor.getX() + 0.5, floor.getY() + 1.0, floor.getZ() + 0.5), Direction.UP, floor, false));
            mc.player.swingHand(Hand.MAIN_HAND);
            Inv.select(prev);
            sc = surroundDelay.i();
            return;
        }
    }

    void face(Vec3d to) {
        float[] r = Targets.rot(mc.player.getEyePos(), to);
        mc.player.setYaw(r[0]); mc.player.setPitch(r[1]);
    }

    @Override public void onRender(DrawContext c, float td) {
        if (!info.b) return;
        Esp.hud(c, "Crystal PvP: " + (target == null ? "no target" : target.getName().getString() + " " + (int) hp(target) + "hp  best dmg " + (int) lastDmg), Modules.accent());
    }
}
