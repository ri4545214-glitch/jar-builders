package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** D-tap: right after Crystal PvP breaks a crystal, fire extra place+break cycles with zero delay and hit the crystal again so the second blast lands before a popped totem can be replaced. */
public class AutoDTap extends Module {
    final Setting burst = add(Setting.num("Burst Cycles", 2, 1, 4, 1));
    final Setting onlyTotem = add(Setting.bool("Only vs Totem Users", true));
    final Setting doubleHit = add(Setting.bool("Double Hit Crystal", true));
    final Setting hitDelay = add(Setting.num("Second Hit Delay", 1, 0, 3, 1));
    int used, hitFor = -1;

    public AutoDTap() { super("Auto D-Tap"); }

    @Override public void onTick() {
        var cp = Modules.CRYSTAL_PVP;
        if (!cp.enabled || mc.currentScreen != null) return;
        int age = mc.player.age, since = age - cp.lastBreak;
        if (since > 8) used = 0;
        LivingEntity t = cp.target;
        boolean totemUser = t != null && (t.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING) || t.getMainHandStack().isOf(Items.TOTEM_OF_UNDYING));
        if (since >= 0 && since <= 1 && used < burst.i() && (!onlyTotem.b || totemUser)) { cp.pc = 0; cp.bc = 0; used++; }
        if (doubleHit.b && cp.lastCrystal != null && hitFor != cp.lastBreak && since >= hitDelay.i() && since <= 3) {
            hitFor = cp.lastBreak;
            if (cp.lastCrystal.isAlive() && !cp.lastCrystal.isRemoved() && mc.player.distanceTo(cp.lastCrystal) <= 5) {
                mc.interactionManager.attackEntity(mc.player, cp.lastCrystal);
                mc.player.swingHand(Hand.MAIN_HAND);
            }
        }
    }
}
