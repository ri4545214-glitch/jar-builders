package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

/** Open a chest / barrel / shulker and it moves the items into your inventory, one per tick (or per delay). */
public class ChestStealer extends Module {
    final Setting delay = add(Setting.num("Delay (ticks)", 1, 0, 10, 1));
    final Setting close = add(Setting.bool("Close When Empty", true));
    int cd;

    public ChestStealer() { super("Chest Stealer"); }

    @Override public void onTick() {
        if (!(mc.currentScreen instanceof GenericContainerScreen gs)) { cd = 0; return; }
        if (cd > 0) { cd--; return; }
        GenericContainerScreenHandler h = gs.getScreenHandler();
        int n = h.getRows() * 9;
        for (int i = 0; i < n; i++) {
            if (h.getSlot(i).getStack().isEmpty()) continue;
            mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, mc.player);
            cd = delay.i();
            return;
        }
        if (close.b) mc.player.closeHandledScreen();
    }
}
