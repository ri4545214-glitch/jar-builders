package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class AutoClicker extends Module {
    final Setting button = add(Setting.mode("Button", 0, "Left", "Right", "Both"));
    final Setting minCps = add(Setting.num("Min CPS", 8, 1, 20, 1));
    final Setting maxCps = add(Setting.num("Max CPS", 12, 1, 20, 1));
    final Setting hold = add(Setting.bool("Only While Holding", true));
    final Setting cooldown = add(Setting.bool("Wait Weapon Cooldown", false));
    final Setting inGui = add(Setting.bool("Click In GUI", false));
    final Random rnd = new Random();
    double accL, accR;

    public AutoClicker() { super("Auto Clicker"); }

    boolean held(int btn) {
        return !hold.b || GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), btn) == GLFW.GLFW_PRESS;
    }

    @Override public void onPreTick() {
        if (Modules.FREECAM.enabled || (mc.currentScreen != null && !inGui.b)) return;
        double lo = Math.min(minCps.v, maxCps.v), hi = Math.max(minCps.v, maxCps.v);
        double cps = lo + rnd.nextDouble() * (hi - lo);
        boolean left = button.idx != 1 && held(GLFW.GLFW_MOUSE_BUTTON_LEFT);
        boolean right = button.idx != 0 && held(GLFW.GLFW_MOUSE_BUTTON_RIGHT);
        if (left) {
            accL += cps / 20.0;
            int n = 0;
            while (accL >= 1 && n++ < 3) {
                accL -= 1;
                if (cooldown.b && mc.player.getAttackCooldownProgress(0f) < 0.9f) continue;
                clickLeft();
            }
        } else accL = 0;
        if (right) {
            accR += cps / 20.0;
            int n = 0;
            while (accR >= 1 && n++ < 3) { accR -= 1; clickRight(); }
        } else accR = 0;
    }

    void clickLeft() {
        if (mc.crosshairTarget instanceof EntityHitResult ehr) {
            mc.interactionManager.attackEntity(mc.player, ehr.getEntity());
            mc.player.swingHand(Hand.MAIN_HAND);
        } else if (mc.crosshairTarget instanceof BlockHitResult br && br.getType() == HitResult.Type.BLOCK) {
            mc.options.attackKey.setPressed(true);          // vanilla block breaking keeps going while the key is down
        } else mc.player.swingHand(Hand.MAIN_HAND);
    }

    void clickRight() {
        if (mc.crosshairTarget instanceof EntityHitResult ehr) mc.interactionManager.interactEntity(mc.player, ehr.getEntity(), Hand.MAIN_HAND);
        else if (mc.crosshairTarget instanceof BlockHitResult br && br.getType() == HitResult.Type.BLOCK) mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, br);
        else mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
