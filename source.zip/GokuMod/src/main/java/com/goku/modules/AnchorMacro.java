package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Inv;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Look at a respawn anchor: charges it with glowstone, then detonates it with another item. */
public class AnchorMacro extends Module {
    final Setting charges = add(Setting.num("Charges", 1, 1, 4, 1));
    final Setting chargeDelay = add(Setting.num("Charge Delay", 1, 0, 10, 1));
    final Setting explodeDelay = add(Setting.num("Explode Delay", 1, 0, 10, 1));
    final Setting explodeWith = add(Setting.mode("Explode With", 0, "Totem", "Any Item"));
    final Setting autoPlace = add(Setting.bool("Auto Place (hold anchor)", false));
    final Setting range = add(Setting.num("Range", 4.5, 2, 6, 0.5));
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    BlockPos target;
    int cd, prevSlot = -1;

    public AnchorMacro() { super("Anchor Macro"); }

    @Override public void onDisable() { target = null; }

    void use(BlockPos pos) {
        BlockHitResult hit = new BlockHitResult(new Vec3d(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5), Direction.UP, pos, false);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    @Override public void onTick() {
        if (Modules.FREECAM.enabled || mc.currentScreen != null) return;
        if (cd > 0) { cd--; return; }
        if (mc.crosshairTarget instanceof BlockHitResult hr && hr.getType() == HitResult.Type.BLOCK) {
            BlockPos p = hr.getBlockPos();
            if (mc.world.getBlockState(p).isOf(Blocks.RESPAWN_ANCHOR)) target = p;
            else if (autoPlace.b && mc.player.getMainHandStack().isOf(Items.RESPAWN_ANCHOR) && target == null) {
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hr);
                mc.player.swingHand(Hand.MAIN_HAND);
                target = p.offset(hr.getSide());
                cd = 2;
                return;
            }
        }
        if (target == null) return;
        BlockState st = mc.world.getBlockState(target);
        if (!st.isOf(Blocks.RESPAWN_ANCHOR) || mc.player.getEyePos().distanceTo(Vec3d.ofCenter(target)) > range.v) {
            if (!st.isOf(Blocks.RESPAWN_ANCHOR) && prevSlot >= 0 && swapBack.b) Inv.select(prevSlot);
            prevSlot = -1; target = null; return;
        }
        if (prevSlot < 0) prevSlot = Inv.selected();
        int ch = st.get(RespawnAnchorBlock.CHARGES);
        if (ch < charges.i()) {
            int g = Inv.hotbar(s -> s.isOf(Items.GLOWSTONE));
            if (g < 0) return;
            Inv.select(g); use(target); cd = chargeDelay.i();
        } else {
            int e = Inv.hotbar(s -> explodeWith.idx == 0 ? s.isOf(Items.TOTEM_OF_UNDYING) : (!s.isOf(Items.GLOWSTONE) && !s.isOf(Items.RESPAWN_ANCHOR)));
            if (e < 0) return;
            Inv.select(e); use(target); cd = explodeDelay.i();
        }
    }
}
