package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.AnchorOps;
import com.goku.util.Inv;
import com.goku.util.Targets;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/**
 * One anchor module, three modes:
 *  Normal - look at a respawn anchor: charge it with glowstone, then detonate it.
 *  Safe   - same, but first puts a glowstone block between you and the anchor and aborts below a health limit.
 *  Air    - places the anchor for you (against a neighbouring block, or in mid-air where the server allows it), then charges/detonates (optionally with the glowstone shield).
 * It never places an anchor on its own in Normal/Safe mode: you place it, the macro does the rest.
 */
public class AnchorMacro extends Module {
    final Setting mode = add(Setting.mode("Mode", 0, "Normal", "Safe", "Air"));
    final Setting charges = add(Setting.num("Charges", 1, 1, 4, 1));
    final Setting chargeDelay = add(Setting.num("Charge Delay", 1, 0, 10, 1));
    final Setting explodeDelay = add(Setting.num("Explode Delay", 1, 0, 10, 1));
    final Setting explodeWith = add(Setting.mode("Explode With", 0, "Totem", "Any Item"));
    final Setting range = add(Setting.num("Range", 4.5, 2, 6, 0.5));
    final Setting shield = add(Setting.bool("Glowstone Shield (Safe/Air)", true));
    final Setting minHp = add(Setting.num("Abort Below HP (Safe/Air)", 8, 0, 20, 1));
    final Setting where = add(Setting.mode("Air: Position", 0, "Crosshair Air", "Above Target", "Beside Target", "Under Target"));
    final Setting dist = add(Setting.num("Air: Distance", 4, 2, 5, 0.5));
    final Setting targetRange = add(Setting.num("Air: Target Range", 8, 3, 16, 1));
    final Setting placeDelay = add(Setting.num("Air: Place Delay", 1, 1, 10, 1));
    final Setting minSelf = add(Setting.num("Air: Min Self Distance", 2.5, 1, 5, 0.5));
    final Setting repeat = add(Setting.bool("Air: Repeat", false));
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    final AnchorOps.Run run = new AnchorOps.Run();
    int wait, fails;

    public AnchorMacro() { super("Anchor Macro"); }

    @Override public void onEnable() { fails = 0; wait = 0; }
    @Override public void onDisable() { if (mc.player != null) run.finish(swapBack.b); }

    BlockPos pick() {
        Vec3d eye = mc.player.getEyePos();
        if (where.idx == 0) {
            if (mc.crosshairTarget instanceof BlockHitResult hr && hr.getType() == HitResult.Type.BLOCK && eye.distanceTo(hr.getPos()) < dist.v)
                return hr.getBlockPos().offset(hr.getSide());
            return BlockPos.ofFloored(eye.add(mc.player.getRotationVec(1f).multiply(dist.v)));
        }
        var l = Targets.find(mc, targetRange.v, true, false, true);
        if (l.isEmpty()) return null;
        LivingEntity t = l.get(0);
        BlockPos feet = t.getBlockPos();
        return switch (where.idx) {
            case 1 -> feet.up(2);
            case 2 -> {
                Vec3d d = mc.player.getEntityPos().subtract(t.getEntityPos());
                yield Math.abs(d.x) > Math.abs(d.z) ? feet.add(d.x > 0 ? 1 : -1, 1, 0) : feet.add(0, 1, d.z > 0 ? 1 : -1);
            }
            default -> feet.down();
        };
    }

    @Override public void onTick() {
        if (Modules.FREECAM.enabled || mc.currentScreen != null) return;
        boolean safe = mode.idx != 0, air = mode.idx == 2;
        if (run.anchor != null) {
            boolean more = run.step(charges.i(), chargeDelay.i(), explodeDelay.i(), explodeWith.idx == 0, safe && shield.b, air ? 5.5 : range.v, safe ? minHp.v : 0);
            if (!more) {
                boolean used = run.acted;
                run.finish(swapBack.b);
                wait = 5;
                if (air) {
                    if (!used) fails++; else fails = 0;
                    if (fails >= 4) { setEnabled(false); mc.player.sendMessage(Text.literal("[Goku] Anchor: server refused placing the anchor"), true); }
                    else if (used && !repeat.b) { setEnabled(false); mc.player.sendMessage(Text.literal("[Goku] Anchor done"), true); }
                }
            }
            return;
        }
        if (wait > 0) { wait--; return; }
        if (!air) {
            if (mc.crosshairTarget instanceof BlockHitResult hr && hr.getType() == HitResult.Type.BLOCK
                    && mc.world.getBlockState(hr.getBlockPos()).isOf(Blocks.RESPAWN_ANCHOR)) run.start(hr.getBlockPos());
            return;
        }
        int slot = Inv.hotbar(s -> s.isOf(Items.RESPAWN_ANCHOR));
        if (slot < 0) return;
        BlockPos p = pick();
        if (p == null || !AnchorOps.canAirPlace(p)) return;
        if (mc.player.getEyePos().distanceTo(Vec3d.ofCenter(p)) > 4.5 || mc.player.getEntityPos().distanceTo(Vec3d.ofCenter(p)) < minSelf.v) return;
        Inv.select(slot);
        AnchorOps.place(p);
        run.start(p);
        run.cd = placeDelay.i();
    }
}
