package com.goku.modules;

import com.goku.Setting;
import net.minecraft.block.entity.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.Set;

/** Finds spawners (dungeons / spawner bases) and trial chamber blocks. */
public class SpawnerEsp extends BlockEntityEsp {
    final Setting spawners = add(Setting.bool("Spawners", true));
    final Setting trial = add(Setting.bool("Trial Chambers", true));

    public SpawnerEsp() { super("Spawner ESP", 20); common(); }

    @Override protected Found classify(BlockEntity be, Set<BlockPos> used) {
        Box b = new Box(be.getPos());
        if (be instanceof MobSpawnerBlockEntity) return spawners.b ? Found.of(b, 0xFFFF3030, "Spawner") : null;
        if (be instanceof TrialSpawnerBlockEntity) return trial.b ? Found.of(b, 0xFF30C8FF, "Trial Spawner") : null;
        if (be instanceof VaultBlockEntity) return trial.b ? Found.of(b, 0xFFFFD700, "Vault") : null;
        return null;
    }
}
