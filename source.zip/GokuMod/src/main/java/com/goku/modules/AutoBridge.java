package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Inv;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.FallingBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Places a block under your feet while you walk off edges (bridging / scaffold). */
public class AutoBridge extends Module {
    final Setting delay = add(Setting.num("Delay (ticks)", 1, 0, 6, 1));
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    final Setting tower = add(Setting.bool("Tower (Jump)", true));
    final Setting rotate = add(Setting.bool("Look Down", false));
    int cd;

    public AutoBridge() { super("Auto Bridge"); }

    @Override public void onTick() {
        if (Modules.FREECAM.enabled || mc.currentScreen != null) return;
        if (cd > 0) { cd--; return; }
        BlockPos below = BlockPos.ofFloored(mc.player.getX(), mc.player.getY() - 1, mc.player.getZ());
        if (!mc.world.getBlockState(below).isReplaceable()) return;
        int slot = Inv.hotbar(st -> st.getItem() instanceof BlockItem bi && !(bi.getBlock() instanceof FallingBlock) && !(bi.getBlock() instanceof BlockEntityProvider));
        if (slot < 0) return;
        for (Direction d : Direction.values()) {
            if (d == Direction.UP) continue;
            BlockPos nb = below.offset(d);
            if (mc.world.getBlockState(nb).isReplaceable()) continue;
            Direction face = d.getOpposite();
            Vec3d hitPos = Vec3d.ofCenter(nb).add(Vec3d.of(face.getVector()).multiply(0.5));
            int prev = Inv.selected();
            Inv.select(slot);
            if (rotate.b) mc.player.setPitch(80f);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(hitPos, face, nb, false));
            mc.player.swingHand(Hand.MAIN_HAND);
            if (swapBack.b) Inv.select(prev);
            if (tower.b && mc.options.jumpKey.isPressed() && mc.player.getVelocity().y < 0.2)
                mc.player.setVelocity(mc.player.getVelocity().x, 0.42, mc.player.getVelocity().z);
            cd = delay.i();
            return;
        }
    }
}
