package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Targets;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.Blocks;
import net.minecraft.block.FallingBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Bridging: places a block under your feet (and one step ahead while moving).
 * Server friendly: it clicks a real face of a real neighbouring block inside reach, and the optional rotation is applied at the
 * start of the tick (before the movement packet) so the server already sees you looking at the block when the placement arrives.
 */
public class AutoBridge extends Module {
    final Setting delay = add(Setting.num("Delay (ticks)", 1, 0, 6, 1));
    final Setting ahead = add(Setting.num("Look Ahead (ticks)", 2, 0, 5, 1));
    final Setting rotate = add(Setting.mode("Rotate", 1, "Off", "Pitch", "Full"));
    final Setting tower = add(Setting.bool("Place While Jumping", true));
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    int cd;
    BlockPos planSupport;
    Direction planFace;
    Vec3d planHit;

    public AutoBridge() { super("Auto Bridge"); }

    @Override public void onDisable() { planSupport = null; }

    BlockPos below(double x, double z) { return BlockPos.ofFloored(x, mc.player.getY() - 1, z); }

    @Override public void onPreTick() {
        planSupport = null;
        if (cd > 0) { cd--; return; }
        if (Modules.FREECAM.enabled || mc.currentScreen != null) return;
        if (!tower.b && mc.options.jumpKey.isPressed() && mc.player.getVelocity().y > 0.1) return;
        Vec3d v = mc.player.getVelocity();
        BlockPos[] cands = { below(mc.player.getX(), mc.player.getZ()), below(mc.player.getX() + v.x * ahead.v, mc.player.getZ() + v.z * ahead.v) };
        Vec3d eye = mc.player.getEyePos();
        for (BlockPos t : cands) {
            if (!mc.world.getBlockState(t).isReplaceable()) continue;
            double best = 4.5;
            for (Direction d : Direction.values()) {
                if (d == Direction.UP) continue;
                BlockPos nb = t.offset(d);
                if (mc.world.getBlockState(nb).isReplaceable() || mc.world.getBlockState(nb).isOf(Blocks.AIR)) continue;
                Direction face = d.getOpposite();
                Vec3d hit = Vec3d.ofCenter(nb).add(Vec3d.of(face.getVector()).multiply(0.5));
                double dist = eye.distanceTo(hit);
                if (dist < best) { best = dist; planSupport = nb; planFace = face; planHit = hit; }
            }
            if (planSupport != null) break;
        }
        if (planSupport == null) return;
        if (rotate.idx > 0) {
            float[] r = Targets.rot(eye, planHit);
            mc.player.setPitch(Math.max(-90f, Math.min(90f, r[1])));
            if (rotate.idx == 2) mc.player.setYaw(r[0]);
        }
    }

    @Override public void onTick() {
        if (planSupport == null) return;
        int slot = Inv.hotbar(st -> st.getItem() instanceof BlockItem bi && !(bi.getBlock() instanceof FallingBlock) && !(bi.getBlock() instanceof BlockEntityProvider));
        if (slot < 0) return;
        int prev = Inv.selected();
        Inv.select(slot);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(planHit, planFace, planSupport, false));
        mc.player.swingHand(Hand.MAIN_HAND);
        if (swapBack.b) Inv.select(prev);
        cd = delay.i();
        planSupport = null;
    }
}
