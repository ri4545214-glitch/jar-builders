package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Draw;
import com.goku.util.Esp;
import com.goku.util.Projector;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.vehicle.ChestMinecartEntity;
import net.minecraft.entity.vehicle.HopperMinecartEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.util.*;

/**
 * Base Finder AI: a weighted evidence model. Every loaded chunk is scored from three signals - artificial blocks in the chunk
 * palettes (redstone, storage blocks, concrete, utility blocks...), player-placed block entities, and stash entities - and squashed into a
 * 0-100 confidence. Chunks are scanned incrementally (a few per tick) so it stays smooth on phones.
 */
public class BaseAi extends Module {
    final Setting minConf = add(Setting.num("Min Confidence %", 55, 20, 95, 5));
    final Setting top = add(Setting.num("Show Top N", 4, 1, 12, 1));
    final Setting blocks = add(Setting.bool("Analyse Blocks", true));
    final Setting tiles = add(Setting.bool("Analyse Containers", true));
    final Setting ents = add(Setting.bool("Analyse Entities", true));
    final Setting speed = add(Setting.num("Scan Speed (chunks/tick)", 4, 1, 20, 1));
    final Setting style = add(Setting.mode("Box Style", 1, Esp.STYLES));
    final Setting fill = add(Setting.bool("Fill", true));
    final Setting labels = add(Setting.bool("Labels", true));
    final Setting tracer = add(Setting.bool("Tracer To Best", true));
    final Setting hud = add(Setting.bool("Compass HUD", true));

    record Result(ChunkPos pos, double conf, Box box, Vec3d center, String why) {}

    final Map<Long, Result> results = new HashMap<>();
    final Map<Long, Double> entityPts = new HashMap<>();
    final Map<Block, Float> weights = new HashMap<>();
    final ArrayDeque<Long> queue = new ArrayDeque<>();
    List<Result> ranked = List.of();
    int lastBuild = -1000;
    Object world;

    public BaseAi() { super("Base Finder AI"); }

    static long key(int x, int z) { return ((long) x << 32) | (z & 0xFFFFFFFFL); }

    float weight(Block b) {
        return weights.computeIfAbsent(b, k -> {
            if (k == Blocks.REDSTONE_LAMP || k == Blocks.PISTON || k == Blocks.STICKY_PISTON || k == Blocks.OBSERVER || k == Blocks.REPEATER
                    || k == Blocks.COMPARATOR || k == Blocks.DROPPER || k == Blocks.NOTE_BLOCK || k == Blocks.DAYLIGHT_DETECTOR || k == Blocks.REDSTONE_BLOCK) return 2.5f;
            if (k == Blocks.DIAMOND_BLOCK || k == Blocks.EMERALD_BLOCK || k == Blocks.NETHERITE_BLOCK || k == Blocks.GOLD_BLOCK || k == Blocks.IRON_BLOCK || k == Blocks.LAPIS_BLOCK) return 4f;
            if (k == Blocks.BEACON || k == Blocks.ENCHANTING_TABLE || k == Blocks.ANVIL || k == Blocks.BREWING_STAND || k == Blocks.BLAST_FURNACE || k == Blocks.SMOKER || k == Blocks.FURNACE) return 3f;
            if (k == Blocks.HOPPER || k == Blocks.DISPENSER || k == Blocks.JUKEBOX || k == Blocks.TNT) return 1.5f;
            String id = Registries.BLOCK.getId(k).getPath();
            if (id.endsWith("concrete") || id.endsWith("concrete_powder") || id.endsWith("glazed_terracotta") || id.endsWith("stained_glass") || id.equals("sea_lantern")
                    || id.equals("smooth_stone") || id.startsWith("quartz_") || id.equals("end_rod")) return 2f;
            return 0f;
        });
    }

    @Override public void onDisable() { results.clear(); queue.clear(); ranked = List.of(); }

    void rebuildQueue() {
        lastBuild = mc.player.age;
        queue.clear();
        ChunkPos cp = mc.getCameraEntity().getChunkPos();
        int vd = mc.options.getViewDistance().getValue() + 1;
        List<long[]> l = new ArrayList<>();
        for (int dx = -vd; dx <= vd; dx++) for (int dz = -vd; dz <= vd; dz++) l.add(new long[]{key(cp.x + dx, cp.z + dz), dx * dx + dz * dz});
        l.sort(Comparator.comparingLong(a -> a[1]));
        for (long[] a : l) queue.add(a[0]);
        entityPts.clear();
        if (ents.b) for (Entity e : mc.world.getEntities()) {
            double p = e instanceof ItemFrameEntity ? 1.0 : (e instanceof ChestMinecartEntity || e instanceof HopperMinecartEntity) ? 2.0
                    : e instanceof ArmorStandEntity ? 0.5 : e instanceof VillagerEntity ? 0.3 : 0;
            if (p > 0) entityPts.merge(key(e.getChunkPos().x, e.getChunkPos().z), p, Double::sum);
        }
    }

    @Override public void onTick() {
        if (mc.world != world) { results.clear(); world = mc.world; }
        if (mc.getCameraEntity() == null) return;
        if (queue.isEmpty() && mc.player.age - lastBuild > 100) rebuildQueue();
        for (int i = 0; i < speed.i() && !queue.isEmpty(); i++) {
            long k = queue.poll();
            int x = (int) (k >> 32), z = (int) k;
            WorldChunk ch = mc.world.getChunkManager().getWorldChunk(x, z);
            if (ch == null) { results.remove(k); continue; }
            Result r = analyse(ch);
            if (r == null) results.remove(k); else results.put(k, r);
        }
        ranked = results.values().stream().filter(r -> r.conf >= minConf.v).sorted(Comparator.comparingDouble((Result r) -> -r.conf)).limit(top.i()).toList();
    }

    Result analyse(WorldChunk ch) {
        double bp = 0, tp = 0, ep = entityPts.getOrDefault(key(ch.getPos().x, ch.getPos().z), 0.0);
        int yMin = Integer.MAX_VALUE, yMax = Integer.MIN_VALUE;
        if (blocks.b) {
            ChunkSection[] secs = ch.getSectionArray();
            for (int i = 0; i < secs.length; i++) {
                ChunkSection s = secs[i];
                if (s == null || s.isEmpty()) continue;
                double[] acc = {0};
                s.getBlockStateContainer().count((st, n) -> { float w = weight(st.getBlock()); if (w > 0) acc[0] += w * Math.min(n, 16) / 4.0; });
                if (acc[0] > 0) {
                    bp += acc[0];
                    int base = (ch.getBottomSectionCoord() + i) * 16;
                    yMin = Math.min(yMin, base); yMax = Math.max(yMax, base + 16);
                }
            }
        }
        if (tiles.b) for (BlockEntity be : ch.getBlockEntities().values()) {
            double w = be instanceof ShulkerBoxBlockEntity ? 2 : be instanceof BeaconBlockEntity ? 6 : be instanceof EnchantingTableBlockEntity ? 3
                    : (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity || be instanceof HopperBlockEntity || be instanceof AbstractFurnaceBlockEntity
                    || be instanceof DispenserBlockEntity || be instanceof BrewingStandBlockEntity) ? 1 : be instanceof BedBlockEntity ? 0.7 : 0;
            if (w > 0) { tp += w; yMin = Math.min(yMin, be.getPos().getY()); yMax = Math.max(yMax, be.getPos().getY() + 1); }
        }
        double total = bp + tp * 1.5 + ep;
        double conf = 100 * (1 - Math.exp(-total / 14.0));
        if (conf < 20) return null;
        if (yMin == Integer.MAX_VALUE) { yMin = (int) mc.player.getY() - 8; yMax = (int) mc.player.getY() + 16; }
        ChunkPos p = ch.getPos();
        Box box = new Box(p.getStartX(), yMin, p.getStartZ(), p.getStartX() + 16, yMax, p.getStartZ() + 16);
        String why = (bp > 0 ? "blocks " : "") + (tp > 0 ? "storage " : "") + (ep > 0 ? "entities" : "");
        return new Result(p, conf, box, box.getCenter(), why.trim());
    }

    /** Best candidate position (for Auto Find), or null. */
    public Vec3d best() { return ranked.isEmpty() ? null : new Vec3d(ranked.get(0).center.x, mc.player.getY(), ranked.get(0).center.z); }

    static String compass(double dx, double dz) {
        String[] n = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
        int i = (int) Math.round(Math.toDegrees(Math.atan2(dz, dx)) / 45.0 + 8) % 8;   // atan2(dz,dx): 0=east(+x), 90=south(+z)
        return new String[]{"E", "SE", "S", "SW", "W", "NW", "N", "NE"}[i];
    }

    @Override public void onRender(DrawContext c, float td) {
        if (!Projector.ok) return;
        int col = Draw.COLORS[3];
        if (hud.b) {
            Esp.hud(c, "Base AI: " + results.size() + " chunks analysed, " + ranked.size() + " candidates", Modules.accent());
            for (Result r : ranked) {
                double dx = r.center.x - mc.player.getX(), dz = r.center.z - mc.player.getZ();
                Esp.hud(c, String.format(" %s %dm  [%d,%d] %d%%  %s", compass(dx, dz), (int) Math.hypot(dx, dz), r.pos.getStartX(), r.pos.getStartZ(), (int) r.conf, r.why), col);
            }
        }
        boolean first = true;
        for (Result r : ranked) {
            double dist = r.center.distanceTo(Projector.cam);
            int cl = Esp.a(col, 255);
            Esp.box(c, r.box, first ? 0xFFFF4040 : cl, style.idx, fill.b, first ? 2 : 1);
            if (first && tracer.b) Esp.tracer(c, r.center, 0xFFFF4040, 0, 1);
            if (labels.b) {
                double[] p = Projector.to(new Vec3d(r.center.x, r.box.maxY + 0.5, r.center.z));
                if (p != null) Esp.label(c, "BASE " + (int) r.conf + "%  " + (int) dist + "m", (int) p[0], (int) p[1] - 11, first ? 0xFFFF4040 : cl);
            }
            first = false;
        }
    }
}
