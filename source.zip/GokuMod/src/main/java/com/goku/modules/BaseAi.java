package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Draw;
import com.goku.util.Esp;
import com.goku.util.Projector;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.entity.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.passive.AbstractHorseEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.vehicle.ChestMinecartEntity;
import net.minecraft.entity.vehicle.HopperMinecartEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Base Finder AI v2.
 *
 * Every chunk is turned into an evidence profile: 10 categories (storage, redstone, utility, decor, building, light, beds, valuables,
 * people/pets, signs) from block palettes, block entities and entities. Evidence is split into PROOF (things that practically only players
 * place: hoppers, observers, beacons, concrete, shulkers, other players, tamed pets...) and SOFT (things that also generate naturally: chests,
 * beds, torches, planks...).
 *
 * Natural structures (mineshafts, villages, strongholds, ancient cities, trial chambers, fortresses/bastions, end cities, monuments, temples)
 * are recognised by their signature blocks; the more signature a chunk has, the more its SOFT evidence is discounted, while PROOF is kept.
 * Evidence from neighbouring chunks is merged into clusters (a base is rarely inside one chunk), then a confidence of 0-100 is computed from
 * the cluster total, category diversity and the natural-structure discount, and the cluster is classified (Stash / Redstone-Farm / Base / Structure).
 * Chunks that unload are remembered, so candidates stay on the list when you fly away. Scanning is incremental (a few chunks per tick).
 */
public class BaseAi extends Module {
    final Setting minConf = add(Setting.num("Min Confidence %", 55, 20, 95, 5));
    final Setting top = add(Setting.num("Show Top N", 4, 1, 12, 1));
    final Setting blocks = add(Setting.bool("Analyse Blocks", true));
    final Setting tiles = add(Setting.bool("Analyse Containers", true));
    final Setting ents = add(Setting.bool("Analyse Entities", true));
    final Setting hideNatural = add(Setting.bool("Hide Natural Structures", true));
    final Setting remember = add(Setting.bool("Remember Unloaded Chunks", true));
    final Setting minChunks = add(Setting.num("Min Cluster Chunks", 1, 1, 6, 1));
    final Setting ignoreNear = add(Setting.num("Ignore Within (blocks)", 0, 0, 300, 10));
    final Setting speed = add(Setting.num("Scan Speed (chunks/tick)", 4, 1, 20, 1));
    final Setting style = add(Setting.mode("Box Style", 1, Esp.STYLES));
    final Setting fill = add(Setting.bool("Fill", true));
    final Setting labels = add(Setting.bool("Labels", true));
    final Setting tracer = add(Setting.bool("Tracer To Best", true));
    final Setting hud = add(Setting.bool("Compass HUD", true));
    final Setting export = add(Setting.bool("> Export List", false));

    static final String[] CAT = {"storage", "redstone", "utility", "decor", "building", "light", "beds", "valuables", "people", "signs"};
    static final int C_STORE = 0, C_RED = 1, C_UTIL = 2, C_DECOR = 3, C_BUILD = 4, C_LIGHT = 5, C_BED = 6, C_VAL = 7, C_PEOPLE = 8, C_SIGN = 9;
    static final int S_MINE = 0, S_VILLAGE = 1, S_ANCIENT = 2, S_TRIAL = 3, S_STRONG = 4, S_NETHER = 5, S_END = 6, S_OTHER = 7, NSIG = 8;
    static final double K = 10.0;

    /** Evidence of one chunk. */
    static final class Chunk {
        final double[] cat = new double[CAT.length];
        double proof, soft, nf, total;
        int yMin = Integer.MAX_VALUE, yMax = Integer.MIN_VALUE;
        ChunkPos pos;
    }
    record Cluster(double conf, Box box, Vec3d center, String type, String why, int chunks, double nf) {}
    record Info(float w, int cat, boolean proof, int sig) {}
    static final Info NONE = new Info(0, 0, false, -1);

    final Map<Long, Chunk> results = new HashMap<>();
    final Map<Long, double[]> entityPts = new HashMap<>();   // [soft, proof] per chunk
    final Map<Block, Info> infos = new HashMap<>();
    final ArrayDeque<Long> queue = new ArrayDeque<>();
    List<Cluster> ranked = List.of();
    int lastBuild = -1000, lastCluster;
    Object world;
    String dim = "overworld";
    Vec3d home;

    public BaseAi() { super("Base Finder AI"); }

    static long key(int x, int z) { return ((long) x << 32) | (z & 0xFFFFFFFFL); }

    // ------------------------------------------------------------------ block knowledge
    static Info st(int cat, float w, boolean proof) { return new Info(w, cat, proof, -1); }
    static Info sg(int sig, float w) { return new Info(w, 0, false, sig); }

    Info info(Block b) { return infos.computeIfAbsent(b, k -> classify(Registries.BLOCK.getId(k).getPath())); }

    Info classify(String id) {
        boolean nether = dim.equals("the_nether"), end = dim.equals("the_end");
        // --- natural-structure signatures
        if (id.equals("rail") || id.equals("powered_rail") || id.equals("detector_rail") || id.equals("activator_rail")) return sg(S_MINE, 0.5f);
        if (id.equals("cobweb")) return sg(S_MINE, 1.5f);
        if (id.equals("bell")) return sg(S_VILLAGE, 6f);
        if (id.equals("hay_block") || id.equals("composter") || id.equals("lectern") || id.equals("loom") || id.equals("cartography_table")
                || id.equals("fletching_table") || id.equals("dirt_path")) return sg(S_VILLAGE, 1.2f);
        if (id.startsWith("sculk") || id.equals("reinforced_deepslate")) return sg(S_ANCIENT, 2f);
        if (id.equals("trial_spawner") || id.equals("vault")) return sg(S_TRIAL, 8f);
        if (id.contains("copper_grate") || id.startsWith("chiseled_copper") || id.startsWith("copper_bulb") || id.startsWith("tuff_brick")) return sg(S_TRIAL, 0.6f);
        if (id.equals("end_portal_frame") || id.equals("end_portal")) return sg(S_STRONG, 10f);
        if (id.equals("mossy_stone_bricks") || id.equals("cracked_stone_bricks")) return sg(S_STRONG, 0.4f);
        if (nether && (id.contains("nether_brick") || id.equals("nether_wart") || id.contains("blackstone") || id.equals("chain"))) return sg(S_NETHER, 0.8f);
        if (end && (id.contains("purpur") || id.equals("end_rod") || id.equals("end_stone_bricks"))) return sg(S_END, 1f);
        if (id.contains("prismarine") || id.equals("sea_lantern") || id.equals("wet_sponge")) return sg(S_OTHER, 1.2f);
        if (id.equals("chiseled_sandstone") || id.equals("chiseled_red_sandstone")) return sg(S_OTHER, 1f);

        // --- player evidence
        if (id.equals("beacon") || id.equals("conduit")) return st(C_VAL, 6f, true);
        if (id.equals("diamond_block") || id.equals("emerald_block") || id.equals("netherite_block") || id.equals("lapis_block") || id.equals("iron_block")) return st(C_VAL, 1.6f, true);
        if (id.equals("gold_block")) return st(C_VAL, 1.6f, !nether);
        if (id.equals("enchanting_table") || id.equals("respawn_anchor")) return st(C_UTIL, 3f, true);
        if (id.equals("anvil") || id.equals("chipped_anvil") || id.equals("damaged_anvil")) return st(C_UTIL, 2f, true);
        if (id.equals("ender_chest") || id.equals("jukebox") || id.equals("tnt")) return st(C_UTIL, 1.5f, true);
        if (id.equals("brewing_stand")) return st(C_UTIL, 1.2f, false);
        if (id.equals("furnace")) return st(C_UTIL, 0.7f, false);
        if (id.equals("blast_furnace") || id.equals("smoker") || id.equals("smithing_table") || id.equals("grindstone") || id.equals("stonecutter")) return st(C_UTIL, 0.5f, false);
        if (id.equals("crafting_table")) return st(C_UTIL, 0.4f, false);
        if (id.equals("redstone_torch") || id.equals("redstone_wall_torch")) return st(C_RED, 0.7f, true);
        if (id.equals("hopper") || id.equals("observer") || id.equals("piston") || id.equals("sticky_piston") || id.equals("repeater") || id.equals("comparator")
                || id.equals("dropper") || id.equals("note_block") || id.equals("daylight_detector") || id.equals("redstone_block") || id.equals("redstone_lamp")
                || id.equals("target") || id.equals("tripwire_hook") || id.equals("slime_block") || id.equals("honey_block")) return st(C_RED, 0.9f, true);
        if (id.equals("dispenser") || id.equals("lever")) return st(C_RED, 0.6f, false);
        if (id.endsWith("_bed")) return st(C_BED, 0.8f, false);
        if (id.endsWith("concrete") || id.endsWith("concrete_powder") || id.endsWith("glazed_terracotta") || id.endsWith("stained_glass") || id.endsWith("stained_glass_pane")) return st(C_BUILD, 0.7f, true);
        if (id.endsWith("torch") || id.equals("lantern") || id.equals("soul_lantern") || id.equals("campfire") || id.equals("soul_campfire")) return st(C_LIGHT, 0.7f, false);
        if (id.equals("glowstone")) return st(C_LIGHT, 0.6f, !nether);
        if (id.endsWith("_banner") || id.endsWith("candle") || id.equals("flower_pot") || id.equals("bookshelf") || id.equals("chiseled_bookshelf")) return st(C_DECOR, 0.45f, false);
        if (id.endsWith("_carpet")) return st(C_DECOR, 0.1f, false);
        if (id.endsWith("_planks") || id.endsWith("_stairs") || id.endsWith("_slab") || id.endsWith("_fence") || id.endsWith("_fence_gate") || id.endsWith("_wall")
                || id.endsWith("_door") || id.endsWith("_trapdoor") || id.endsWith("_wool") || id.endsWith("_terracotta") || id.equals("glass") || id.equals("glass_pane")
                || id.endsWith("bricks") || id.startsWith("polished_") || id.startsWith("cut_") || id.startsWith("smooth_") || id.startsWith("chiseled_") || id.equals("ladder"))
            return st(C_BUILD, 0.12f, false);
        return NONE;
    }

    // ------------------------------------------------------------------ scanning
    @Override public void onEnable() { if (mc.player != null) home = mc.player.getEntityPos(); }
    @Override public void onDisable() { results.clear(); entityPts.clear(); queue.clear(); ranked = List.of(); }

    void rebuildQueue() {
        lastBuild = mc.player.age;
        queue.clear();
        ChunkPos cp = mc.getCameraEntity().getChunkPos();
        int vd = mc.options.getViewDistance().getValue() + 1;
        List<long[]> l = new ArrayList<>();
        for (int dx = -vd; dx <= vd; dx++) for (int dz = -vd; dz <= vd; dz++) l.add(new long[]{key(cp.x + dx, cp.z + dz), dx * dx + dz * dz});
        // chunks never analysed go first, then nearest-first
        l.sort(Comparator.comparingLong((long[] a) -> results.containsKey(a[0]) ? 1 : 0).thenComparingLong(a -> a[1]));
        for (long[] a : l) queue.add(a[0]);
        entityPts.clear();
        if (!ents.b) return;
        for (Entity e : mc.world.getEntities()) {
            double soft = 0, proof = 0;
            if (e instanceof ItemFrameEntity) soft = 1.0;
            else if (e instanceof ChestMinecartEntity || e instanceof HopperMinecartEntity) soft = 1.5;
            else if (e instanceof ArmorStandEntity) soft = 0.5;
            else if (e instanceof VillagerEntity) soft = 0.3;
            else if (e instanceof PlayerEntity && e != mc.player && e != mc.getCameraEntity()) proof = 4.0;
            else if (e instanceof TameableEntity te && te.isTamed()) proof = 1.5;
            else if (e instanceof AbstractHorseEntity he && he.isTame()) proof = 1.0;
            if (soft + proof <= 0) continue;
            double[] a = entityPts.computeIfAbsent(key(e.getChunkPos().x, e.getChunkPos().z), k -> new double[2]);
            a[0] += soft; a[1] += proof;
        }
    }

    @Override public void onTick() {
        if (mc.world != world) {
            results.clear(); infos.clear(); ranked = List.of(); world = mc.world; home = mc.player.getEntityPos();
            dim = mc.world.getRegistryKey().getValue().getPath();
        }
        if (mc.getCameraEntity() == null) return;
        if (export.b) { export.b = false; export(); }
        if (queue.isEmpty() && mc.player.age - lastBuild > 100) rebuildQueue();
        for (int i = 0; i < speed.i() && !queue.isEmpty(); i++) {
            long k = queue.poll();
            int x = (int) (k >> 32), z = (int) k;
            WorldChunk ch = mc.world.getChunkManager().getWorldChunk(x, z);
            if (ch == null) { if (!remember.b) results.remove(k); continue; }
            Chunk r = analyse(ch);
            if (r == null) results.remove(k); else results.put(k, r);
        }
        if (results.size() > 6000) trim();
        if (mc.player.age - lastCluster >= 10) { lastCluster = mc.player.age; ranked = cluster(); }
    }

    void trim() {
        ChunkPos cp = mc.getCameraEntity().getChunkPos();
        List<Long> far = new ArrayList<>(results.keySet());
        far.sort(Comparator.comparingLong((Long k) -> -(sq((int) (k >> 32) - cp.x) + sq((int) (long) k - cp.z))));
        for (int i = 0; i < 1000 && i < far.size(); i++) results.remove(far.get(i));
    }
    static long sq(long v) { return v * v; }

    Chunk analyse(WorldChunk wc) {
        Chunk c = new Chunk();
        c.pos = wc.getPos();
        double[] sig = new double[NSIG];
        double[] pf = new double[2];                    // [0] proof, [1] soft
        if (blocks.b) {
            ChunkSection[] secs = wc.getSectionArray();
            for (int i = 0; i < secs.length; i++) {
                ChunkSection s = secs[i];
                if (s == null || s.isEmpty()) continue;
                boolean[] hit = {false};
                s.getBlockStateContainer().count((state, n) -> {
                    Info in = info(state.getBlock());
                    if (in == NONE) return;
                    double v = in.w() * Math.min(8.0, Math.sqrt(n));
                    if (in.sig() >= 0) { sig[in.sig()] += v; return; }
                    c.cat[in.cat()] += v;
                    pf[in.proof() ? 0 : 1] += v;
                    if (in.cat() != C_BUILD) hit[0] = true;
                });
                if (hit[0]) {
                    int base = (wc.getBottomSectionCoord() + i) * 16;
                    c.yMin = Math.min(c.yMin, base); c.yMax = Math.max(c.yMax, base + 16);
                }
            }
        }
        if (tiles.b) for (BlockEntity be : wc.getBlockEntities().values()) {
            double w; int cat = C_STORE; boolean proof = false;
            if (be instanceof ShulkerBoxBlockEntity) { w = dim.equals("the_end") ? 0.5 : 2.5; proof = !dim.equals("the_end"); }
            else if (be instanceof BeaconBlockEntity) { w = 6; cat = C_VAL; proof = true; }
            else if (be instanceof EnchantingTableBlockEntity) { w = 3; cat = C_UTIL; proof = true; }
            else if (be instanceof EnderChestBlockEntity) { w = 1.2; proof = true; }
            else if (be instanceof HopperBlockEntity) { w = 1.8; cat = C_RED; proof = true; }
            else if (be instanceof DispenserBlockEntity) { w = 1.0; cat = C_RED; }
            else if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity) w = 1.0;
            else if (be instanceof AbstractFurnaceBlockEntity || be instanceof BrewingStandBlockEntity) { w = 0.8; cat = C_UTIL; }
            else if (be instanceof SignBlockEntity) { w = 0.5; cat = C_SIGN; proof = true; }
            else if (be instanceof BedBlockEntity) { w = 0.5; cat = C_BED; }
            else if (be instanceof BannerBlockEntity) { w = 0.4; cat = C_DECOR; }
            else continue;
            c.cat[cat] += w; pf[proof ? 0 : 1] += w;
            c.yMin = Math.min(c.yMin, be.getPos().getY()); c.yMax = Math.max(c.yMax, be.getPos().getY() + 1);
        }
        double[] ep = entityPts.get(key(c.pos.x, c.pos.z));
        if (ep != null) { c.cat[C_PEOPLE] += ep[0] + ep[1]; pf[1] += ep[0]; pf[0] += ep[1]; }

        double nf = 0;
        for (double s : sig) nf = Math.max(nf, s / (s + 10.0));
        c.nf = Math.min(0.8, nf);
        c.proof = pf[0]; c.soft = pf[1];
        int cats = 0;
        for (double v : c.cat) if (v >= 1.0) cats++;
        c.total = (c.proof + c.soft * (1 - c.nf)) * (1 + 0.15 * Math.max(0, cats - 1));
        if (c.total < 0.8) return null;
        return c;
    }

    // ------------------------------------------------------------------ clustering
    List<Cluster> cluster() {
        Set<Long> seen = new HashSet<>();
        List<Cluster> out = new ArrayList<>();
        for (var e : results.entrySet()) {
            if (seen.contains(e.getKey()) || e.getValue().total < 2.5) continue;
            ArrayDeque<Long> q = new ArrayDeque<>();
            q.add(e.getKey()); seen.add(e.getKey());
            double sum = 0, wx = 0, wz = 0, nfw = 0;
            double[] cat = new double[CAT.length];
            int yMin = Integer.MAX_VALUE, yMax = Integer.MIN_VALUE, x0 = Integer.MAX_VALUE, x1 = Integer.MIN_VALUE, z0 = Integer.MAX_VALUE, z1 = Integer.MIN_VALUE, n = 0;
            while (!q.isEmpty() && n < 40) {
                long k = q.poll();
                Chunk ch = results.get(k);
                n++;
                sum += ch.total; nfw += ch.nf * ch.total;
                wx += (ch.pos.getStartX() + 8) * ch.total; wz += (ch.pos.getStartZ() + 8) * ch.total;
                for (int i = 0; i < cat.length; i++) cat[i] += ch.cat[i];
                if (ch.yMin != Integer.MAX_VALUE) { yMin = Math.min(yMin, ch.yMin); yMax = Math.max(yMax, ch.yMax); }
                x0 = Math.min(x0, ch.pos.getStartX()); x1 = Math.max(x1, ch.pos.getStartX() + 16);
                z0 = Math.min(z0, ch.pos.getStartZ()); z1 = Math.max(z1, ch.pos.getStartZ() + 16);
                int cx = ch.pos.x, cz = ch.pos.z;
                for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
                    long nk = key(cx + dx, cz + dz);
                    Chunk nc = results.get(nk);
                    if (nc == null || seen.contains(nk) || nc.total < 1.2) continue;
                    seen.add(nk); q.add(nk);
                }
            }
            if (n < minChunks.i()) continue;
            double nf = sum > 0 ? nfw / sum : 0;
            double conf = 100 * (1 - Math.exp(-sum / K));
            if (hideNatural.b && nf > 0.6) continue;
            if (conf < minConf.v) continue;
            if (yMin == Integer.MAX_VALUE) { yMin = (int) mc.player.getY() - 8; yMax = (int) mc.player.getY() + 16; }
            double cx = wx / sum, cz = wz / sum;
            if (ignoreNear.v > 0 && home != null && Math.hypot(cx - home.x, cz - home.z) < ignoreNear.v) continue;
            Box box = new Box(x0, yMin, z0, x1, yMax, z1);
            out.add(new Cluster(conf, box, new Vec3d(cx, (yMin + yMax) / 2.0, cz), classify(cat, sum, nf), why(cat), n, nf));
        }
        out.sort(Comparator.comparingDouble((Cluster c) -> -c.conf).thenComparingInt(c -> -c.chunks));
        return out.size() > top.i() ? new ArrayList<>(out.subList(0, top.i())) : out;
    }

    static String classify(double[] cat, double sum, double nf) {
        if (nf > 0.55) return "Natural?";
        if (cat[C_RED] >= Math.max(6, 0.45 * sum)) return "Redstone/Farm";
        if (cat[C_STORE] >= 8 && cat[C_STORE] >= 0.45 * sum) return "Stash";
        if (cat[C_BED] >= 1.5 || cat[C_UTIL] >= 3) return "Base";
        return "Structure";
    }

    static String why(double[] cat) {
        Integer[] idx = new Integer[cat.length];
        for (int i = 0; i < idx.length; i++) idx[i] = i;
        Arrays.sort(idx, (a, b) -> Double.compare(cat[b], cat[a]));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 3; i++) if (cat[idx[i]] >= 1) sb.append(sb.length() > 0 ? ", " : "").append(CAT[idx[i]]).append(' ').append((int) Math.round(cat[idx[i]]));
        return sb.toString();
    }

    void export() {
        try {
            Path p = FabricLoader.getInstance().getConfigDir().resolve("gokumod");
            Files.createDirectories(p);
            StringBuilder sb = new StringBuilder("# Base Finder AI export (" + dim + ")\n");
            for (Cluster c : ranked) sb.append(String.format("%s %d%% x=%d y=%d z=%d chunks=%d  %s%n", c.type, (int) c.conf, (int) c.center.x, (int) c.center.y, (int) c.center.z, c.chunks, c.why));
            Files.writeString(p.resolve("base-ai.txt"), sb.toString());
            mc.player.sendMessage(net.minecraft.text.Text.literal("[Goku] Exported " + ranked.size() + " candidates to config/gokumod/base-ai.txt"), true);
        } catch (Exception e) { mc.player.sendMessage(net.minecraft.text.Text.literal("[Goku] Export failed"), true); }
    }

    /** Best candidate position (for Auto Find), or null. */
    public Vec3d best() { return ranked.isEmpty() ? null : new Vec3d(ranked.get(0).center.x, mc.player.getY(), ranked.get(0).center.z); }

    static String compass(double dx, double dz) {
        int i = (int) Math.round(Math.toDegrees(Math.atan2(dz, dx)) / 45.0 + 8) % 8;   // atan2(dz,dx): 0=east(+x), 90=south(+z)
        return new String[]{"E", "SE", "S", "SW", "W", "NW", "N", "NE"}[i];
    }

    @Override public void onRender(DrawContext c, float td) {
        if (!Projector.ok) return;
        int col = Draw.COLORS[3];
        if (hud.b) {
            Esp.hud(c, "Base AI v2: " + results.size() + " chunks known, " + ranked.size() + " candidates" + (queue.isEmpty() ? "" : " (scanning " + queue.size() + ")"), Modules.accent());
            for (Cluster r : ranked) {
                double dx = r.center.x - mc.player.getX(), dz = r.center.z - mc.player.getZ();
                Esp.hud(c, String.format(" %s %dm  [%d, %d, %d] %d%% %s  %s", compass(dx, dz), (int) Math.hypot(dx, dz), (int) r.center.x, (int) r.center.y, (int) r.center.z, (int) r.conf, r.type, r.why), col);
            }
        }
        boolean first = true;
        for (Cluster r : ranked) {
            double dist = r.center.distanceTo(Projector.cam);
            int cl = Esp.a(r.conf >= 80 ? 0xFFFF4040 : col, 255);
            Esp.box(c, r.box, first ? 0xFFFF4040 : cl, style.idx, fill.b, first ? 2 : 1);
            if (first && tracer.b) Esp.tracer(c, r.center, 0xFFFF4040, 0, 1);
            if (labels.b) {
                double[] p = Projector.to(new Vec3d(r.center.x, r.box.maxY + 0.5, r.center.z));
                if (p != null) Esp.label(c, r.type.toUpperCase() + " " + (int) r.conf + "%  " + (int) dist + "m", (int) p[0], (int) p[1] - 11, first ? 0xFFFF4040 : cl);
            }
            first = false;
        }
    }
}
