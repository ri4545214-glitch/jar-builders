package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Draw;
import com.goku.util.Projector;
import net.minecraft.block.entity.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.List;

public class StorageEsp extends Module {
    final Setting chests = add(Setting.bool("Chests", true));
    final Setting hoppers = add(Setting.bool("Hoppers", true));
    final Setting shulkers = add(Setting.bool("Shulkers", true));
    final Setting ender = add(Setting.bool("Ender Chests", false));
    final Setting range = add(Setting.num("Range (0=inf)", 0, 0, 1000, 10));
    final Setting labels = add(Setting.bool("Labels", true));
    final Setting fill = add(Setting.bool("Fill", true));

    record Found(BlockPos pos, int color, String label) {}
    List<Found> found = List.of();

    public StorageEsp() { super("Storage ESP"); }

    @Override public void onTick() {
        if (mc.player.age % 10 != 0) return;
        List<Found> out = new ArrayList<>();
        ChunkPos cp = mc.getCameraEntity().getChunkPos();
        int vd = mc.options.getViewDistance().getValue() + 2;
        for (int dx = -vd; dx <= vd; dx++) for (int dz = -vd; dz <= vd; dz++) {
            WorldChunk ch = mc.world.getChunkManager().getWorldChunk(cp.x + dx, cp.z + dz);
            if (ch == null) continue;
            for (BlockEntity be : ch.getBlockEntities().values()) {
                if (be instanceof ChestBlockEntity && chests.b) {
                    boolean t = be instanceof TrappedChestBlockEntity;
                    out.add(new Found(be.getPos(), t ? 0xFFFF4444 : 0xFFFFAA33, t ? "Trapped Chest" : "Chest"));
                } else if (be instanceof HopperBlockEntity && hoppers.b) {
                    out.add(new Found(be.getPos(), 0xFFAAAAAA, "Hopper"));
                } else if (be instanceof ShulkerBoxBlockEntity && shulkers.b) {
                    out.add(new Found(be.getPos(), 0xFFFF55FF, "Shulker"));
                } else if (be instanceof EnderChestBlockEntity && ender.b) {
                    out.add(new Found(be.getPos(), 0xFF44CCAA, "Ender Chest"));
                }
            }
        }
        found = out;
    }

    @Override public void onRender(DrawContext c, float td) {
        if (!Projector.ok) return;
        for (Found f : found) {
            double dist = f.pos.toCenterPos().distanceTo(Projector.cam);
            if (range.v > 0 && dist > range.v) continue;
            int[] b = Projector.box(new Box(f.pos));
            if (b == null) continue;
            if (fill.b) c.fill(b[0], b[1], b[2], b[3], (f.color & 0xFFFFFF) | 0x33000000);
            Draw.outline(c, b[0], b[1], b[2], b[3], f.color);
            if (labels.b) Draw.text(c, f.label + " " + (int) dist + "m", (b[0] + b[2]) / 2, b[1] - 10, f.color);
        }
    }

    @Override public void onDisable() { found = List.of(); }
}
