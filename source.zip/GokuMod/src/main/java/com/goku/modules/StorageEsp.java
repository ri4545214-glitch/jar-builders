package com.goku.modules;

import com.goku.Setting;
import net.minecraft.block.BlockState;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.enums.ChestType;
import net.minecraft.block.entity.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.Set;

/** Storage ESP: merged double chests, accurate chest hitboxes, 3D wire boxes, tracers, per-type colours, summary HUD. */
public class StorageEsp extends BlockEntityEsp {
    final Setting chests = add(Setting.bool("Chests", true));
    final Setting trapped = add(Setting.bool("Trapped Chests", true));
    final Setting barrels = add(Setting.bool("Barrels", true));
    final Setting shulkers = add(Setting.bool("Shulker Boxes", true));
    final Setting ender = add(Setting.bool("Ender Chests", false));
    final Setting hoppers = add(Setting.bool("Hoppers", true));
    final Setting furnaces = add(Setting.bool("Furnaces", false));
    final Setting dispensers = add(Setting.bool("Disp./Dropper", false));
    final Setting merge = add(Setting.bool("Merge Doubles", true));

    public StorageEsp() { super("Storage ESP", 10); common(); }

    static Box chestBox(BlockPos p) {
        return new Box(p.getX() + 0.0625, p.getY(), p.getZ() + 0.0625, p.getX() + 0.9375, p.getY() + 0.875, p.getZ() + 0.9375);
    }

    Found chest(BlockEntity be, Set<BlockPos> used, int col, String name) {
        BlockState s = be.getCachedState();
        BlockPos p = be.getPos();
        Box box = chestBox(p);
        if (merge.b && s.contains(ChestBlock.CHEST_TYPE) && s.get(ChestBlock.CHEST_TYPE) != ChestType.SINGLE) {
            BlockPos o = p.offset(ChestBlock.getFacing(s));
            used.add(o);
            box = box.union(chestBox(o));
            name = "Double " + name;
        }
        return Found.of(box, col, name);
    }

    @Override protected Found classify(BlockEntity be, Set<BlockPos> used) {
        BlockPos p = be.getPos();
        if (be instanceof TrappedChestBlockEntity) return trapped.b ? chest(be, used, 0xFFFF4444, "Trapped Chest") : null;
        if (be instanceof ChestBlockEntity) return chests.b ? chest(be, used, 0xFFFFAA33, "Chest") : null;
        if (be instanceof EnderChestBlockEntity) return ender.b ? Found.of(chestBox(p), 0xFF44CCAA, "Ender Chest") : null;
        if (be instanceof BarrelBlockEntity) return barrels.b ? Found.of(new Box(p).contract(0.03), 0xFFC98A4B, "Barrel") : null;
        if (be instanceof ShulkerBoxBlockEntity) return shulkers.b ? Found.of(new Box(p).contract(0.03), 0xFFFF55FF, "Shulker") : null;
        if (be instanceof HopperBlockEntity) return hoppers.b ? Found.of(new Box(p).contract(0.05), 0xFFBBBBBB, "Hopper") : null;
        if (be instanceof AbstractFurnaceBlockEntity)
            return furnaces.b ? Found.of(new Box(p).contract(0.03), 0xFFFF7733, be.getCachedState().getBlock().getName().getString()) : null;
        if (be instanceof DispenserBlockEntity)
            return dispensers.b ? Found.of(new Box(p).contract(0.03), 0xFF8899FF, be.getCachedState().getBlock().getName().getString()) : null;
        return null;
    }
}
