package com.goku.modules;

import com.goku.Setting;
import net.minecraft.block.BlockState;
import net.minecraft.block.BedBlock;
import net.minecraft.block.enums.BedPart;
import net.minecraft.block.entity.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.Set;

/** Base Finder: highlights block entities that players only place when they live somewhere. */
public class BaseEsp extends BlockEntityEsp {
    final Setting beds = add(Setting.bool("Beds", true));
    final Setting signs = add(Setting.bool("Signs", false));
    final Setting beacons = add(Setting.bool("Beacons", true));
    final Setting utility = add(Setting.bool("Utility Blocks", true));
    final Setting banners = add(Setting.bool("Banners", false));
    final Setting pots = add(Setting.bool("Decorated Pots", false));
    final Setting command = add(Setting.bool("Command Blocks", true));

    public BaseEsp() { super("Base Finder", 20); common(); }

    @Override protected Found classify(BlockEntity be, Set<BlockPos> used) {
        BlockPos p = be.getPos();
        BlockState s = be.getCachedState();
        if (be instanceof BedBlockEntity) {
            if (!beds.b || (s.contains(BedBlock.PART) && s.get(BedBlock.PART) != BedPart.HEAD)) return null;
            return Found.of(new Box(p).withMaxY(p.getY() + 0.5625), 0xFFFF5577, "Bed");
        }
        if (be instanceof BeaconBlockEntity) return beacons.b ? Found.of(new Box(p), 0xFF55FFFF, "Beacon") : null;
        if (be instanceof SignBlockEntity) return signs.b ? Found.of(new Box(p).contract(0.15), 0xFFD8C27A, "Sign") : null;
        if (be instanceof BannerBlockEntity) return banners.b ? Found.of(new Box(p).contract(0.1), 0xFFEEEEEE, "Banner") : null;
        if (be instanceof DecoratedPotBlockEntity) return pots.b ? Found.of(new Box(p).contract(0.12), 0xFFCC7755, "Pot") : null;
        if (be instanceof CommandBlockBlockEntity) return command.b ? Found.of(new Box(p), 0xFFFF8800, "Command Block") : null;
        if (utility.b && (be instanceof EnchantingTableBlockEntity || be instanceof BrewingStandBlockEntity
                || be instanceof LecternBlockEntity || be instanceof JukeboxBlockEntity
                || be instanceof BellBlockEntity || be instanceof CrafterBlockEntity))
            return Found.of(new Box(p).contract(0.05), 0xFF66EE88, be.getCachedState().getBlock().getName().getString());
        return null;
    }
}
