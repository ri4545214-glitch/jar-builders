package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Esp;
import com.goku.util.Projector;
import com.goku.util.Scan;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.*;

/** Shared base for block-entity ESPs: scan cache, 3D boxes, tracers, labels, distance fade, summary. */
public abstract class BlockEntityEsp extends Module {
    public record Found(Box box, Vec3d center, int color, String label) {
        public static Found of(Box b, int color, String label) { return new Found(b, b.getCenter(), color, label); }
    }

    protected final Setting style = Setting.mode("Box Style", 1, Esp.STYLES);
    protected final Setting fill = Setting.bool("Fill", true);
    protected final Setting labels = Setting.bool("Labels", true);
    protected final Setting showDist = Setting.bool("Distance", true);
    protected final Setting fade = Setting.bool("Distance Fade", true);
    protected final Setting tracers = Setting.bool("Tracers", false);
    protected final Setting origin = Setting.mode("Tracer From", 0, Esp.ORIGINS);
    protected final Setting width = Setting.num("Line Width", 1, 1, 4, 1);
    protected final Setting range = Setting.num("Range (0=inf)", 0, 0, 1000, 10);
    protected final Setting summary = Setting.bool("Summary HUD", true);

    private final int scanEvery;
    private List<Found> found = List.of();
    private Map<String, Integer> counts = Map.of();

    protected BlockEntityEsp(String name, int scanEvery) { super(name); this.scanEvery = scanEvery; }

    /** Call at the end of the subclass constructor so type toggles come first in the GUI. */
    protected void common() {
        add(style); add(fill); add(labels); add(showDist); add(fade); add(tracers); add(origin); add(width); add(range); add(summary);
    }

    /** Return a Found for this block entity or null to skip it. May add extra positions to 'used' (e.g. other half of a double chest). */
    protected abstract Found classify(BlockEntity be, Set<BlockPos> used);

    @Override public void onTick() {
        if (mc.player.age % scanEvery != 0) return;
        List<Found> out = new ArrayList<>();
        Map<String, Integer> cnt = new TreeMap<>();
        Set<BlockPos> used = new HashSet<>();
        for (BlockEntity be : Scan.blockEntities(mc)) {
            if (used.contains(be.getPos())) continue;
            Found f = classify(be, used);
            if (f == null) continue;
            used.add(be.getPos());
            out.add(f);
            cnt.merge(f.label(), 1, Integer::sum);
        }
        found = out; counts = cnt;
    }

    @Override public void onRender(DrawContext c, float td) {
        if (!Projector.ok) return;
        if (summary.b && !counts.isEmpty()) {
            StringBuilder sb = new StringBuilder(name + ": ");
            int i = 0;
            for (var e : counts.entrySet()) { if (i++ > 0) sb.append("  "); sb.append(e.getValue()).append(' ').append(e.getKey()); }
            Esp.hud(c, sb.toString(), Modules_accent());
        }
        for (Found f : found) {
            double dist = f.center().distanceTo(Projector.cam);
            if (range.v > 0 && dist > range.v) continue;
            int col = fade.b ? Esp.fade(f.color(), dist, range.v) : f.color();
            Esp.box(c, f.box(), col, style.idx, fill.b, width.i());
            if (tracers.b) Esp.tracer(c, f.center(), col, origin.idx, width.i());
            if (labels.b || showDist.b) {
                double[] p = Projector.to(new Vec3d(f.center().x, f.box().maxY + 0.2, f.center().z));
                if (p == null) continue;
                String t = (labels.b ? f.label() : "") + (showDist.b ? (labels.b ? " " : "") + (int) dist + "m" : "");
                Esp.label(c, t, (int) p[0], (int) p[1] - 11, col);
            }
        }
    }

    @Override public void onDisable() { found = List.of(); counts = Map.of(); }

    private static int Modules_accent() { return com.goku.Modules.accent(); }
}
