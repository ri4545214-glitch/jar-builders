package com.goku.modules;

import com.goku.Config;
import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Sfx;
import net.minecraft.text.Text;

/** Save/Load buttons and profiles. Settings are stored in config/gokumod/<profile>.json; the last saved config loads at startup. */
public class ConfigModule extends Module {
    public final Setting profile = add(Setting.mode("Profile", 0, "default", "pvp", "base", "legit"));
    public final Setting save = add(Setting.bool("> Save Config", false));
    public final Setting load = add(Setting.bool("> Load Config", false));
    public final Setting reset = add(Setting.bool("> Reset All", false));
    public final Setting auto = add(Setting.bool("Auto Save On Close", true));

    public ConfigModule() { super("Config"); toggleable = false; open = true; }

    void msg(String s) { if (mc.player != null) mc.player.sendMessage(Text.literal("[Goku] " + s), true); }

    public void poll() {
        if (save.b) { save.b = false; msg(Config.save(profile.modeName()) ? "Saved profile '" + profile.modeName() + "'" : "Save failed"); Sfx.play("on", 1f); }
        if (load.b) { load.b = false; msg(Config.load(profile.modeName()) ? "Loaded profile '" + profile.modeName() + "'" : "No saved profile '" + profile.modeName() + "'"); Sfx.play("on", 1f); }
        if (reset.b) { reset.b = false; Config.reset(); msg("All settings reset"); Sfx.play("off", 1f); }
    }
}
