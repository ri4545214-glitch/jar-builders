package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Nav;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

public class AutoMine extends Module {
    final Setting mode = add(Setting.mode("Mode", 0, "Hold", "Tunnel"));
    final Setting autoTool = add(Setting.bool("Auto Tool", true));
    final Setting avoidLiquid = add(Setting.bool("Stop At Lava/Water", true));
    final Setting stopFull = add(Setting.bool("Stop On Full Inventory", false));
    int phase;

    public AutoMine() { super("Auto Mine"); }

    @Override public void onDisable() { if (mc.player != null) { mc.options.attackKey.setPressed(false); Nav.release(); } phase = 0; }

    void pickTool(BlockState st) {
        int best = -1; float bs = mc.player.getInventory().getStack(Inv.selected()).getMiningSpeedMultiplier(st);
        for (int i = 0; i < 9; i++) {
            float s = mc.player.getInventory().getStack(i).getMiningSpeedMultiplier(st);
            if (s > bs + 0.01f) { bs = s; best = i; }
        }
        if (best >= 0) Inv.select(best);
    }

    @Override public void onPreTick() {
        if (mc.currentScreen != null || Modules.FREECAM.enabled) return;
        if (stopFull.b && mc.player.getInventory().getEmptySlot() < 0) { setEnabled(false); return; }
        boolean tunnel = mode.idx == 1;
        if (mc.crosshairTarget instanceof BlockHitResult hr && hr.getType() == HitResult.Type.BLOCK) {
            BlockState st = mc.world.getBlockState(hr.getBlockPos());
            if (!st.isAir() && !st.isOf(Blocks.BEDROCK)) {
                if (avoidLiquid.b) {
                    for (var d : net.minecraft.util.math.Direction.values())
                        if (!mc.world.getFluidState(hr.getBlockPos().offset(d)).isEmpty()) { mc.options.attackKey.setPressed(false); Nav.release(); return; }
                }
                if (autoTool.b) pickTool(st);
                mc.options.attackKey.setPressed(true);
                mc.options.forwardKey.setPressed(false);
                return;
            }
        }
        mc.options.attackKey.setPressed(false);
        if (!tunnel) return;
        // 1x2 tunnel: alternate between head-level and feet-level, walk once both are clear
        if (phase == 0) { mc.player.setPitch(0f); phase = 1; }
        else { mc.player.setPitch(40f); phase = 0; mc.options.forwardKey.setPressed(true); return; }
        mc.options.forwardKey.setPressed(false);
    }
}
