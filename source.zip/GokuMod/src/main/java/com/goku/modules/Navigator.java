package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Esp;
import com.goku.util.Inv;
import com.goku.util.Nav;
import com.goku.util.Pathing;
import com.goku.util.Sfx;
import com.goku.util.Targets;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.mob.WardenEntity;
import net.minecraft.entity.mob.ZombifiedPiglinEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.util.*;
import java.util.function.Predicate;

/**
 * Navigator: pick an ore, biome, structure or waypoint (Settings hub > Navigate) and it walks you there with an A* path through
 * the loaded world - tunnelling to buried ores when allowed - while a built-in guardian fights off monsters, eats / drinks healing,
 * runs from what it can not beat, and can leave the game before you die.
 * Ores, biomes and structures are located from the chunks your client has loaded (structures by their typical blocks).
 */
public class Navigator extends Module {
    // ------------------------------------------------------------ target catalogue
    public static final String[] ORES = XRay.NAMES;
    public static final String[] BIOMES = {"plains", "sunflower_plains", "forest", "flower_forest", "birch_forest", "dark_forest", "cherry_grove", "taiga", "snowy_taiga",
            "old_growth_pine_taiga", "snowy_plains", "ice_spikes", "desert", "savanna", "badlands", "eroded_badlands", "jungle", "bamboo_jungle", "swamp", "mangrove_swamp",
            "meadow", "windswept_hills", "jagged_peaks", "frozen_peaks", "stony_peaks", "mushroom_fields", "beach", "river", "lush_caves", "dripstone_caves", "deep_dark",
            "nether_wastes", "crimson_forest", "warped_forest", "soul_sand_valley", "basalt_deltas"};
    public static final String[] STRUCTS = {"Village", "Mineshaft", "Stronghold", "Nether Fortress", "Bastion Remnant", "Ancient City", "Ocean Monument", "End City",
            "Trial Chambers", "Dungeon / Spawner", "Ruined Portal", "Loot Chest"};
    static final Block[][] STRUCT_BLOCKS = {
            {Blocks.BELL}, {Blocks.RAIL}, {Blocks.END_PORTAL_FRAME}, {Blocks.NETHER_BRICK_FENCE}, {Blocks.GILDED_BLACKSTONE}, {Blocks.REINFORCED_DEEPSLATE},
            {Blocks.PRISMARINE_BRICKS}, {Blocks.PURPUR_PILLAR}, {Blocks.TRIAL_SPAWNER, Blocks.VAULT}, {Blocks.SPAWNER}, {Blocks.CRYING_OBSIDIAN}, {Blocks.CHEST}};

    public static String biomeName(int i) {
        StringBuilder sb = new StringBuilder();
        for (String w : BIOMES[i].split("_")) sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1)).append(' ');
        return sb.toString().trim();
    }

    // ------------------------------------------------------------ settings
    final Setting dig = add(Setting.bool("Tunnel Through Blocks", true));
    final Setting maxDrop = add(Setting.num("Max Drop (blocks)", 3, 1, 5, 1));
    final Setting sprint = add(Setting.bool("Sprint", true));
    final Setting mineOre = add(Setting.bool("Mine The Ore On Arrival", true));
    final Setting defend = add(Setting.bool("Guardian: Fight Monsters", true));
    final Setting defendRange = add(Setting.num("Guardian Range", 8, 3, 16, 1));
    final Setting healAt = add(Setting.num("Heal / Eat At HP", 10, 2, 19, 1));
    final Setting fleeAt = add(Setting.num("Run Away At HP", 6, 1, 15, 1));
    final Setting hunger = add(Setting.num("Eat When Food Below", 14, 4, 19, 1));
    final Setting panic = add(Setting.num("Leave Game At HP (0=off)", 0, 0, 10, 1));
    final Setting totemHelp = add(Setting.bool("Auto-Enable Auto Totem", true));
    final Setting clutchHelp = add(Setting.bool("Auto-Enable Water Clutch", true));
    final Setting wardenStop = add(Setting.bool("Stop If A Warden Is Near", true));
    final Setting scanChunks = add(Setting.num("Scan Radius (chunks)", 8, 3, 16, 1));
    final Setting showPath = add(Setting.bool("Show Path", true));
    final Setting hud = add(Setting.bool("Status HUD", true));

    // ------------------------------------------------------------ scan results (read by the GUI)
    public volatile BlockPos[] oreHit = new BlockPos[ORES.length], biomeHit = new BlockPos[BIOMES.length], structHit = new BlockPos[STRUCTS.length];
    final Map<Block, int[]> blockTargets = new HashMap<>();
    final Map<String, Integer> biomeIndex = new HashMap<>();
    BlockPos[] tOre, tBiome, tStruct; double[] dOre, dBiome, dStruct;
    final ArrayDeque<int[]> queue = new ArrayDeque<>();
    int idleScan = 60, scanTicks;
    public String scanStatus = "";

    // ------------------------------------------------------------ run state
    public int tKind = -1, tIdx;
    BlockPos tFixed;
    public String tName = "";
    List<Pathing.Step> path = List.of();
    Pathing.Search search;
    boolean planReached;
    int pi, progressTick, fails, planTick, heading, eatT, eatPrev = -1, searchSwap;
    double bestDist = 1e9;
    String status = "idle";
    boolean wasTotem, wasClutch;
    boolean forced; // helpers switched on by us

    public Navigator() {
        super("Navigator");
        for (int i = 0; i < XRay.BLOCKS.length; i++) for (Block b : XRay.BLOCKS[i]) blockTargets.merge(b, new int[]{i}, (a, c) -> concat(a, c));
        for (int i = 0; i < STRUCT_BLOCKS.length; i++) for (Block b : STRUCT_BLOCKS[i]) blockTargets.merge(b, new int[]{100 + i}, (a, c) -> concat(a, c));
        for (int i = 0; i < BIOMES.length; i++) biomeIndex.put(BIOMES[i], i);
    }

    static int[] concat(int[] a, int[] b) { int[] r = Arrays.copyOf(a, a.length + b.length); System.arraycopy(b, 0, r, a.length, b.length); return r; }

    // ------------------------------------------------------------ public API (GUI)
    /** kind: 0 ore, 1 biome, 2 structure. */
    public void go(int kind, int idx) {
        tKind = kind; tIdx = idx; tFixed = null;
        tName = kind == 0 ? ORES[idx] : kind == 1 ? biomeName(idx) : STRUCTS[idx];
        begin();
    }

    public void goTo(BlockPos p, String name) {
        tKind = 3; tFixed = p; tName = name;
        begin();
    }

    void begin() {
        if (enabled) { reset(); status = "planning"; } else setEnabled(true);
    }

    public String status() { return enabled ? status : "idle"; }

    public BlockPos nearest(int kind, int idx) { return kind == 0 ? oreHit[idx] : kind == 1 ? biomeHit[idx] : structHit[idx]; }

    /** Ask for a fresh scan for a few seconds (the Hub calls this while its Navigate tab is open). */
    public void requestScan() { scanTicks = 60; }

    BlockPos targetPos() { return tKind == 3 ? tFixed : tKind == 0 ? oreHit[tIdx] : tKind == 1 ? biomeHit[tIdx] : tKind == 2 ? structHit[tIdx] : null; }

    // ------------------------------------------------------------ life cycle
    void reset() { path = List.of(); search = null; pi = 0; progressTick = 0; fails = 0; bestDist = 1e9; eatT = 0; planTick = 0; }

    void chat(String s) { if (mc.player != null) mc.player.sendMessage(Text.literal("[Goku] " + s), false); }

    @Override public void onEnable() {
        if (mc.player == null || tKind < 0) { setEnabled(false); if (mc.player != null) chat("Pick a target in the Settings hub (pause menu) > Navigate."); return; }
        reset();
        heading = (int) mc.player.getYaw();
        status = "locating " + tName;
        wasTotem = Modules.TOTEM.enabled; wasClutch = Modules.CLUTCH.enabled;
        if (totemHelp.b && !wasTotem) Modules.TOTEM.setEnabled(true);
        if (clutchHelp.b && !wasClutch) Modules.CLUTCH.setEnabled(true);
        chat("Navigating to nearest " + tName + ". Press the Navigator toggle (or Stop in the hub) to cancel.");
    }

    @Override public void onDisable() {
        if (mc.player != null) { Nav.release(); mc.options.attackKey.setPressed(false); mc.options.useKey.setPressed(false); }
        if (totemHelp.b && !wasTotem) Modules.TOTEM.setEnabled(false);
        if (clutchHelp.b && !wasClutch) Modules.CLUTCH.setEnabled(false);
        reset();
    }

    void stop(String why) {
        chat("Navigator: " + why);
        status = why;
        Sfx.play("off", 1f);
        setEnabled(false);
    }

    // ------------------------------------------------------------ scanning (runs a few chunks per tick)
    public void scanTick() {
        if (mc.world == null || mc.player == null) return;
        if (scanTicks > 0) scanTicks--; else if (!enabled) return;
        if (queue.isEmpty()) {
            if (++idleScan < 40) return;
            idleScan = 0;
            int r = Math.min(scanChunks.i(), mc.options.getViewDistance().getValue());
            int pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4;
            List<int[]> l = new ArrayList<>();
            for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) l.add(new int[]{pcx + dx, pcz + dz, dx * dx + dz * dz});
            l.sort(Comparator.comparingInt(a -> a[2]));
            queue.addAll(l);
            tOre = new BlockPos[ORES.length]; tBiome = new BlockPos[BIOMES.length]; tStruct = new BlockPos[STRUCTS.length];
            dOre = new double[ORES.length]; dBiome = new double[BIOMES.length]; dStruct = new double[STRUCTS.length];
            Arrays.fill(dOre, 1e18); Arrays.fill(dBiome, 1e18); Arrays.fill(dStruct, 1e18);
        }
        for (int n = 0; n < 3 && !queue.isEmpty(); n++) {
            int[] c = queue.poll();
            WorldChunk ch = mc.world.getChunkManager().getWorldChunk(c[0], c[1]);
            if (ch != null) scanChunk(ch, c[0], c[1]);
        }
        if (queue.isEmpty()) {
            for (Entity e : mc.world.getEntities()) if (e instanceof VillagerEntity v) hit(2, 0, v.getBlockPos(), v.getEntityPos());
            oreHit = tOre; biomeHit = tBiome; structHit = tStruct;
            scanStatus = "scanned";
        }
    }

    void hit(int kind, int idx, BlockPos p, Vec3d at) {
        Vec3d me = mc.player.getEntityPos();
        double d = (at.x - me.x) * (at.x - me.x) + (at.y - me.y) * (at.y - me.y) + (at.z - me.z) * (at.z - me.z);
        BlockPos[] pos = kind == 0 ? tOre : kind == 1 ? tBiome : tStruct;
        double[] dist = kind == 0 ? dOre : kind == 1 ? dBiome : dStruct;
        if (d < dist[idx]) { dist[idx] = d; pos[idx] = p; }
    }

    void scanChunk(WorldChunk ch, int cx, int cz) {
        ChunkSection[] secs = ch.getSectionArray();
        BlockPos.Mutable mp = new BlockPos.Mutable();
        for (int i = 0; i < secs.length; i++) {
            ChunkSection s = secs[i];
            if (s == null || s.isEmpty()) continue;
            boolean[] any = {false};
            s.getBlockStateContainer().count((st, n) -> { if (n > 0 && blockTargets.containsKey(st.getBlock())) any[0] = true; });
            if (!any[0]) continue;
            int baseY = (ch.getBottomSectionCoord() + i) * 16;
            for (int x = 0; x < 16; x++) for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) {
                int[] codes = blockTargets.get(s.getBlockState(x, y, z).getBlock());
                if (codes == null) continue;
                BlockPos p = new BlockPos(cx * 16 + x, baseY + y, cz * 16 + z);
                for (int code : codes) {
                    if (code >= 100) hit(2, code - 100, p, Vec3d.ofCenter(p)); else hit(0, code, p, Vec3d.ofCenter(p));
                }
            }
        }
        // biomes: sample a coarse grid at the surface and at the player's height
        int py = mc.player.getBlockY();
        for (int x = 2; x < 16; x += 4) for (int z = 2; z < 16; z += 4) {
            int wx = cx * 16 + x, wz = cz * 16 + z;
            int top = mc.world.getTopY(Heightmap.Type.WORLD_SURFACE, wx, wz);
            int[] ys = {top - 1, py};
            for (int y : ys) {
                mp.set(wx, y, wz);
                String id = mc.world.getBiome(mp).getKey().map(k -> k.getValue().getPath()).orElse("");
                Integer bi = biomeIndex.get(id);
                if (bi != null) { BlockPos p = new BlockPos(wx, y, wz); hit(1, bi, p, Vec3d.ofCenter(p)); }
            }
        }
    }

    boolean biomeIs(BlockPos p, String id) {
        return mc.world.getBiome(p).getKey().map(k -> k.getValue().getPath().equals(id)).orElse(false);
    }

    // ------------------------------------------------------------ main loop
    @Override public void onPreTick() {
        var p = mc.player;
        if (p == null || mc.world == null) return;
        if (mc.currentScreen != null) { Nav.release(); mc.options.attackKey.setPressed(false); return; }
        if (!p.isAlive()) { stop("you died"); return; }
        scanTicks = 40;
        if (guardian()) return;
        navigate();
    }

    static int man(BlockPos a, BlockPos b) { return Math.abs(a.getX() - b.getX()) + Math.abs(a.getY() - b.getY()) + Math.abs(a.getZ() - b.getZ()); }

    boolean arrived(BlockPos tp, BlockPos feet) {
        if (tKind == 1) return biomeIs(feet, BIOMES[tIdx]);
        if (tp == null) return false;
        if (tKind == 0) return man(feet, tp) == 1 || man(feet.up(), tp) == 1;
        double hd = Math.hypot(feet.getX() - tp.getX(), feet.getZ() - tp.getZ());
        return hd <= (tKind == 3 ? 2.5 : 5) && Math.abs(feet.getY() - tp.getY()) <= 3;
    }

    void navigate() {
        var p = mc.player;
        BlockPos feet = p.getBlockPos();
        BlockPos tp = targetPos();
        if (arrived(tp, feet)) { finish(tp); return; }
        if (!p.isOnGround() && !p.isTouchingWater()) { status = "falling"; return; }

        if (search != null) {
            status = tp == null ? "searching for " + tName + " (nothing loaded nearby yet)" : "planning route";
            if (!search.step(2500)) return;
            path = search.path(); planReached = search.reached(); search = null; pi = 0; progressTick = 0; bestDist = 1e9;
            if (path.size() < (planReached ? 1 : 3)) {
                if (tp == null) heading += 90 + (int) (Math.random() * 90);
                else if (++fails >= 3) { stop("no safe route to " + tName + " (blocked by water, lava or unloaded land)"); return; }
                path = List.of();
            }
            return;
        }
        if (tp != null && !planReached && !path.isEmpty() && ++planTick % 100 == 0) { path = List.of(); }   // re-aim at a closer partial goal
        if (tp == null && !path.isEmpty() && ++planTick % 20 == 0 && targetPos() != null) path = List.of(); // target just got found
        if (path.isEmpty() || pi >= path.size()) { startPlan(feet, tp); return; }
        follow(feet);
    }

    void startPlan(BlockPos feet, BlockPos tp) {
        Pathing.Opts o = new Pathing.Opts();
        o.dig = dig.b; o.maxDrop = maxDrop.i();
        Predicate<BlockPos> goal;
        double gx, gy, gz;
        if (tp == null) {
            double a = Math.toRadians(heading);
            gx = feet.getX() - Math.sin(a) * 80; gz = feet.getZ() + Math.cos(a) * 80; gy = feet.getY();
            goal = q -> false;
        } else {
            gx = tp.getX() + 0.5; gy = tp.getY(); gz = tp.getZ() + 0.5;
            final BlockPos t = tp;
            if (tKind == 0) goal = q -> man(q, t) == 1 || man(q.up(), t) == 1;
            else if (tKind == 1) { final String id = BIOMES[tIdx]; goal = q -> biomeIs(q, id); }
            else { final double r = tKind == 3 ? 2.5 : 5; goal = q -> Math.hypot(q.getX() - t.getX(), q.getZ() - t.getZ()) <= r && Math.abs(q.getY() - t.getY()) <= 3; }
        }
        search = new Pathing.Search(feet, goal, gx, gy, gz, o);
        planTick = 0;
    }

    void follow(BlockPos feet) {
        var p = mc.player;
        // skip ahead if we are already past some steps
        for (int j = Math.min(path.size() - 1, pi + 3); j >= pi; j--) if (feet.equals(path.get(j).pos())) { pi = j + 1; progressTick = 0; bestDist = 1e9; break; }
        if (pi >= path.size()) return;
        // safety re-check of the next few steps (lava may have flowed in, blocks may have changed)
        for (int j = pi; j < Math.min(path.size(), pi + 4); j++) {
            BlockPos q = path.get(j).pos();
            if (Pathing.classify(mc.world, q) == Pathing.DANGER || Pathing.classify(mc.world, q.up()) == Pathing.DANGER) { path = List.of(); status = "danger ahead - re-planning"; return; }
        }
        Pathing.Step st = path.get(pi);
        // mine whatever is in the way
        for (BlockPos b : st.breaks()) {
            int k = Pathing.classify(mc.world, b);
            if (k == Pathing.PASS || k == Pathing.WATER) continue;
            if (!Pathing.minable(mc.world, b)) { path = List.of(); status = "can not mine safely - re-planning"; return; }
            status = "digging";
            mine(b);
            return;
        }
        mc.options.attackKey.setPressed(false);
        Vec3d c = Vec3d.ofBottomCenter(st.pos());
        double dist = Nav.walk(c, sprint.b && st.kind() == Pathing.Kind.WALK, true, 45f);
        status = "walking to " + tName + " (" + (path.size() - pi) + " steps)";
        if (dist < bestDist - 0.02) { bestDist = dist; progressTick = 0; }
        else if (++progressTick > 60) {
            path = List.of(); progressTick = 0;
            if (++fails >= 8) stop("stuck - could not make progress");
        }
    }

    void pickTool(BlockState st) {
        int best = -1; float bs = mc.player.getInventory().getStack(Inv.selected()).getMiningSpeedMultiplier(st);
        for (int i = 0; i < 9; i++) {
            float s = mc.player.getInventory().getStack(i).getMiningSpeedMultiplier(st);
            if (s > bs + 0.01f) { bs = s; best = i; }
        }
        if (best >= 0) Inv.select(best);
    }

    void mine(BlockPos b) {
        Nav.release();
        BlockState st = mc.world.getBlockState(b);
        pickTool(st);
        Vec3d c = Vec3d.ofCenter(b);
        Nav.turnTo(c, 60f, true);
        Vec3d d = mc.player.getEyePos().subtract(c);
        mc.interactionManager.updateBlockBreakingProgress(b, Direction.getFacing(d.x, d.y, d.z));
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    void finish(BlockPos tp) {
        Nav.release();
        if (tKind == 0 && mineOre.b && tp != null && !mc.world.getBlockState(tp).isAir()) {
            if (Pathing.minable(mc.world, tp)) { status = "mining " + tName; mine(tp); return; }
            stop("reached " + tName + " but it touches lava/water, so I left it alone");
            return;
        }
        Sfx.play("on", 1f);
        stop("arrived at " + tName + (tp != null ? " (" + tp.getX() + ", " + tp.getY() + ", " + tp.getZ() + ")" : ""));
    }

    // ------------------------------------------------------------ guardian
    LivingEntity threat() {
        LivingEntity best = null; double bd = 1e9;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || !(e instanceof Monster) || !le.isAlive()) continue;
            if (e instanceof EndermanEntity || e instanceof ZombifiedPiglinEntity) continue;   // neutral until provoked
            double d = mc.player.distanceTo(e);
            if (d > defendRange.v || (d > 3.5 && !mc.player.canSee(e))) continue;
            if (d < bd) { bd = d; best = le; }
        }
        return best;
    }

    boolean wardenNear() {
        for (Entity e : mc.world.getEntities()) if (e instanceof WardenEntity w && w.isAlive() && mc.player.distanceTo(w) < 28) return true;
        return false;
    }

    /** Hotbar slot of a matching stack (moves one in from the inventory into slot 8 if needed), or -1. */
    int stock(Predicate<ItemStack> f) {
        int s = Inv.hotbar(f);
        if (s >= 0) return s;
        for (int i = 9; i < 36; i++) if (f.test(mc.player.getInventory().getStack(i))) {
            mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, Inv.containerSlot(i), 8, SlotActionType.SWAP, mc.player);
            return 8;
        }
        return -1;
    }

    static boolean junkFood(ItemStack s) {
        return s.isOf(Items.ROTTEN_FLESH) || s.isOf(Items.SPIDER_EYE) || s.isOf(Items.POISONOUS_POTATO) || s.isOf(Items.PUFFERFISH)
                || s.isOf(Items.CHORUS_FRUIT) || s.isOf(Items.SUSPICIOUS_STEW);
    }

    boolean startEat(Predicate<ItemStack> f) {
        int s = stock(f);
        if (s < 0) return false;
        eatPrev = Inv.selected();
        Inv.select(s);
        eatT = 45;
        return true;
    }

    /** Eat/drink something that heals. Golden apples and healing potions first, then any food. */
    boolean heal() {
        var p = mc.player;
        if (startEat(s -> s.isOf(Items.ENCHANTED_GOLDEN_APPLE))) return true;
        if (startEat(s -> s.isOf(Items.GOLDEN_APPLE))) return true;
        if (startEat(s -> s.isOf(Items.POTION) && AutoPot.has(s, StatusEffects.INSTANT_HEALTH))) return true;
        if (p.getHungerManager().isNotFull()) return startEat(s -> s.get(DataComponentTypes.FOOD) != null && !junkFood(s));
        return false;
    }

    int weapon() {
        int best = -1, bs = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            int sc = s.isOf(Items.MACE) ? 60 : s.isIn(ItemTags.SWORDS) ? 100 + s.getMaxDamage() / 10 : s.isIn(ItemTags.AXES) ? 50 + s.getMaxDamage() / 10 : -1;
            if (sc > bs) { bs = sc; best = i; }
        }
        return best;
    }

    boolean flee(LivingEntity from) {
        Vec3d me = mc.player.getEntityPos();
        Vec3d away = me.subtract(from.getEntityPos());
        if (away.horizontalLength() < 0.01) away = new Vec3d(1, 0, 0);
        away = away.normalize().multiply(8);
        Nav.walk(new Vec3d(me.x + away.x, me.y, me.z + away.z), true, true, 70f);
        status = "running from " + from.getName().getString();
        path = List.of();
        return true;
    }

    boolean guardian() {
        var p = mc.player;
        float hp = p.getHealth() + p.getAbsorptionAmount();
        if (panic.v > 0 && hp <= panic.v) {
            chat("PANIC: health " + (int) hp + " - leaving the game");
            setEnabled(false);
            if (mc.getNetworkHandler() != null) mc.getNetworkHandler().getConnection().disconnect(Text.literal("[Goku] Navigator panic at " + (int) hp + " HP"));
            return true;
        }
        if (wardenStop.b && wardenNear()) { stop("a Warden is nearby - stopping. Sneak away quietly!"); return true; }
        // in lava: get out
        if (p.isInLava()) { Nav.release(); mc.options.jumpKey.setPressed(true); mc.options.forwardKey.setPressed(true); status = "escaping lava"; path = List.of(); return true; }
        // low air: surface
        if (p.isSubmergedInWater() && p.getAir() < 100) { mc.options.jumpKey.setPressed(true); status = "surfacing for air"; return true; }
        // eating / drinking in progress
        if (eatT > 0) {
            Nav.release();
            mc.options.useKey.setPressed(true);
            if (--eatT <= 0 || (eatT < 38 && !p.isUsingItem())) {
                eatT = 0; mc.options.useKey.setPressed(false);
                if (eatPrev >= 0) { Inv.select(eatPrev); eatPrev = -1; }
            }
            status = "healing";
            return true;
        }
        LivingEntity t = threat();
        if (hp <= healAt.v && (t == null || mc.player.distanceTo(t) > 2.6 || hp <= fleeAt.v) && heal()) return true;
        if (t == null && p.getHungerManager().getFoodLevel() < hunger.v && p.getHungerManager().isNotFull() && startEat(s -> s.get(DataComponentTypes.FOOD) != null && !junkFood(s))) return true;
        if (t == null || !defend.b) return false;

        // ---- fight or flight
        if (hp <= fleeAt.v) return flee(t);
        status = "fighting " + t.getName().getString();
        path = List.of();
        int w = weapon();
        if (w >= 0 && Inv.selected() != w) Inv.select(w);
        double d = p.distanceTo(t);
        Nav.turnTo(t.getEntityPos().add(0, t.getHeight() * 0.6, 0), 60f, true);
        boolean ready = p.getAttackCooldownProgress(0.5f) >= 0.95f;
        if (t instanceof CreeperEntity && d < 3.4 && !ready) return flee(t);
        if (d > 2.7) { mc.options.forwardKey.setPressed(true); mc.options.sprintKey.setPressed(true); mc.options.jumpKey.setPressed(p.horizontalCollision && p.isOnGround()); }
        else { Nav.release(); }
        if (d <= 3.0 && ready) { mc.interactionManager.attackEntity(p, t); p.swingHand(Hand.MAIN_HAND); }
        return true;
    }

    // ------------------------------------------------------------ HUD / path overlay
    @Override public void onRender(DrawContext c, float td) {
        if (mc.player == null) return;
        if (hud.b) Esp.hud(c, "Navigator -> " + tName + ": " + status, Modules.accent());
        if (!showPath.b) return;
        BlockPos tp = targetPos();
        if (tp != null) Esp.box(c, new Box(tp.getX(), tp.getY(), tp.getZ(), tp.getX() + 1, tp.getY() + 1, tp.getZ() + 1), 0xFFFFDD33, 1, true, 1);
        List<Pathing.Step> pa = path;
        for (int i = pi; i < Math.min(pa.size(), pi + 8); i++) {
            BlockPos q = pa.get(i).pos();
            Esp.box(c, new Box(q.getX() + 0.3, q.getY(), q.getZ() + 0.3, q.getX() + 0.7, q.getY() + 0.1, q.getZ() + 0.7), 0xFF44DDFF, 1, true, 1);
        }
    }
}
