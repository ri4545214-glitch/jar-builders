package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;

/** Settings for the GUI background particles (read by gui.ParticleField). Not toggleable; shown as its own panel. */
public class ParticleModule extends Module {
    public final Setting on = add(Setting.bool("Particles", true));
    public final Setting amount = add(Setting.num("Amount", 80, 0, 300, 10));
    public final Setting size = add(Setting.num("Size", 2, 1, 6, 1));
    public final Setting speed = add(Setting.num("Speed", 10, 0, 40, 1));
    public final Setting opacity = add(Setting.num("Opacity", 140, 20, 255, 5));
    public final Setting direction = add(Setting.mode("Direction", 0, "Up", "Down", "Left", "Right", "Drift"));
    public final Setting shape = add(Setting.mode("Shape", 0, "Square", "Diamond", "Plus", "Circle"));
    public final Setting color = add(Setting.mode("Color", 0, "Theme", "Rainbow", "Custom"));
    public final Setting cr = add(Setting.num("Custom Red", 255, 0, 255, 5));
    public final Setting cg = add(Setting.num("Custom Green", 255, 0, 255, 5));
    public final Setting cb = add(Setting.num("Custom Blue", 255, 0, 255, 5));
    public final Setting twinkle = add(Setting.bool("Twinkle", true));
    public final Setting links = add(Setting.bool("Link Lines", false));
    public final Setting linkDist = add(Setting.num("Link Distance", 40, 15, 100, 5));
    public final Setting mouse = add(Setting.bool("Mouse Repel", false));

    public ParticleModule() { super("Particles"); toggleable = false; open = true; }
}
