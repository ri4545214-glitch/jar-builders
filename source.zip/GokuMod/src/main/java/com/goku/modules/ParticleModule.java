package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;

/** Settings for the GUI background particles (read by gui.ParticleField). Not toggleable; shown as its own panel. */
public class ParticleModule extends Module {
    public final Setting on = add(Setting.bool("Particles", true));
    public final Setting style = add(Setting.mode("Style", 0, "Float", "Snow", "Rain", "Fireflies", "Swirl"));
    public final Setting amount = add(Setting.num("Amount", 90, 0, 300, 10));
    public final Setting size = add(Setting.num("Size", 2, 1, 6, 1));
    public final Setting depth = add(Setting.bool("Depth (size + parallax)", true));
    public final Setting speed = add(Setting.num("Speed", 10, 0, 40, 1));
    public final Setting opacity = add(Setting.num("Opacity", 150, 20, 255, 5));
    public final Setting direction = add(Setting.mode("Float Direction", 0, "Up", "Down", "Left", "Right", "Drift"));
    public final Setting shape = add(Setting.mode("Shape", 0, "Square", "Diamond", "Plus", "Circle"));
    public final Setting color = add(Setting.mode("Color", 0, "Theme", "Rainbow", "Gradient", "Custom"));
    public final Setting custom = add(Setting.color("Custom Color", 0xFFFFFF));
    public final Setting twinkle = add(Setting.bool("Twinkle", true));
    public final Setting glow = add(Setting.bool("Glow", true));
    public final Setting trail = add(Setting.bool("Trail", false));
    public final Setting links = add(Setting.bool("Link Lines", false));
    public final Setting linkDist = add(Setting.num("Link Distance", 40, 15, 100, 5));
    public final Setting mouse = add(Setting.mode("Mouse", 0, "Off", "Repel", "Attract"));
    public final Setting burst = add(Setting.bool("Click Burst", true));

    public ParticleModule() { super("Particles"); toggleable = false; open = true; }
}
