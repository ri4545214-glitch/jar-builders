package com.goku.modules;

import com.goku.Module;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Client-side night vision so caves and nights are fully lit. */
public class Fullbright extends Module {
    public Fullbright() { super("Fullbright"); }

    @Override public void onTick() {
        if (mc.player == null) return;
        var cur = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (cur == null || cur.getDuration() < 400) mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1200, 0, false, false));
    }

    @Override public void onDisable() { if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION); }
}
