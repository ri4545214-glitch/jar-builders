package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Full brightness. Night Vision mode (client-side effect, true fullbright) or Gamma mode (option maxed). */
public class Fullbright extends Module {
    final Setting mode = add(Setting.mode("Mode", 0, "Night Vision", "Gamma"));

    private double origGamma = -1;
    private boolean addedNv;

    public Fullbright() { super("Fullbright"); }

    @Override public void onTick() {
        if (mc.player == null) return;
        if (mode.idx == 0) {
            restoreGamma();
            var cur = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur == null || (addedNv && cur.getDuration() < 600)) {
                mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1200, 0, false, false, false));
                addedNv = true;
            }
        } else {
            removeNv();
            if (origGamma < 0) origGamma = mc.options.getGamma().getValue();
            mc.options.getGamma().setValue(1.0);
        }
    }

    private void removeNv() {
        if (addedNv && mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        addedNv = false;
    }

    private void restoreGamma() {
        if (origGamma >= 0) { mc.options.getGamma().setValue(origGamma); origGamma = -1; }
    }

    @Override public void onDisable() { removeNv(); restoreGamma(); }
}
