package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Targets;
import net.minecraft.util.Hand;

/** Attacks whatever is under the crosshair once the weapon cooldown is ready. */
public class AutoAttack extends Module {
    final Setting players = add(Setting.bool("Players", true));
    final Setting mobs = add(Setting.bool("Mobs", true));
    final Setting cooldown = add(Setting.num("Min Cooldown %", 100, 10, 100, 5));
    final Setting crits = add(Setting.bool("Crits Only", false));
    final Setting walls = add(Setting.bool("Through Walls", false));

    public AutoAttack() { super("Auto Attack"); }

    @Override public void onTick() {
        if (mc.currentScreen != null || mc.targetedEntity == null) return;
        if (!Targets.valid(mc, mc.targetedEntity, 6, players.b, mobs.b, walls.b)) return;
        if (mc.player.getAttackCooldownProgress(0.5f) < cooldown.v / 100.0) return;
        if (crits.b && (mc.player.isOnGround() || mc.player.fallDistance <= 0)) return;
        mc.interactionManager.attackEntity(mc.player, mc.targetedEntity);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
