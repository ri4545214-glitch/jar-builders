package com.goku.gui;

import com.goku.Modules;
import com.goku.modules.ParticleModule;
import com.goku.util.Draw;
import net.minecraft.client.gui.DrawContext;

import java.util.Random;

/** Background particle system for the ClickGui, driven by the Particles settings panel. */
public class ParticleField {
    static final int MAX = 300;
    final float[] x = new float[MAX], y = new float[MAX], ph = new float[MAX], rv = new float[MAX], rdx = new float[MAX], rdy = new float[MAX];
    int w = 1, h = 1;

    public void resize(int w, int h) {
        this.w = w; this.h = h;
        Random r = new Random();
        for (int i = 0; i < MAX; i++) {
            x[i] = r.nextFloat() * w; y[i] = r.nextFloat() * h; ph[i] = r.nextFloat() * 6.28f; rv[i] = r.nextFloat();
            double a = r.nextDouble() * Math.PI * 2; rdx[i] = (float) Math.cos(a); rdy[i] = (float) Math.sin(a);
        }
    }

    static int hsv(float hue) {
        hue -= (float) Math.floor(hue);
        float f6 = hue * 6; int i = (int) f6; float f = f6 - i, q = 1 - f;
        float r, g, b;
        switch (i % 6) {
            case 0 -> { r = 1; g = f; b = 0; }
            case 1 -> { r = q; g = 1; b = 0; }
            case 2 -> { r = 0; g = 1; b = f; }
            case 3 -> { r = 0; g = q; b = 1; }
            case 4 -> { r = f; g = 0; b = 1; }
            default -> { r = 1; g = 0; b = q; }
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    static void shape(DrawContext c, int mode, int px, int py, int s, int col) {
        switch (mode) {
            case 0 -> c.fill(px, py, px + s, py + s, col);
            case 1 -> { for (int dy = -s; dy <= s; dy++) { int hw = s - Math.abs(dy); c.fill(px - hw, py + dy, px + hw + 1, py + dy + 1, col); } }
            case 2 -> { c.fill(px - s, py, px + s + 1, py + 1, col); c.fill(px, py - s, px + 1, py + s + 1, col); }
            default -> { c.fill(px - s, py - s + 1, px + s + 1, py + s, col); c.fill(px - s + 1, py - s, px + s, py + s + 1, col); }
        }
    }

    public void render(DrawContext c, float dt, int accent, int mx, int my) {
        ParticleModule m = Modules.PARTICLES;
        if (!m.on.b) return;
        int n = Math.min(MAX, m.amount.i()), dir = m.direction.idx, size = m.size.i(), baseA = m.opacity.i();
        float mul = (float) (m.speed.v / 10.0);
        float t = (System.nanoTime() % 100_000_000_000L) / 1e9f;
        int[] cols = new int[n], ax = new int[n], ay = new int[n];
        for (int i = 0; i < n; i++) {
            ph[i] += dt * 2;
            float sp = 14 * (0.5f + rv[i]) * mul, dx, dy;
            switch (dir) {
                case 0 -> { dx = 0; dy = -1; }
                case 1 -> { dx = 0; dy = 1; }
                case 2 -> { dx = -1; dy = 0; }
                case 3 -> { dx = 1; dy = 0; }
                default -> { dx = rdx[i]; dy = rdy[i]; }
            }
            x[i] += dx * sp * dt; y[i] += dy * sp * dt;
            if (dir < 4) { float sw = (float) Math.sin(ph[i] * 0.5f) * 6 * mul * dt; if (dir < 2) x[i] += sw; else y[i] += sw; }
            if (m.mouse.b) {
                float ex = x[i] - mx, ey = y[i] - my, d2 = ex * ex + ey * ey;
                if (d2 < 3600 && d2 > 0.01f) { float d = (float) Math.sqrt(d2), push = (60 - d) * 4 * dt; x[i] += ex / d * push; y[i] += ey / d * push; }
            }
            if (x[i] < -6) x[i] = w + 6; else if (x[i] > w + 6) x[i] = -6;
            if (y[i] < -6) y[i] = h + 6; else if (y[i] > h + 6) y[i] = -6;
            int rgb = switch (m.color.idx) {
                case 0 -> accent & 0xFFFFFF;
                case 1 -> hsv(t * 0.1f + rv[i] * 0.5f);
                default -> (m.cr.i() << 16) | (m.cg.i() << 8) | m.cb.i();
            };
            int a = m.twinkle.b ? (int) (baseA * (0.55f + 0.45f * Math.sin(ph[i]))) : baseA;
            cols[i] = (Math.max(0, Math.min(255, a)) << 24) | rgb;
            ax[i] = (int) x[i]; ay[i] = (int) y[i];
        }
        if (m.links.b) {
            float ld = (float) m.linkDist.v;
            int ln = Math.min(n, 100);
            for (int i = 0; i < ln; i++) for (int j = i + 1; j < ln; j++) {
                float ex = x[i] - x[j], ey = y[i] - y[j], d2 = ex * ex + ey * ey;
                if (d2 > ld * ld) continue;
                int a = (int) (((cols[i] >>> 24) * 0.7f) * (1 - (float) Math.sqrt(d2) / ld));
                Draw.line(c, x[i], y[i], x[j], y[j], 1, (a << 24) | (cols[i] & 0xFFFFFF));
            }
        }
        for (int i = 0; i < n; i++) shape(c, m.shape.idx, ax[i], ay[i], size, cols[i]);
    }
}
