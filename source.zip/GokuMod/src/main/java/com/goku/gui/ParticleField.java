package com.goku.gui;

import com.goku.Modules;
import com.goku.modules.ParticleModule;
import com.goku.util.Draw;
import net.minecraft.client.gui.DrawContext;

import java.util.Random;

/** Background particle system for the ClickGui, driven by the Particles settings panel. */
public class ParticleField {
    static final int MAX = 300, BMAX = 240;
    final float[] x = new float[MAX], y = new float[MAX], ph = new float[MAX], rv = new float[MAX];
    final float[] rdx = new float[MAX], rdy = new float[MAX], vdx = new float[MAX], vdy = new float[MAX];
    // click bursts
    final float[] bx = new float[BMAX], by = new float[BMAX], bvx = new float[BMAX], bvy = new float[BMAX], life = new float[BMAX], maxLife = new float[BMAX];
    final int[] bcol = new int[BMAX];
    int bNext;
    final Random rnd = new Random();
    int w = 1, h = 1;

    public void resize(int w, int h) {
        this.w = w; this.h = h;
        for (int i = 0; i < MAX; i++) {
            x[i] = rnd.nextFloat() * w; y[i] = rnd.nextFloat() * h; ph[i] = rnd.nextFloat() * 6.28f; rv[i] = rnd.nextFloat();
            double a = rnd.nextDouble() * Math.PI * 2; rdx[i] = (float) Math.cos(a); rdy[i] = (float) Math.sin(a);
        }
    }

    /** Spawn a ring of sparks at the click position. */
    public void burst(float cx, float cy, int accent, int accent2) {
        for (int k = 0; k < 28; k++) {
            int i = bNext++ % BMAX;
            double a = rnd.nextDouble() * Math.PI * 2, sp = 30 + rnd.nextDouble() * 120;
            bx[i] = cx; by[i] = cy; bvx[i] = (float) (Math.cos(a) * sp); bvy[i] = (float) (Math.sin(a) * sp);
            maxLife[i] = life[i] = 0.5f + rnd.nextFloat() * 0.7f;
            bcol[i] = rnd.nextBoolean() ? accent & 0xFFFFFF : accent2 & 0xFFFFFF;
        }
    }

    static int mixRgb(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t), g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t), bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    static void shape(DrawContext c, int mode, int px, int py, int s, int col) {
        switch (mode) {
            case 0 -> c.fill(px, py, px + s, py + s, col);
            case 1 -> { for (int dy = -s; dy <= s; dy++) { int hw = s - Math.abs(dy); c.fill(px - hw, py + dy, px + hw + 1, py + dy + 1, col); } }
            case 2 -> { c.fill(px - s, py, px + s + 1, py + 1, col); c.fill(px, py - s, px + 1, py + s + 1, col); }
            default -> { c.fill(px - s, py - s + 1, px + s + 1, py + s, col); c.fill(px - s + 1, py - s, px + s, py + s + 1, col); }
        }
    }

    public void render(DrawContext c, float dt, int accent, int accent2, int mx, int my) {
        ParticleModule m = Modules.PARTICLES;
        if (!m.on.b) return;
        int n = Math.min(MAX, m.amount.i()), dir = m.direction.idx, style = m.style.idx, baseA = m.opacity.i();
        float mul = (float) (m.speed.v / 10.0);
        float t = (System.nanoTime() % 100_000_000_000L) / 1e9f;
        int[] cols = new int[n], ax = new int[n], ay = new int[n], sz = new int[n];
        for (int i = 0; i < n; i++) {
            ph[i] += dt * 2;
            float layer = m.depth.b ? 0.45f + rv[i] * 1.1f : 1f;      // far particles are small and slow
            float sp = 14 * (0.5f + rv[i]) * mul * (m.depth.b ? layer : 1f), dx, dy;
            switch (style) {
                case 1 -> { dx = (float) Math.sin(ph[i] * 0.6f) * 0.6f; dy = 1; sp *= 0.7f; }                       // snow
                case 2 -> { dx = 0.15f; dy = 1; sp *= 4.5f; }                                                    // rain
                case 3 -> { dx = (float) Math.cos(ph[i] * 0.7f + rv[i] * 6.28f); dy = (float) Math.sin(ph[i] * 0.9f + rv[i] * 3.1f); sp *= 0.6f; } // fireflies
                case 4 -> { float ex = x[i] - w / 2f, ey = y[i] - h / 2f, l = (float) Math.sqrt(ex * ex + ey * ey) + 0.001f; dx = -ey / l; dy = ex / l; sp *= 1.6f; } // swirl
                default -> {
                    switch (dir) {
                        case 0 -> { dx = 0; dy = -1; }
                        case 1 -> { dx = 0; dy = 1; }
                        case 2 -> { dx = -1; dy = 0; }
                        case 3 -> { dx = 1; dy = 0; }
                        default -> { dx = rdx[i]; dy = rdy[i]; }
                    }
                }
            }
            vdx[i] = dx; vdy[i] = dy;
            x[i] += dx * sp * dt; y[i] += dy * sp * dt;
            if (style == 0 && dir < 4) { float sw = (float) Math.sin(ph[i] * 0.5f) * 6 * mul * dt; if (dir < 2) x[i] += sw; else y[i] += sw; }
            if (m.mouse.idx != 0) {
                float ex = x[i] - mx, ey = y[i] - my, d2 = ex * ex + ey * ey;
                if (d2 < 4900 && d2 > 0.01f) {
                    float d = (float) Math.sqrt(d2), push = (70 - d) * 4 * dt * (m.mouse.idx == 1 ? 1 : -0.6f);
                    x[i] += ex / d * push; y[i] += ey / d * push;
                }
            }
            if (x[i] < -6) x[i] = w + 6; else if (x[i] > w + 6) x[i] = -6;
            if (y[i] < -6) y[i] = h + 6; else if (y[i] > h + 6) y[i] = -6;
            int rgb = switch (m.color.idx) {
                case 0 -> accent & 0xFFFFFF;
                case 1 -> Draw.hsv(t * 0.1f + rv[i] * 0.5f);
                case 2 -> mixRgb(accent, accent2, (float) (Math.sin(t * 0.8f + rv[i] * 6.28f) * 0.5 + 0.5));
                default -> m.custom.rgb();
            };
            float tw = style == 3 ? 0.15f + 0.85f * (float) Math.pow(Math.sin(ph[i]) * 0.5 + 0.5, 2) : (m.twinkle.b ? 0.55f + 0.45f * (float) Math.sin(ph[i]) : 1f);
            int a = (int) (baseA * tw);
            cols[i] = (Math.max(0, Math.min(255, a)) << 24) | rgb;
            ax[i] = (int) x[i]; ay[i] = (int) y[i];
            sz[i] = m.depth.b ? Math.max(1, Math.round(m.size.i() * layer)) : m.size.i();
        }
        if (m.links.b) {
            float ld = (float) m.linkDist.v;
            int ln = Math.min(n, 100);
            for (int i = 0; i < ln; i++) for (int j = i + 1; j < ln; j++) {
                float ex = x[i] - x[j], ey = y[i] - y[j], d2 = ex * ex + ey * ey;
                if (d2 > ld * ld) continue;
                int a = (int) (((cols[i] >>> 24) * 0.7f) * (1 - (float) Math.sqrt(d2) / ld));
                Draw.line(c, x[i], y[i], x[j], y[j], 1, (a << 24) | (cols[i] & 0xFFFFFF));
            }
        }
        for (int i = 0; i < n; i++) {
            int col = cols[i], rgb = col & 0xFFFFFF, a = col >>> 24, s = sz[i];
            if (style == 2) {                                         // rain streaks
                c.fill(ax[i], ay[i], ax[i] + 1, ay[i] + s * 5, col);
                if (m.glow.b) c.fill(ax[i] - 1, ay[i], ax[i] + 2, ay[i] + s * 5, ((a / 5) << 24) | rgb);
                continue;
            }
            if (m.trail.b) for (int k = 1; k <= 3; k++) {
                int tx = ax[i] - (int) (vdx[i] * k * (s + 2)), ty = ay[i] - (int) (vdy[i] * k * (s + 2));
                shape(c, m.shape.idx, tx, ty, Math.max(1, s - k / 2), (((int) (a * (1 - k / 4f))) << 24) | rgb);
            }
            if (m.glow.b) {
                shape(c, m.shape.idx, ax[i], ay[i], s + 3, ((a / 7) << 24) | rgb);
                shape(c, m.shape.idx, ax[i], ay[i], s + 1, ((a / 4) << 24) | rgb);
            }
            shape(c, m.shape.idx, ax[i], ay[i], s, col);
        }
        // click bursts
        for (int i = 0; i < BMAX; i++) {
            if (life[i] <= 0) continue;
            life[i] -= dt;
            bx[i] += bvx[i] * dt; by[i] += bvy[i] * dt;
            float damp = Math.max(0f, 1 - 2.4f * dt); bvx[i] *= damp; bvy[i] *= damp;
            float k = Math.max(0f, life[i] / maxLife[i]);
            int a = (int) (255 * k);
            shape(c, m.shape.idx, (int) bx[i], (int) by[i], 1 + (k > 0.5f ? 1 : 0), (a << 24) | bcol[i]);
        }
    }
}
