package com.goku.gui;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ClickGui extends Screen {
    static final int W = 130, HEAD = 18, ROW = 16, SROW = 14;

    static class Panel {
        String title; int x, y; List<Module> mods; boolean collapsed;
        Panel(String t, int x, int y, List<Module> m) { title = t; this.x = x; this.y = y; mods = m; }
    }
    static class Hit {
        int x1, y1, x2, y2; Runnable left, right; Setting slider; Panel panel;
        Hit(int x1, int y1, int x2, int y2) { this.x1 = x1; this.y1 = y1; this.x2 = x2; this.y2 = y2; }
    }

    static List<Panel> panels;
    final List<Hit> hits = new ArrayList<>();
    Panel dragPanel; int grabX, grabY;
    Hit activeSlider;

    // particles
    static final int N = 80;
    final float[] px = new float[N], py = new float[N], vx = new float[N], vy = new float[N], sz = new float[N], ph = new float[N];
    long lastNs = System.nanoTime();

    public ClickGui() {
        super(Text.literal("Goku mod's"));
        if (panels == null) {
            panels = new ArrayList<>();
            panels.add(new Panel("Base", 30, 40, Modules.BASE));
            panels.add(new Panel("Combat", 180, 40, Modules.COMBAT));
            panels.add(new Panel("Theme", 330, 40, List.of(Modules.THEME)));
        }
    }

    @Override protected void init() {
        Random r = new Random();
        for (int i = 0; i < N; i++) {
            px[i] = r.nextFloat() * width; py[i] = r.nextFloat() * height;
            vx[i] = (r.nextFloat() - .5f) * 14; vy[i] = -4 - r.nextFloat() * 16;
            sz[i] = 1 + r.nextInt(3); ph[i] = r.nextFloat() * 6.28f;
        }
    }

    @Override public boolean shouldPause() { return false; }

    static int alpha(int argb, int a) { return (a << 24) | (argb & 0xFFFFFF); }

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        int accent = Modules.accent();
        hits.clear();
        ctx.fill(0, 0, width, height, 0x99000000);

        long now = System.nanoTime(); float dt = Math.min((now - lastNs) / 1e9f, 0.1f); lastNs = now;
        for (int i = 0; i < N; i++) {
            px[i] += vx[i] * dt; py[i] += vy[i] * dt; ph[i] += dt * 2;
            if (py[i] < -4) { py[i] = height + 4; px[i] = (float) Math.random() * width; }
            if (px[i] < -4) px[i] = width + 4; if (px[i] > width + 4) px[i] = -4;
            int a = 70 + (int) (60 * Math.sin(ph[i]));
            ctx.fill((int) px[i], (int) py[i], (int) (px[i] + sz[i]), (int) (py[i] + sz[i]), alpha(accent, a));
        }

        Text title = Text.literal("Goku mod's").formatted(Formatting.BOLD);
        int tw = textRenderer.getWidth(title);
        ctx.drawText(textRenderer, title, width / 2 - tw / 2, 10, accent, true);
        ctx.fill(width / 2 - tw / 2 - 6, 22, width / 2 + tw / 2 + 6, 23, accent);

        for (Panel p : panels) drawPanel(ctx, p, accent);
        ctx.drawText(textRenderer, "LMB toggle  |  RMB settings  |  drag headers  |  RMB header: collapse", 4, height - 12, 0xFF888888, false);
    }

    void drawPanel(DrawContext ctx, Panel p, int accent) {
        ctx.fill(p.x, p.y, p.x + W, p.y + HEAD, alpha(accent, 0xEE));
        ctx.drawText(textRenderer, p.title, p.x + 5, p.y + 5, 0xFFFFFFFF, true);
        Hit hh = new Hit(p.x, p.y, p.x + W, p.y + HEAD); hh.panel = p; hits.add(hh);
        if (p.collapsed) return;
        int y = p.y + HEAD;
        for (Module m : p.mods) {
            if (m.toggleable) {
                ctx.fill(p.x, y, p.x + W, y + ROW, m.enabled ? alpha(accent, 0xCC) : 0xCC141414);
                ctx.drawText(textRenderer, m.name, p.x + 5, y + 4, m.enabled ? 0xFFFFFFFF : 0xFFBBBBBB, true);
                ctx.drawText(textRenderer, m.open ? "-" : "+", p.x + W - 10, y + 4, 0xFFAAAAAA, false);
                Hit h = new Hit(p.x, y, p.x + W, y + ROW); h.left = m::toggle; h.right = () -> m.open = !m.open; hits.add(h);
                y += ROW;
            }
            if (m.open) for (Setting s : m.settings) { drawSetting(ctx, p, s, y, accent); y += SROW; }
        }
        ctx.fill(p.x, y, p.x + W, y + 2, alpha(accent, 0xEE));
    }

    void drawSetting(DrawContext ctx, Panel p, Setting s, int y, int accent) {
        ctx.fill(p.x, y, p.x + W, y + SROW, 0xCC0A0A0A);
        ctx.fill(p.x, y, p.x + 2, y + SROW, accent);
        Hit h = new Hit(p.x, y, p.x + W, y + SROW);
        switch (s.type) {
            case BOOL -> {
                if (s.b) ctx.fill(p.x + 2, y, p.x + W, y + SROW, alpha(accent, 0x66));
                ctx.drawText(textRenderer, s.name, p.x + 7, y + 3, 0xFFDDDDDD, false);
                String v = s.b ? "ON" : "OFF";
                ctx.drawText(textRenderer, v, p.x + W - 5 - textRenderer.getWidth(v), y + 3, s.b ? 0xFFFFFFFF : 0xFF777777, false);
                h.left = () -> s.b = !s.b;
            }
            case MODE -> {
                ctx.drawText(textRenderer, s.name, p.x + 7, y + 3, 0xFFDDDDDD, false);
                String v = s.modeName();
                ctx.drawText(textRenderer, v, p.x + W - 5 - textRenderer.getWidth(v), y + 3, accent, false);
                h.left = s::cycle;
            }
            case NUM -> {
                double t = (s.v - s.min) / (s.max - s.min);
                ctx.fill(p.x + 2, y, p.x + 2 + (int) ((W - 2) * t), y + SROW, alpha(accent, 0x88));
                ctx.drawText(textRenderer, s.name, p.x + 7, y + 3, 0xFFDDDDDD, false);
                String v = s.step >= 1 ? String.valueOf((int) Math.round(s.v)) : String.format("%.1f", s.v);
                ctx.drawText(textRenderer, v, p.x + W - 5 - textRenderer.getWidth(v), y + 3, 0xFFFFFFFF, false);
                h.slider = s;
            }
        }
        hits.add(h);
    }

    void setSlider(Hit h, double mx) {
        Setting s = h.slider;
        double t = Math.max(0, Math.min(1, (mx - h.x1) / (double) (h.x2 - h.x1)));
        double v = s.min + t * (s.max - s.min);
        s.v = Math.max(s.min, Math.min(s.max, Math.round(v / s.step) * s.step));
    }

    @Override public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y(); int btn = click.button();
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (mx < h.x1 || mx >= h.x2 || my < h.y1 || my >= h.y2) continue;
            if (h.panel != null) {
                if (btn == 0) {
                    dragPanel = h.panel; grabX = (int) mx - h.panel.x; grabY = (int) my - h.panel.y;
                    panels.remove(h.panel); panels.add(h.panel);
                } else if (btn == 1) h.panel.collapsed = !h.panel.collapsed;
            } else if (h.slider != null) {
                if (btn == 0) { activeSlider = h; setSlider(h, mx); }
            } else if (btn == 0 && h.left != null) h.left.run();
            else if (btn == 1 && h.right != null) h.right.run();
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override public boolean mouseDragged(Click click, double dx, double dy) {
        if (dragPanel != null) {
            dragPanel.x = Math.max(0, Math.min(width - W, (int) click.x() - grabX));
            dragPanel.y = Math.max(0, Math.min(height - HEAD, (int) click.y() - grabY));
            return true;
        }
        if (activeSlider != null) { setSlider(activeSlider, click.x()); return true; }
        return super.mouseDragged(click, dx, dy);
    }

    @Override public boolean mouseReleased(Click click) {
        dragPanel = null; activeSlider = null;
        return super.mouseReleased(click);
    }

    @Override public boolean keyPressed(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_RIGHT_ALT) { close(); return true; }
        return super.keyPressed(input);
    }
}
