package com.goku.gui;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Draw;
import com.goku.util.Sfx;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Animated, gradient-themed module GUI with open animation, smooth toggles, sliding settings, scrolling, sounds and phonk. */
public class ClickGui extends Screen {
    static final int W = 130, HEAD = 20, ROW = 17, SROW = 14, WHEEL_H = 74, WR = 26;
    static int sh(Setting s) { return s.type == Setting.Type.COLOR ? WHEEL_H : SROW; }
    static int sumH(Module m) { int h = 0; for (Setting s : m.settings) h += sh(s); return h; }

    static class Panel {
        String title; int x, y; List<Module> mods; boolean collapsed; float anim = 1;
        Panel(String t, List<Module> m, boolean collapsed) { title = t; mods = m; this.collapsed = collapsed; anim = collapsed ? 0 : 1; }
    }
    static class Hit {
        int x1, y1, x2, y2; Runnable left, right; Setting slider, color; Panel panel;
        Hit(int x1, int y1, int x2, int y2) { this.x1 = x1; this.y1 = y1; this.x2 = x2; this.y2 = y2; }
    }

    static List<Panel> panels;
    static float scroll;
    final List<Hit> hits = new ArrayList<>();
    final ParticleField field = new ParticleField();
    Panel dragPanel; int grabX, grabY;
    Hit activeSlider, activeColor;
    int colorRegion = -1;   // 0 = wheel, 1 = brightness bar
    boolean dragScroll;
    float open, time, maxBottom;
    long lastNs = System.nanoTime();

    public ClickGui() { super(Text.literal("Goku mod's")); }

    @Override protected void init() {
        field.resize(width, height);
        open = 0;
        Sfx.play("open", 1f);
        Sfx.guiOpen = true;
        if (panels == null) {
            panels = new ArrayList<>();
            panels.add(new Panel("Base", Modules.BASE, false));
            panels.add(new Panel("Combat", Modules.COMBAT, false));
            panels.add(new Panel("Movement", Modules.MOVEMENT, false));
            panels.add(new Panel("Automation", Modules.AUTOMATION, false));
            panels.add(new Panel("Theme", List.of(Modules.THEME), true));
            panels.add(new Panel("Particles", List.of(Modules.PARTICLES), true));
            panels.add(new Panel("Sound", List.of(Modules.SOUND), true));
            panels.add(new Panel("Config", List.of(Modules.CONFIG), false));
            // greedy column packing so every panel starts on screen (phone friendly)
            int cols = Math.max(1, (width - 8) / (W + 8));
            int[] colH = new int[cols];
            for (Panel p : panels) {
                int best = 0;
                for (int i = 1; i < cols; i++) if (colH[i] < colH[best]) best = i;
                p.x = 8 + best * (W + 8); p.y = 34 + colH[best];
                int h = HEAD + 6;
                if (!p.collapsed) for (Module m : p.mods) if (m.toggleable) h += ROW;
                colH[best] += h + 6;
            }
        }
    }

    @Override public void removed() { if (Modules.CONFIG.auto.b) com.goku.Config.save(Modules.CONFIG.profile.modeName()); Sfx.guiOpen = false; super.removed(); }
    @Override public boolean shouldPause() { return false; }

    // ---- colour helpers
    static int ca(int argb, float f) { return ((int) (((argb >>> 24) & 255) * Math.max(0, Math.min(1, f))) << 24) | (argb & 0xFFFFFF); }
    static int rgba(int rgb, float a) { return ((int) (255 * Math.max(0, Math.min(1, a))) << 24) | (rgb & 0xFFFFFF); }
    static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t), g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t), bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
    static float ease(float t) { t = Math.max(0, Math.min(1, t)); return 1 - (1 - t) * (1 - t) * (1 - t); }
    static float approach(float v, float to, float dt, float speed) { return v + (to - v) * Math.min(1f, dt * speed); }

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        long now = System.nanoTime(); float dt = Math.min((now - lastNs) / 1e9f, 0.1f); lastNs = now;
        time += dt; open = Math.min(1, open + dt * 3.2f);
        float eo = ease(open);
        int accent = Modules.accent(), accent2 = Modules.accent2();
        hits.clear();

        ctx.fillGradient(0, 0, width, height, rgba(0x000000, 0.62f * eo), ca(accent, 0.33f * eo));
        field.render(ctx, dt, accent, accent2, mx, my);

        // animated title: 2x scale, wave, glow, gradient underline, version tag
        String t = "Goku mod's"; int tw = textRenderer.getWidth(t);
        float ty = 5 - (1 - eo) * 12;
        var mt = ctx.getMatrices();
        mt.pushMatrix(); mt.translate(width / 2f, ty); mt.scale(2f, 2f);
        int cx = -tw / 2;
        for (int i = 0; i < t.length(); i++) {
            String ch = String.valueOf(t.charAt(i));
            float k = (float) (Math.sin(time * 3 + i * 0.55) * 0.5 + 0.5);
            int col = mix(accent, accent2, k) | 0xFF000000, wy = (int) Math.round(Math.sin(time * 2.4 + i * 0.7) * 1.2);
            ctx.drawText(textRenderer, ch, cx - 1, wy, ca(col, 0.25f * eo), false);
            ctx.drawText(textRenderer, ch, cx + 1, wy, ca(col, 0.25f * eo), false);
            ctx.drawText(textRenderer, ch, cx, wy - 1, ca(col, 0.25f * eo), false);
            ctx.drawText(textRenderer, ch, cx, wy + 1, ca(col, 0.25f * eo), false);
            ctx.drawText(textRenderer, ch, cx, wy, ca(mix(col, 0xFFFFFFFF, 0.25f), eo), true);
            cx += textRenderer.getWidth(ch);
        }
        mt.popMatrix();
        String ver = "v" + net.fabricmc.loader.api.FabricLoader.getInstance().getModContainer("gokumod").map(m -> m.getMetadata().getVersion().getFriendlyString()).orElse("");
        ctx.drawText(textRenderer, ver, width / 2 + tw + 4, (int) ty + 9, ca(0xFFB8B8D0, eo), false);
        int lw = (int) ((tw + 12) * eo), sweep = (int) (((time * 0.6f) % 1f) * lw * 2) - lw;
        ctx.fillGradient(width / 2 - lw, 25, width / 2, 27, ca(accent2, 0f), accent);
        ctx.fillGradient(width / 2, 25, width / 2 + lw, 27, accent, ca(accent2, 0f));
        ctx.fill(width / 2 + sweep - 6, 25, width / 2 + sweep + 6, 27, ca(0xFFFFFFFF, 0.7f * eo));

        maxBottom = 0;
        int idx = 0;
        for (Panel p : new ArrayList<>(panels)) drawPanel(ctx, p, idx++, accent, accent2, mx, my, dt);
        float minScroll = Math.min(0, height - maxBottom - 14 - scroll + scroll);
        scroll = Math.max(minScroll, Math.min(0, scroll));

        ctx.drawText(textRenderer, "Tap = toggle | Hold/RMB = settings | drag headers | drag empty space or scroll", 4, height - 11, ca(0xFF9A9AB0, eo), false);
    }

    float bodyH(Panel p) {
        float h = 2;
        for (Module m : p.mods) {
            if (m.toggleable) h += ROW;
            h += sumH(m) * m.openAnim;
        }
        return h;
    }

    void drawPanel(DrawContext ctx, Panel p, int idx, int accent, int accent2, int mx, int my, float dt) {
        float e = ease((open - idx * 0.07f) / 0.55f);
        p.anim = approach(p.anim, p.collapsed ? 0 : 1, dt, 14);
        for (Module m : p.mods) {
            m.anim = approach(m.anim, m.enabled ? 1 : 0, dt, 14);
            m.openAnim = m.toggleable ? approach(m.openAnim, m.open ? 1 : 0, dt, 16) : 1;
        }
        if (e <= 0.02f) return;
        int px = p.x, py = p.y + (int) scroll + (int) ((1 - e) * -20);
        int bodyH = (int) (bodyH(p) * p.anim);
        maxBottom = Math.max(maxBottom, p.y + HEAD + bodyH + 6);
        boolean inter = p.anim > 0.98f && e > 0.98f;

        // soft shadow + header
        ctx.fill(px - 1, py - 1, px + W + 1, py + HEAD + bodyH + 1, ca(accent, 0.35f * e));
        ctx.fillGradient(px, py, px + W, py + HEAD, ca(accent, 0.97f * e), ca(accent2, 0.97f * e));
        ctx.drawText(textRenderer, p.title, px + 6, py + 6, ca(0xFFFFFFFF, e), true);
        String arrow = p.collapsed ? "+" : "-";
        ctx.drawText(textRenderer, arrow, px + W - 10, py + 6, ca(0xFFFFFFFF, e), false);
        Hit hh = new Hit(px, py, px + W, py + HEAD); hh.panel = p; hits.add(hh);
        if (bodyH <= 0) return;

        ctx.enableScissor(px - 1, py + HEAD, px + W + 1, py + HEAD + bodyH);
        ctx.fill(px, py + HEAD, px + W, py + HEAD + bodyH + 2, ca(0xEE0C0C12, e));
        int y = py + HEAD;
        for (Module m : p.mods) {
            if (m.toggleable) {
                boolean hov = mx >= px && mx < px + W && my >= y && my < y + ROW;
                ctx.fill(px, y, px + W, y + ROW, ca(hov ? 0xEE1C1C26 : 0xEE12121A, e));
                int fw = (int) (W * m.anim);
                if (fw > 0) ctx.fillGradient(px, y, px + fw, y + ROW, ca(accent, 0.85f * e), ca(accent2, 0.85f * e));
                ctx.fill(px, y, px + 2, y + ROW, ca(accent, e * (0.4f + 0.6f * m.anim)));
                int tc = m.enabled ? 0xFFFFFFFF : mix(0xFFBBBBCC, 0xFFFFFFFF, hov ? 1 : 0);
                ctx.drawText(textRenderer, m.name, px + 7 + (int) (2 * m.anim), y + 5, ca(tc, e), true);
                ctx.drawText(textRenderer, m.open ? "v" : ">", px + W - 10, y + 5, ca(0xFFAAAAAA, e), false);
                if (inter) {
                    Hit h = new Hit(px, y, px + W, y + ROW);
                    h.left = () -> { m.toggle(); Sfx.play(m.enabled ? "on" : "off", 1f); };
                    h.right = () -> { m.open = !m.open; Sfx.play("click", m.open ? 1.2f : 0.85f); };
                    hits.add(h);
                }
                y += ROW;
            }
            int full = sumH(m), vis = (int) (full * m.openAnim);
            if (vis > 0) {
                ctx.enableScissor(px, y, px + W, y + vis);
                int sy = y;
                for (Setting s : m.settings) { drawSetting(ctx, px, s, sy, y + vis, accent, accent2, mx, my, dt, e, inter); sy += sh(s); }
                ctx.disableScissor();
                y += vis;
            }
        }
        ctx.disableScissor();
        ctx.fillGradient(px, py + HEAD + bodyH, px + W, py + HEAD + bodyH + 2, ca(accent, e), ca(accent2, e));
    }

    void drawSetting(DrawContext ctx, int px, Setting s, int y, int clipBottom, int accent, int accent2, int mx, int my, float dt, float e, boolean inter) {
        int hgt = sh(s);
        boolean hov = mx >= px && mx < px + W && my >= y && my < Math.min(y + hgt, clipBottom);
        ctx.fill(px, y, px + W, y + hgt, ca(hov ? 0xEE15151F : 0xEE0A0A10, e));
        ctx.fill(px, y, px + 2, y + hgt, ca(accent, e));
        Hit h = new Hit(px, y, px + W, Math.min(y + hgt, clipBottom));
        int white = ca(0xFFDDDDDD, e);
        switch (s.type) {
            case BOOL -> {
                if (s.anim < 0) s.anim = s.b ? 1 : 0;
                s.anim = approach(s.anim, s.b ? 1 : 0, dt, 18);
                ctx.drawText(textRenderer, s.name, px + 7, y + 3, white, false);
                int pw = 18, bx = px + W - pw - 5, by = y + 3;
                ctx.fill(bx, by, bx + pw, by + 8, ca(mix(0xFF303040, accent, s.anim), e));
                ctx.fill(bx + 1 + (int) ((pw - 8) * s.anim), by + 1, bx + 7 + (int) ((pw - 8) * s.anim), by + 7, ca(0xFFFFFFFF, e));
                h.left = () -> { s.b = !s.b; Sfx.play("click", s.b ? 1.25f : 0.8f); };
            }
            case MODE -> {
                ctx.drawText(textRenderer, s.name, px + 7, y + 3, white, false);
                String v = s.modeName();
                ctx.drawText(textRenderer, v, px + W - 5 - textRenderer.getWidth(v), y + 3, ca(mix(accent, 0xFFFFFFFF, 0.35f), e), false);
                h.left = () -> { s.cycle(); Sfx.play("click", 1f + 0.08f * s.idx); };
            }
            case NUM -> {
                float t = (float) ((s.v - s.min) / (s.max - s.min));
                if (s.anim < 0) s.anim = t;
                s.anim = approach(s.anim, t, dt, 20);
                int fw = (int) ((W - 2) * s.anim);
                if (fw > 0) ctx.fillGradient(px + 2, y, px + 2 + fw, y + hgt, ca(accent, 0.55f * e), ca(accent2, 0.55f * e));
                ctx.drawText(textRenderer, s.name, px + 7, y + 3, white, false);
                String v = s.step >= 1 ? String.valueOf((int) Math.round(s.v)) : s.step >= 0.1 ? String.format("%.1f", s.v) : String.format("%.2f", s.v);
                ctx.drawText(textRenderer, v, px + W - 5 - textRenderer.getWidth(v), y + 3, ca(0xFFFFFFFF, e), false);
                h.slider = s;
            }
            case COLOR -> {
                ctx.drawText(textRenderer, s.name, px + 7, y + 3, white, false);
                int cx = px + 10 + WR, cy = y + 14 + WR, cell = 2;
                for (int dy = -WR; dy < WR; dy += cell) for (int dx = -WR; dx < WR; dx += cell) {
                    float qx = dx + cell / 2f, qy = dy + cell / 2f, d = (float) Math.sqrt(qx * qx + qy * qy);
                    if (d > WR) continue;
                    float hue = (float) (Math.atan2(qy, qx) / (2 * Math.PI)); if (hue < 0) hue += 1;
                    ctx.fill(cx + dx, cy + dy, cx + dx + cell, cy + dy + cell, ca(0xFF000000 | Draw.hsv(hue, d / WR, s.fv), e));
                }
                int mxp = cx + (int) (Math.cos(s.fh * 2 * Math.PI) * s.fs * WR), myp = cy + (int) (Math.sin(s.fh * 2 * Math.PI) * s.fs * WR);
                Draw.outline(ctx, mxp - 3, myp - 3, mxp + 4, myp + 4, ca(0xFFFFFFFF, e));
                Draw.outline(ctx, mxp - 2, myp - 2, mxp + 3, myp + 3, ca(0xFF000000, e));
                int bx = px + 68, by = y + 14, bh = 2 * WR;
                ctx.fillGradient(bx, by, bx + 10, by + bh, ca(0xFF000000 | Draw.hsv(s.fh, s.fs, 1f), e), ca(0xFF000000, e));
                int vy = by + (int) ((1 - s.fv) * bh);
                ctx.fill(bx - 2, vy - 1, bx + 12, vy + 1, ca(0xFFFFFFFF, e));
                ctx.fill(px + 86, y + 14, px + 124, y + 30, ca(0xFF000000 | s.rgb(), e));
                Draw.outline(ctx, px + 86, y + 14, px + 124, y + 30, ca(0xFFFFFFFF, e * 0.6f));
                ctx.drawText(textRenderer, String.format("#%06X", s.rgb()), px + 86, y + 33, ca(0xFFFFFFFF, e), false);
                h.color = s;
                if (inter && h.y2 > h.y1) hits.add(h);
                int[] pre = {0xFF3B3B, 0xFF9A2E, 0x3BE05A, 0x2EE6E6, 0x8246E6, 0xFFFFFF};
                for (int i = 0; i < pre.length; i++) {
                    int qx = px + 86 + (i % 3) * 14, qy = y + 46 + (i / 3) * 14, col = pre[i];
                    ctx.fill(qx, qy, qx + 12, qy + 12, ca(0xFF000000 | col, e));
                    Hit ph = new Hit(qx, qy, qx + 12, Math.min(qy + 12, clipBottom));
                    ph.left = () -> { s.setRgb(col); Sfx.play("click", 1.3f); };
                    if (inter && ph.y2 > ph.y1) hits.add(ph);
                }
            }
        }
        if (inter && h.y2 > h.y1 && s.type != Setting.Type.COLOR) hits.add(h);
    }

    void setSlider(Hit h, double mx) {
        Setting s = h.slider;
        double t = Math.max(0, Math.min(1, (mx - h.x1) / (double) (h.x2 - h.x1)));
        double v = s.min + t * (s.max - s.min);
        s.v = Math.max(s.min, Math.min(s.max, Math.round(v / s.step) * s.step));
    }

    void setColor(Hit h, double mx, double my) {
        Setting s = h.color;
        if (colorRegion == 0) {
            double dx = mx - (h.x1 + 10 + WR), dy = my - (h.y1 + 14 + WR), d = Math.sqrt(dx * dx + dy * dy);
            float hue = (float) (Math.atan2(dy, dx) / (2 * Math.PI)); if (hue < 0) hue += 1;
            s.setHsv(hue, (float) Math.min(1.0, d / WR), s.fv);
        } else {
            float v = (float) (1 - (my - (h.y1 + 14)) / (2.0 * WR));
            s.setHsv(s.fh, s.fs, Math.max(0f, Math.min(1f, v)));
        }
    }

    @Override public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y(); int btn = click.button();
        if (btn == 0 && Modules.PARTICLES.on.b && Modules.PARTICLES.burst.b) field.burst((float) mx, (float) my, Modules.accent(), Modules.accent2());
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (mx < h.x1 || mx >= h.x2 || my < h.y1 || my >= h.y2) continue;
            if (h.panel != null) {
                if (btn == 0) {
                    dragPanel = h.panel; grabX = (int) mx - h.panel.x; grabY = (int) (my - (h.panel.y + scroll));
                    panels.remove(h.panel); panels.add(h.panel);
                } else if (btn == 1) { h.panel.collapsed = !h.panel.collapsed; Sfx.play("click", h.panel.collapsed ? 0.85f : 1.2f); }
            } else if (h.color != null) {
                if (btn == 0) {
                    int rel = (int) mx - h.x1;
                    colorRegion = rel < 64 ? 0 : (rel < 84 ? 1 : -1);
                    if (colorRegion >= 0) { activeColor = h; setColor(h, mx, my); Sfx.play("click", 1.4f); }
                }
            } else if (h.slider != null) {
                if (btn == 0) { activeSlider = h; setSlider(h, mx); Sfx.play("click", 1.4f); }
            } else if (btn == 0 && h.left != null) h.left.run();
            else if (btn == 1 && h.right != null) h.right.run();
            return true;
        }
        dragScroll = true;
        return super.mouseClicked(click, doubled);
    }

    @Override public boolean mouseDragged(Click click, double dx, double dy) {
        if (dragPanel != null) {
            dragPanel.x = Math.max(0, Math.min(width - W, (int) click.x() - grabX));
            dragPanel.y = (int) (click.y() - grabY - scroll);
            return true;
        }
        if (activeSlider != null) { setSlider(activeSlider, click.x()); return true; }
        if (activeColor != null) { setColor(activeColor, click.x(), click.y()); return true; }
        if (dragScroll) { scroll += dy; return true; }
        return super.mouseDragged(click, dx, dy);
    }

    @Override public boolean mouseReleased(Click click) {
        dragPanel = null; activeSlider = null; activeColor = null; dragScroll = false;
        return super.mouseReleased(click);
    }

    @Override public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll += (float) verticalAmount * 18;
        return true;
    }

    @Override public boolean keyPressed(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_RIGHT_ALT) { close(); return true; }
        return super.keyPressed(input);
    }
}
