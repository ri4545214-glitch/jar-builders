package com.goku;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name;
    public boolean enabled, open;
    public boolean toggleable = true;
    public float anim, openAnim; // GUI animation state
    public final List<Setting> settings = new ArrayList<>();
    protected final MinecraftClient mc = MinecraftClient.getInstance();

    protected Module(String name) { this.name = name; }
    protected Setting add(Setting s) { settings.add(s); return s; }

    public void toggle() { setEnabled(!enabled); }
    public void setEnabled(boolean e) {
        if (e == enabled) return;
        enabled = e;
        if (e) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onPreTick() {}
    public void onTick() {}
    public void onRender(DrawContext ctx, float td) {}
}
