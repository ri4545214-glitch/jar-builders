# Seen by everyone on your own server

A client mod only changes what you see. For your own server use plugins:

- **Skins for everyone**: install SkinsRestorer (Paper/Spigot/Velocity). In game: `/skin set <PlayerName>` (or `/skin url <png url>`).
- **Invisible to other players (armor too)**: install SuperVanish or PremiumVanish and use `/vanish`.
- **Capes**: capes are client-side; other players only see yours if they run the same cape mod/service.
