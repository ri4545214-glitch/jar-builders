# Goku mod's

Fabric **client-side** mod for Minecraft **1.21.10** with a draggable, recolorable module GUI.

Press **Right Alt** in-game to open it.

## GUI
- Animated particle background tinted with the GUI color
- Title "Goku mod's"
- Draggable panels (drag header, right-click header to collapse)
- **Left-click** a module = toggle, **right-click** = open its settings
- Theme panel: Red / Green / Blue sliders change the whole GUI color live

## Modules
| Panel | Module | Notes |
|---|---|---|
| Base | Storage ESP | Chests, trapped chests, hoppers, shulkers, ender chests through walls. Range 0 = unlimited (every loaded chunk). |
| Base | Sus Chunk | Flags chunks with many player-placed block entities. Threshold, types, range, color. |
| Base | Freecam | Detached camera (WASD / Space / Shift), speed setting, periodic terrain refresh while standing still. |
| Combat | Player ESP | Box, name, health, distance, range, color. |
| Combat | Auto Aim | Smooth aim at players/mobs; range, FOV, smoothness, head/body. |
| Combat | Auto Attack | Attacks the entity under the crosshair on cooldown; crit-only option. |
| Combat | Kill Aura | Range, max targets, cooldown/delay, rotate, players/mobs. |

## Build
Requires JDK 21.

```bash
gradle wrapper --gradle-version 8.14.3   # once, to generate ./gradlew
./gradlew build
```
Jar: `build/libs/goku-mod-1.0.0.jar` -> drop into `.minecraft/mods` with Fabric Loader + Fabric API.

GitHub Actions builds every push; pushing a tag like `v1.0.0` attaches the jar to a GitHub Release.

## Notes / limitations
- Freecam can only show chunks the server has sent (server view distance around your real position).
- ESP is drawn in screen space, so it is slightly off while FOV effects (sprinting, potions) are active.
- Settings are not persisted between launches yet.
- Combat/ESP modules are against the rules of most multiplayer servers. Use on servers where it is allowed.
