# Goku mod's

Fabric **client-side** mod for Minecraft **1.21.10** with a draggable, recolorable module GUI.

Press **Right Alt** in-game to open it.

## GUI
- Animated particle background tinted with the GUI color
- Title "Goku mod's"
- Draggable panels (drag header, right-click header to collapse)
- **Left-click** a module = toggle, **right-click** = open its settings
- Theme panel: Red / Green / Blue sliders change the whole GUI color live

## Modules
| Panel | Module | Notes |
|---|---|---|
| Base | Storage ESP | Chests (double chests merged), trapped, barrels, shulkers, ender, hoppers, furnaces, dispensers. 2D / 3D wire / corner boxes, tracers, distance fade, labels, summary HUD. |
| Base | Spawner ESP | Spawners, trial spawners, vaults. |
| Base | Base Finder | Beds, beacons, signs, banners, pots, command blocks, enchanting/brewing/lectern/jukebox/bell/crafter. |
| Base | Entity Finder | Dropped items (min stack), item frames, chest/hopper minecarts, armor stands, villagers. |
| Base | Sus Chunk | Flags chunks with many player-placed block entities. |
| Base | Chunk Log | Logs every chunk the camera visits (cyan = loaded, red = visited but not loaded). Live chunk map HUD, export to `config/gokumod/chunklog-*.txt`. |
| Base | Freecam | Own view angles: full 360 yaw, mouse/touch or arrow-key look, player not turned, smoothing, Ctrl boost, flat/look movement, blocks clicks, auto chunk log, info overlay. |
| Combat | Player ESP | Box styles, **tracer lines**, name, health, distance. |
| Combat | Auto Aim / Auto Attack / Kill Aura | unchanged |
| Theme | GUI Color | Red / Green / Blue sliders. |
| Particles | Particles | Amount, size, speed, opacity, direction, shape, color (theme/rainbow/custom), twinkle, link lines, mouse repel. |

## Build
Requires JDK 21.

```bash
gradle wrapper --gradle-version 8.14.3   # once, to generate ./gradlew
./gradlew build
```
Jar: `build/libs/goku-mod-1.0.0.jar` -> drop into `.minecraft/mods` with Fabric Loader + Fabric API.

GitHub Actions builds every push; pushing a tag like `v1.0.0` attaches the jar to a GitHub Release.

## Notes / limitations
- Freecam can only show chunks the server has sent (around your real position). Chunk Log shows which chunks you visited were not loaded.
- ESP is drawn in screen space, so it is slightly off while FOV effects (sprinting, potions) are active.
- Settings are not persisted between launches yet.
- Combat/ESP modules are against the rules of most multiplayer servers. Use on servers where it is allowed.
