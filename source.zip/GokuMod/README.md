# Goku mod's

Fabric **client-side** mod for Minecraft **1.21.10** with a draggable, recolorable module GUI.

Press **Right Alt** in-game to open it.

## GUI
- Animated particle background tinted with the GUI color
- Title "Goku mod's"
- Draggable panels (drag header, right-click header to collapse)
- **Left-click** a module = toggle, **right-click** = open its settings
- Theme panel: Red / Green / Blue sliders change the whole GUI color live

## GUI
- Animated open sequence, gradient panels, smooth toggles and sliding settings
- Theme modes: Static / Rainbow / Pulse / Gradient (+ RGB sliders)
- Particles panel (amount, size, speed, shape, colors, link lines, mouse repel)
- Sound panel: original phonk loop while the GUI is open, click/toggle/open sounds, volume + pitch
- Tap = toggle, RMB/long-press = settings, drag headers, drag empty space or mouse-wheel to scroll

## New in 1.8
- **Silent Aim**: rotation is sent to the server for the tick, the camera never moves. Range, FOV, priority, head/chest, attack with cooldown, only-while-attack-held.
- **Keystrokes** HUD: WASD, space, mouse buttons with CPS.
- Animated 2x title with glow, wave and a sweeping underline.
- **Speed**: default raised to 0.5 b/tick (0.28 is vanilla sprint speed, so it looked like it did nothing), max 2.0; it no longer fights Fly.

## New in 1.7.1
- Config panel: **Allow This Server** adds the server you are on to Online Guard's list.

## New in 1.7
- **Fly** (Movement): Velocity (full 3D control, Jump up / Sneak down), Creative (client flight ability, only works where the server allows flying) and Glide. Speed settings, hover.
- **Base Finder AI v2**: 10 evidence categories from blocks, containers and entities, split into proof vs. soft evidence; recognises natural structures (mineshaft, village, stronghold, ancient city, trial chamber, fortress/bastion, end city, monument, temple) and discounts them; merges neighbouring chunks into clusters; classifies Stash / Redstone-Farm / Base / Structure; remembers unloaded chunks; players and tamed pets count as proof; coordinates, confidence and reasons in the HUD; *Export List* writes `config/gokumod/base-ai.txt`.
- New modules: **Sprint**, **Step**, **Fullbright**, **Auto Armor**, **Chest Stealer**.

## New in 1.6
- **Color wheel** (GUI Color and Particles > Custom Color): drag on the wheel for hue/saturation, the bar for brightness, tap a preset square.
- **Particles**: styles (Float, Snow, Rain, Fireflies, Swirl), depth sizes/parallax, glow, trails, click bursts, mouse repel/attract, gradient color.
- **Music**: added Montagem Perigosa, Luz Roja and Fight Back (Track setting + Shuffle).
- **Anchor Macro** now has Mode: Normal / Safe / Air (Safe Anchor and Air Anchor are merged into it). Safe/Air shield uses **glowstone**, never auto-places an anchor in Normal/Safe.
- **Auto Bridge** reworked for servers: clicks real block faces within reach, looks ahead while moving, optional Pitch/Full rotation applied before the movement packet, no velocity hacks.
- **Crystal PvP**: plans at the start of the tick and acts at the end, so Rotate is seen by the server before the attack/place.
- **Online Guard** (Config panel): cheat modules only run in singleplayer, LAN/localhost, or servers listed in `config/gokumod/allowed-servers.txt`.

## New in 1.4
- **Air Anchor**: places a respawn anchor in mid-air (crosshair air / above / beside / under the target), charges and detonates it, with optional shield block. Needs a server that accepts air placing.
- **Safe Anchor**: anchor macro that puts a block between you and the anchor and aborts below a health limit.
- **Auto D-Tap**: after Crystal PvP breaks a crystal it bursts extra zero-delay place+break cycles and hits the crystal a second time.
- **Second track "Aura Phonk"** + Shuffle. Sound panel: *Play Without GUI* (or Right Ctrl hotkey) plays the music in-game.
- Speed module is unchanged.

## New in 1.3
- **Freecam look** now uses a Mixin on `Entity.changeLookDirection` (same technique as the Freecam mod): mouse/touch/arrow look rotates only the camera, your player never turns. Full 360 yaw, +-90 pitch, Free or Orbit mode.
- **Load Chunks (radius)** (default 10): freecam raises your client view distance while active so the server sends/keeps more chunks (limited by the server's own view distance).
- **Base Finder AI**: scores every loaded chunk (artificial blocks, containers, stash entities) into a confidence %, shows top candidates with compass + tracer; **Auto Find** can walk to the best one.
- **Crystal PvP**: damage-calculated place/break (target vs self damage, exposure, armor, difficulty), face place, anti-suicide, lethal priority, auto switch, obsidian surround, eating pause.
- **Automation**: Auto Clicker, Auto Walk, Auto Mine (hold / 1x2 tunnel), Auto Find, Player Hunter.
- **Config panel**: profiles (default/pvp/base/legit) saved to `config/gokumod/*.json`; the last saved config loads at startup. Auto-save on GUI close.

## Modules
| Panel | Module | Notes |
|---|---|---|
| Base | Storage ESP | Merged double chests, 2D/3D/corner boxes, tracers, fade, labels, summary |
| Base | Spawner ESP | Spawners, trial spawners, vaults |
| Base | Base Finder | Beds, beacons, signs, banners, pots, command blocks, utility blocks |
| Base | Entity Finder | Dropped items, item frames, storage minecarts, armor stands, villagers |
| Base | Sus Chunk | Weighted score per chunk, whole chunk column boxed, top-3 list with coordinates |
| Base | Chunk Log | Visited-chunk log + live loaded/unloaded map, export to `config/gokumod/` |
| Base | Freecam | Free or Orbit-Player mode, 360 look, sensitivity, look smoothing, arrow-key look, boost, smoothing |
| Combat | Player ESP | Boxes, tracers, name, health, distance |
| Combat | Auto Aim / Auto Attack / Kill Aura | Range, FOV, smoothing, cooldowns |
| Combat | Auto Crystal | Aura or Macro mode, place/break ranges + delays, auto switch, rotate, safety |
| Combat | Anchor Macro | Charge + detonate the anchor you look at, optional auto place |
| Combat | Auto Totem | Keeps a totem in the offhand (health threshold, delay, prefer hotbar) |
| Combat | Hover Totem | Hover a totem in any inventory to move it to offhand / hotbar |
| Movement | Speed | Strafe / BHop / Ground, speed + hop height |
| Movement | Auto Bridge | Places blocks under your feet, tower, swap back |

## Build
Requires JDK 21.

```bash
gradle wrapper --gradle-version 8.14.3   # once, to generate ./gradlew
./gradlew build
```
Jar: `build/libs/goku-mod-1.0.0.jar` -> drop into `.minecraft/mods` with Fabric Loader + Fabric API.

GitHub Actions builds every push; pushing a tag like `v1.0.0` attaches the jar to a GitHub Release.

## Notes / limitations
- Freecam can only show chunks the server has sent (around your real position). Chunk Log shows which chunks you visited were not loaded.
- ESP is drawn in screen space, so it is slightly off while FOV effects (sprinting, potions) are active.
- Settings are not persisted between launches yet.
- Combat/ESP modules are against the rules of most multiplayer servers. Use on servers where it is allowed.
