# Goku mod's

Fabric **client-side** mod for Minecraft **1.21.10** with a draggable, recolorable module GUI.

Press **Right Alt** in-game to open it.

## GUI
- Animated particle background tinted with the GUI color
- Title "Goku mod's"
- Draggable panels (drag header, right-click header to collapse)
- **Left-click** a module = toggle, **right-click** = open its settings
- Theme panel: Red / Green / Blue sliders change the whole GUI color live

## GUI
- Animated open sequence, gradient panels, smooth toggles and sliding settings
- Theme modes: Static / Rainbow / Pulse / Gradient (+ RGB sliders)
- Particles panel (amount, size, speed, shape, colors, link lines, mouse repel)
- Sound panel: original phonk loop while the GUI is open, click/toggle/open sounds, volume + pitch
- Tap = toggle, RMB/long-press = settings, drag headers, drag empty space or mouse-wheel to scroll

## Modules
| Panel | Module | Notes |
|---|---|---|
| Base | Storage ESP | Merged double chests, 2D/3D/corner boxes, tracers, fade, labels, summary |
| Base | Spawner ESP | Spawners, trial spawners, vaults |
| Base | Base Finder | Beds, beacons, signs, banners, pots, command blocks, utility blocks |
| Base | Entity Finder | Dropped items, item frames, storage minecarts, armor stands, villagers |
| Base | Sus Chunk | Weighted score per chunk, whole chunk column boxed, top-3 list with coordinates |
| Base | Chunk Log | Visited-chunk log + live loaded/unloaded map, export to `config/gokumod/` |
| Base | Freecam | Free or Orbit-Player mode, 360 look, sensitivity, look smoothing, arrow-key look, boost, smoothing |
| Combat | Player ESP | Boxes, tracers, name, health, distance |
| Combat | Auto Aim / Auto Attack / Kill Aura | Range, FOV, smoothing, cooldowns |
| Combat | Auto Crystal | Aura or Macro mode, place/break ranges + delays, auto switch, rotate, safety |
| Combat | Anchor Macro | Charge + detonate the anchor you look at, optional auto place |
| Combat | Auto Totem | Keeps a totem in the offhand (health threshold, delay, prefer hotbar) |
| Combat | Hover Totem | Hover a totem in any inventory to move it to offhand / hotbar |
| Movement | Speed | Strafe / BHop / Ground, speed + hop height |
| Movement | Auto Bridge | Places blocks under your feet, tower, swap back |

## Build
Requires JDK 21.

```bash
gradle wrapper --gradle-version 8.14.3   # once, to generate ./gradlew
./gradlew build
```
Jar: `build/libs/goku-mod-1.0.0.jar` -> drop into `.minecraft/mods` with Fabric Loader + Fabric API.

GitHub Actions builds every push; pushing a tag like `v1.0.0` attaches the jar to a GitHub Release.

## Notes / limitations
- Freecam can only show chunks the server has sent (around your real position). Chunk Log shows which chunks you visited were not loaded.
- ESP is drawn in screen space, so it is slightly off while FOV effects (sprinting, potions) are active.
- Settings are not persisted between launches yet.
- Combat/ESP modules are against the rules of most multiplayer servers. Use on servers where it is allowed.
