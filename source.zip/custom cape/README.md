# CustomCapes & Cape Studio (Minecraft 1.21.11 Fabric — MJ Launcher Ready)

A complete **Minecraft 1.21.11 Fabric** mod that lets players equip built-in static and animated capes, import custom `.png` or animated `.gif` capes, design capes in-game with a pixel editor, and sync capes across multiplayer servers.

---

## Features
- **Built-in Cape Library**: Includes 5 static capes (*Migrator Crimson, Enderman Obsidian, Creeper Emerald, Royal Sapphire, Cherry Blossom*) and 4 animated capes (*Galaxy Nebula, Inferno Flame, RGB Matrix, Ocean Wave*).
- **Import Any Custom Cape**: Click **Import PNG / GIF** in-game (or drop files into `.minecraft/config/customcapes/capes/`) to load any `.png` image, vertical animated sprite sheet, or animated `.gif`.
- **In-Game Cape Creator Studio**: Paint your own `10x16` cape pixel-by-pixel with symmetry mirroring and save/equip immediately.
- **Multiplayer Server Support**: Install the `.jar` on both the **Fabric Server** and **Client** so every player sees each other's custom and animated capes in real time.
- **MJ Launcher Compatible**: Works seamlessly with offline/custom accounts in MJ Launcher via player UUID mapping.

---

## How to Compile into a `.jar` File via GitHub (Easiest Method — No Setup Required)
1. Create a new repository on **GitHub**.
2. Upload all files from this ZIP into your repository (make sure `.github/workflows/build.yml` is included).
3. Go to the **Actions** tab in your GitHub repository.
4. Click **Build Fabric Mod (.jar)** and select **Run workflow** (or push any commit).
5. Once complete, download the compiled **`CustomCapes-1.21.11-Fabric-Mod`** artifact containing `customcapes-1.0.0.jar`.

---

## How to Compile Locally
Requirements: **Java 21 (JDK 21)** and **Gradle 8.11+**.
```bash
gradle build
```
Your compiled mod will be generated at:
`build/libs/customcapes-1.0.0.jar`

---

## Installation (MJ Launcher & Server)
1. Install **Fabric Loader 0.16.10+** for **Minecraft 1.21.11** in MJ Launcher.
2. Download **Fabric API** for `1.21.11` and place both `fabric-api` and `customcapes-1.0.0.jar` into your `mods/` folder.
3. *(Optional for Multiplayer)* Put `customcapes-1.0.0.jar` and `fabric-api` into your Fabric server's `mods/` folder so all players can see each other's capes.
4. Launch the game and press **`K`** (configurable in *Controls -> CustomCapes*) to open **CustomCapes Library & Studio**.
