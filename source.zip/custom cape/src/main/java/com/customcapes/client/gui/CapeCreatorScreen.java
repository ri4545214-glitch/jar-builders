package com.customcapes.client.gui;

import com.customcapes.client.CapeEntry;
import com.customcapes.client.CapeManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.Arrays;

public class CapeCreatorScreen extends Screen {
    private final Screen parent;
    // Standard Minecraft Cape front/back canvas is 10x16 pixels
    private final int[][] pixels = new int[10][16];
    private int selectedColor = 0xFFE11D48;
    private TextFieldWidget nameField;
    private String feedback = "Click or drag on the 10x16 grid to paint your cape!";

    private static final int[] PALETTE = new int[]{
            0xFFE11D48, // Crimson
            0xFFF97316, // Orange
            0xFFEAB308, // Gold
            0xFF22C55E, // Emerald
            0xFF06B6D4, // Cyan
            0xFF3B82F6, // Royal Blue
            0xFF8B5CF6, // Purple
            0xFFEC4899, // Pink
            0xFFFFFFFF, // White
            0xFF1E293B, // Dark Slate
            0xFF09090B, // Obsidian Black
            0xFF78350F  // Brown
    };

    public CapeCreatorScreen(Screen parent) {
        super(Text.translatable("screen.customcapes.creator"));
        this.parent = parent;
        fillCanvas(0xFF1E293B);
    }

    private void fillCanvas(int argb) {
        for (int[] row : pixels) {
            Arrays.fill(row, argb);
        }
    }

    @Override
    protected void init() {
        int rightX = this.width / 2 + 30;

        this.nameField = new TextFieldWidget(this.textRenderer, rightX, 55, 140, 20, Text.literal("Cape Name"));
        this.nameField.setText("MyCustomCape");
        this.addDrawableChild(this.nameField);

        // Fill All with Active Color
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Fill Background"), btn -> {
            fillCanvas(selectedColor);
        }).dimensions(rightX, 145, 140, 20).build());

        // Mirror Horizontal Symmetry
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Mirror Left -> Right"), btn -> {
            for (int y = 0; y < 16; y++) {
                for (int x = 0; x < 5; x++) {
                    pixels[9 - x][y] = pixels[x][y];
                }
            }
        }).dimensions(rightX, 170, 140, 20).build());

        // Save & Equip
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Save & Equip Cape"), btn -> saveCape())
                .dimensions(rightX, 200, 140, 20).build());

        // Back
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Back to Library"), btn -> {
            if (this.client != null) {
                this.client.setScreen(parent);
            }
        }).dimensions(rightX, 225, 140, 20).build());
    }

    private void saveCape() {
        try {
            BufferedImage uv = new BufferedImage(64, 32, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = uv.createGraphics();
            g.setColor(new Color(pixels[0][0], true));
            g.fillRect(0, 0, 22, 17);
            g.dispose();

            for (int y = 0; y < 16; y++) {
                for (int x = 0; x < 10; x++) {
                    // Front face (1,1) and Back face (12,1)
                    uv.setRGB(1 + x, 1 + y, pixels[x][y]);
                    uv.setRGB(12 + x, 1 + y, pixels[x][y]);
                }
            }

            CapeEntry created = CapeManager.getInstance().saveCreatedCape(nameField.getText(), uv);
            CapeManager.getInstance().equipLocalCape(created);
            if (this.client != null) {
                this.client.setScreen(new CapeLibraryScreen());
            }
        } catch (Exception e) {
            feedback = "Error saving cape: " + e.getMessage();
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (handleGridPaint(mouseX, mouseY) || handlePaletteClick(mouseX, mouseY)) {
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (handleGridPaint(mouseX, mouseY)) {
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    private boolean handleGridPaint(double mouseX, double mouseY) {
        int gridX = this.width / 2 - 140;
        int gridY = 45;
        int cellSize = 12;

        if (mouseX >= gridX && mouseX < gridX + 10 * cellSize && mouseY >= gridY && mouseY < gridY + 16 * cellSize) {
            int gx = (int) ((mouseX - gridX) / cellSize);
            int gy = (int) ((mouseY - gridY) / cellSize);
            pixels[gx][gy] = selectedColor;
            return true;
        }
        return false;
    }

    private boolean handlePaletteClick(double mouseX, double mouseY) {
        int palX = this.width / 2 + 30;
        int palY = 85;
        int swatch = 20;

        for (int i = 0; i < PALETTE.length; i++) {
            int col = i % 6;
            int row = i / 6;
            int sx = palX + col * (swatch + 3);
            int sy = palY + row * (swatch + 3);
            if (mouseX >= sx && mouseX <= sx + swatch && mouseY >= sy && mouseY <= sy + swatch) {
                selectedColor = PALETTE[i];
                return true;
            }
        }
        return false;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        super.render(context, mouseX, mouseY, delta);

        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 12, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(feedback), this.width / 2, 26, 0xAAAAAA);

        // Draw 10x16 Cape Pixel Editor Grid
        int gridX = this.width / 2 - 140;
        int gridY = 45;
        int cellSize = 12;

        context.fill(gridX - 2, gridY - 2, gridX + 10 * cellSize + 2, gridY + 16 * cellSize + 2, 0xFFFFFFFF);
        for (int y = 0; y < 16; y++) {
            for (int x = 0; x < 10; x++) {
                int px = gridX + x * cellSize;
                int py = gridY + y * cellSize;
                context.fill(px, py, px + cellSize - 1, py + cellSize - 1, pixels[x][y]);
            }
        }

        // Draw Color Palette Swatches
        int palX = this.width / 2 + 30;
        int palY = 85;
        int swatch = 20;

        for (int i = 0; i < PALETTE.length; i++) {
            int col = i % 6;
            int row = i / 6;
            int sx = palX + col * (swatch + 3);
            int sy = palY + row * (swatch + 3);
            if (PALETTE[i] == selectedColor) {
                context.fill(sx - 2, sy - 2, sx + swatch + 2, sy + swatch + 2, 0xFFFFFFFF);
            }
            context.fill(sx, sy, sx + swatch, sy + swatch, PALETTE[i]);
        }
    }
}
