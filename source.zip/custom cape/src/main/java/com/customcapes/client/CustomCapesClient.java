package com.customcapes.client;

import com.customcapes.client.gui.CapeLibraryScreen;
import com.customcapes.network.CapeSyncPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class CustomCapesClient implements ClientModInitializer {
    public static KeyBinding openCapeMenuKey;

    @Override
    public void onInitializeClient() {
        CapeManager.getInstance().init();

        // Register Keybind (Default: K)
        openCapeMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.customcapes.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_K,
                "category.customcapes"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openCapeMenuKey.wasPressed()) {
                if (client.player != null) {
                    client.setScreen(new CapeLibraryScreen());
                }
            }
        });

        // Receive remote player capes from server
        ClientPlayNetworking.registerGlobalReceiver(CapeSyncPayload.ID, (payload, context) -> {
            context.client().execute(() -> CapeManager.getInstance().applyRemotePlayerCape(payload));
        });

        // Automatically sync active cape when joining a multiplayer server
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            client.execute(() -> CapeManager.getInstance().onJoinServerSync());
        });
    }
}
