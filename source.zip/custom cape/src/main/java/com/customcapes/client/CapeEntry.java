package com.customcapes.client;

import net.minecraft.util.Identifier;

import java.util.List;

public class CapeEntry {
    private final String id;
    private final String displayName;
    private final String category; // "Built-In", "Animated", "Custom"
    private final boolean animated;
    private final int frameDelayMs;
    private final List<Identifier> frameTextures;
    private final byte[] rawPngBytes;

    public CapeEntry(String id, String displayName, String category, boolean animated, int frameDelayMs, List<Identifier> frameTextures, byte[] rawPngBytes) {
        this.id = id;
        this.displayName = displayName;
        this.category = category;
        this.animated = animated;
        this.frameDelayMs = Math.max(40, frameDelayMs);
        this.frameTextures = frameTextures;
        this.rawPngBytes = rawPngBytes;
    }

    public String getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getCategory() {
        return category;
    }

    public boolean isAnimated() {
        return animated;
    }

    public int getFrameDelayMs() {
        return frameDelayMs;
    }

    public List<Identifier> getFrameTextures() {
        return frameTextures;
    }

    public byte[] getRawPngBytes() {
        return rawPngBytes;
    }

    public Identifier getCurrentFrameTexture() {
        if (frameTextures == null || frameTextures.isEmpty()) {
            return null;
        }
        if (!animated || frameTextures.size() == 1) {
            return frameTextures.get(0);
        }
        long now = System.currentTimeMillis();
        int frameIndex = (int) ((now / frameDelayMs) % frameTextures.size());
        return frameTextures.get(frameIndex);
    }
}
