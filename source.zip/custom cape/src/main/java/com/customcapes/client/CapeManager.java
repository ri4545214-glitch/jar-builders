package com.customcapes.client;

import com.customcapes.CustomCapesMod;
import com.customcapes.client.gui.CapeLibraryScreen;
import com.customcapes.network.CapeSyncPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class CapeManager {
    private static final CapeManager INSTANCE = new CapeManager();

    public static CapeManager getInstance() {
        return INSTANCE;
    }

    private final Path capesDir;
    private final Path configFile;
    private final List<CapeEntry> library = new ArrayList<>();
    private final Map<UUID, CapeEntry> playerActiveCapes = new ConcurrentHashMap<>();
    private String selectedCapeId = "";

    private CapeManager() {
        Path configRoot = FabricLoader.getInstance().getConfigDir().resolve("customcapes");
        this.capesDir = configRoot.resolve("capes");
        this.configFile = configRoot.resolve("selected_cape.txt");
    }

    public void init() {
        try {
            Files.createDirectories(capesDir);
        } catch (IOException e) {
            CustomCapesMod.LOGGER.error("Failed to create customcapes directory", e);
        }

        library.clear();
        registerBuiltInCapes();
        loadUserFolderCapes();
        loadSavedSelection();
    }

    private void registerBuiltInCapes() {
        // Static Built-in Capes (procedural 64x32 Minecraft Cape UV textures)
        addBuiltInStatic("builtin_migrator", "Migrator Crimson", 0xFFB81D24, 0xFFFFD700, "crest");
        addBuiltInStatic("builtin_minecon_2016", "Enderman Obsidian", 0xFF1A1025, 0xFFCC33FF, "eyes");
        addBuiltInStatic("builtin_creeper", "Creeper Emerald", 0xFF1F7A1F, 0xFF0A140A, "creeper");
        addBuiltInStatic("builtin_royal_blue", "Royal Sapphire", 0xFF1034A6, 0xFFE5E4E2, "border");
        addBuiltInStatic("builtin_cherry", "Cherry Blossom", 0xFFFFB7C5, 0xFF882D49, "stripes");

        // Animated Built-in Capes (multi-frame sprite sheets)
        addBuiltInAnimated("anim_galaxy_nebula", "Animated Galaxy Nebula", 120, 8, "galaxy");
        addBuiltInAnimated("anim_inferno_flame", "Animated Inferno Flame", 100, 8, "flame");
        addBuiltInAnimated("anim_rgb_cyber", "Animated RGB Matrix", 90, 10, "rgb");
        addBuiltInAnimated("anim_ocean_wave", "Animated Ocean Wave", 130, 8, "ocean");
    }

    private void addBuiltInStatic(String id, String name, int primaryArgb, int accentArgb, String pattern) {
        try {
            BufferedImage img = CapeTextureGenerator.generateStaticCape(primaryArgb, accentArgb, pattern);
            byte[] pngBytes = toPngBytes(img);
            List<Identifier> frames = registerFramesFromVerticalSheet(id, img, 1);
            library.add(new CapeEntry(id, name, "Built-In", false, 100, frames, pngBytes));
        } catch (Exception e) {
            CustomCapesMod.LOGGER.error("Failed generating built-in cape " + id, e);
        }
    }

    private void addBuiltInAnimated(String id, String name, int delayMs, int frameCount, String theme) {
        try {
            BufferedImage spriteSheet = CapeTextureGenerator.generateAnimatedCapeSheet(theme, frameCount);
            byte[] pngBytes = toPngBytes(spriteSheet);
            List<Identifier> frames = registerFramesFromVerticalSheet(id, spriteSheet, frameCount);
            library.add(new CapeEntry(id, name, "Animated", true, delayMs, frames, pngBytes));
        } catch (Exception e) {
            CustomCapesMod.LOGGER.error("Failed generating animated cape " + id, e);
        }
    }

    public void loadUserFolderCapes() {
        // Remove previous user entries before reload
        library.removeIf(entry -> "Custom".equals(entry.getCategory()));

        File[] files = capesDir.toFile().listFiles((dir, name) -> {
            String lower = name.toLowerCase(Locale.ROOT);
            return lower.endsWith(".png") || lower.endsWith(".gif");
        });

        if (files == null) return;
        Arrays.sort(files);

        for (File file : files) {
            try {
                importFileInternal(file, false);
            } catch (Exception e) {
                CustomCapesMod.LOGGER.error("Error loading user cape: " + file.getName(), e);
            }
        }
    }

    public CapeEntry importExternalFile(File sourceFile) throws IOException {
        String cleanName = sourceFile.getName().replaceAll("[^a-zA-Z0-9._-]", "_");
        Path target = capesDir.resolve(cleanName);
        if (!sourceFile.toPath().toAbsolutePath().equals(target.toAbsolutePath())) {
            Files.copy(sourceFile.toPath(), target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        }
        return importFileInternal(target.toFile(), true);
    }

    private CapeEntry importFileInternal(File file, boolean replaceIfExists) throws IOException {
        String lower = file.getName().toLowerCase(Locale.ROOT);
        String baseName = file.getName().replaceFirst("[.][^.]+$", "");
        String id = "custom_" + baseName.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_]", "_");

        if (replaceIfExists) {
            library.removeIf(e -> e.getId().equals(id));
        }

        if (lower.endsWith(".gif")) {
            List<BufferedImage> gifFrames = readGifFrames(file);
            if (gifFrames.isEmpty()) throw new IOException("Empty GIF");
            int frameCount = Math.min(gifFrames.size(), 24);
            BufferedImage sheet = new BufferedImage(64, 32 * frameCount, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = sheet.createGraphics();
            for (int i = 0; i < frameCount; i++) {
                BufferedImage scaled = scaleToCapeUv(gifFrames.get(i));
                g.drawImage(scaled, 0, i * 32, null);
            }
            g.dispose();

            byte[] pngBytes = toPngBytes(sheet);
            List<Identifier> identifiers = registerFramesFromVerticalSheet(id, sheet, frameCount);
            CapeEntry entry = new CapeEntry(id, baseName + " (GIF)", "Custom", frameCount > 1, 100, identifiers, pngBytes);
            library.add(entry);
            return entry;
        } else {
            BufferedImage raw = ImageIO.read(file);
            if (raw == null) throw new IOException("Invalid PNG file");

            // Check if vertical animated sprite sheet (height is a multiple of width/2)
            int expectedFrameHeight = Math.max(1, raw.getWidth() / 2);
            int frameCount = 1;
            if (raw.getHeight() > expectedFrameHeight && raw.getHeight() % expectedFrameHeight == 0) {
                frameCount = Math.min(raw.getHeight() / expectedFrameHeight, 32);
            }

            BufferedImage normalizedSheet = new BufferedImage(64, 32 * frameCount, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = normalizedSheet.createGraphics();
            for (int i = 0; i < frameCount; i++) {
                BufferedImage sub = raw.getSubimage(0, i * expectedFrameHeight, raw.getWidth(), expectedFrameHeight);
                g.drawImage(scaleToCapeUv(sub), 0, i * 32, null);
            }
            g.dispose();

            byte[] pngBytes = toPngBytes(normalizedSheet);
            List<Identifier> identifiers = registerFramesFromVerticalSheet(id, normalizedSheet, frameCount);
            boolean isAnim = frameCount > 1 || baseName.toLowerCase(Locale.ROOT).contains("anim");
            CapeEntry entry = new CapeEntry(id, baseName, "Custom", isAnim, 100, identifiers, pngBytes);
            library.add(entry);
            return entry;
        }
    }

    public CapeEntry saveCreatedCape(String name, BufferedImage capeUv64x32) throws IOException {
        String safeName = name.trim().isEmpty() ? "custom_cape_" + System.currentTimeMillis() : name.trim().replaceAll("[^a-zA-Z0-9_-]", "_");
        Path outFile = capesDir.resolve(safeName + ".png");
        ImageIO.write(capeUv64x32, "PNG", outFile.toFile());
        return importFileInternal(outFile.toFile(), true);
    }

    public void equipLocalCape(CapeEntry entry) {
        MinecraftClient client = MinecraftClient.getInstance();
        UUID localUuid = client.getSession().getUuidOrNull();

        if (entry == null) {
            selectedCapeId = "";
            if (localUuid != null) {
                playerActiveCapes.remove(localUuid);
            }
            saveSelectedSelection();
            syncToServer(null);
            return;
        }

        selectedCapeId = entry.getId();
        if (localUuid != null) {
            playerActiveCapes.put(localUuid, entry);
        }
        saveSelectedSelection();
        syncToServer(entry);
    }

    public void onJoinServerSync() {
        if (selectedCapeId != null && !selectedCapeId.isEmpty()) {
            getCapeById(selectedCapeId).ifPresent(this::syncToServer);
        }
    }

    public void syncToServer(CapeEntry entry) {
        if (!ClientPlayNetworking.canSend(CapeSyncPayload.ID)) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        UUID uuid = client.getSession().getUuidOrNull();
        if (uuid == null) return;

        if (entry == null) {
            ClientPlayNetworking.send(new CapeSyncPayload(uuid, "", false, 0, 100, new byte[0]));
        } else {
            ClientPlayNetworking.send(new CapeSyncPayload(
                    uuid,
                    entry.getDisplayName(),
                    entry.isAnimated(),
                    entry.getFrameTextures().size(),
                    entry.getFrameDelayMs(),
                    entry.getRawPngBytes()
            ));
        }
    }

    public void applyRemotePlayerCape(CapeSyncPayload payload) {
        if (payload.pngData() == null || payload.pngData().length == 0) {
            playerActiveCapes.remove(payload.playerUuid());
            return;
        }
        try {
            BufferedImage sheet = ImageIO.read(new ByteArrayInputStream(payload.pngData()));
            if (sheet == null) return;
            int frames = Math.max(1, payload.frameCount());
            String remoteId = "remote_" + payload.playerUuid().toString().replace("-", "");
            List<Identifier> textures = registerFramesFromVerticalSheet(remoteId, sheet, frames);
            CapeEntry remoteEntry = new CapeEntry(
                    remoteId,
                    payload.capeName(),
                    "Remote",
                    payload.animated() && frames > 1,
                    payload.frameDelayMs(),
                    textures,
                    payload.pngData()
            );
            playerActiveCapes.put(payload.playerUuid(), remoteEntry);
        } catch (Exception e) {
            CustomCapesMod.LOGGER.error("Failed to decode remote player cape for " + payload.playerUuid(), e);
        }
    }

    public Identifier getActiveCapeTexture(UUID playerUuid) {
        CapeEntry entry = playerActiveCapes.get(playerUuid);
        return entry != null ? entry.getCurrentFrameTexture() : null;
    }

    public List<CapeEntry> getLibrary() {
        return Collections.unmodifiableList(library);
    }

    public String getSelectedCapeId() {
        return selectedCapeId;
    }

    public Optional<CapeEntry> getCapeById(String id) {
        return library.stream().filter(c -> c.getId().equals(id)).findFirst();
    }

    public Path getCapesDirectory() {
        return capesDir;
    }

    private void loadSavedSelection() {
        if (!Files.exists(configFile)) return;
        try {
            String saved = Files.readString(configFile).trim();
            if (!saved.isEmpty()) {
                getCapeById(saved).ifPresent(this::equipLocalCape);
            }
        } catch (IOException ignored) {
        }
    }

    private void saveSelectedSelection() {
        try {
            Files.writeString(configFile, selectedCapeId == null ? "" : selectedCapeId);
        } catch (IOException ignored) {
        }
    }

    private List<Identifier> registerFramesFromVerticalSheet(String baseId, BufferedImage sheet, int frameCount) throws IOException {
        List<Identifier> list = new ArrayList<>();
        int frameW = sheet.getWidth();
        int frameH = sheet.getHeight() / Math.max(1, frameCount);

        for (int i = 0; i < frameCount; i++) {
            BufferedImage sub = sheet.getSubimage(0, i * frameH, frameW, frameH);
            NativeImage nativeImage = toNativeImage(sub);
            Identifier texId = Identifier.of(CustomCapesMod.MOD_ID, "capes/" + baseId + "_f" + i);
            MinecraftClient.getInstance().getTextureManager().registerTexture(texId, new NativeImageBackedTexture(nativeImage));
            list.add(texId);
        }
        return list;
    }

    private NativeImage toNativeImage(BufferedImage img) {
        int w = img.getWidth();
        int h = img.getHeight();
        NativeImage nativeImage = new NativeImage(NativeImage.Format.RGBA, w, h, false);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int argb = img.getRGB(x, y);
                nativeImage.setColorArgb(x, y, argb);
            }
        }
        return nativeImage;
    }

    private BufferedImage scaleToCapeUv(BufferedImage src) {
        // Standard Minecraft Cape Texture is 64x32, front face is at (1,1) to (11,17) -> 10x16 pixels
        if (src.getWidth() == 64 && src.getHeight() == 32) {
            return src;
        }
        BufferedImage canvas = new BufferedImage(64, 32, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = canvas.createGraphics();
        // Fill full UV background with average top-left pixel
        int bg = src.getRGB(0, 0);
        g.setColor(new java.awt.Color(bg, true));
        g.fillRect(0, 0, 22, 17);
        // Draw main front face (1,1 to 11,17) and back face (12,1 to 22,17)
        g.drawImage(src, 1, 1, 10, 16, null);
        g.drawImage(src, 12, 1, 10, 16, null);
        g.dispose();
        return canvas;
    }

    private byte[] toPngBytes(BufferedImage img) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(img, "PNG", baos);
        return baos.toByteArray();
    }

    private List<BufferedImage> readGifFrames(File file) throws IOException {
        List<BufferedImage> frames = new ArrayList<>();
        try (ImageInputStream stream = ImageIO.createImageInputStream(file)) {
            Iterator<ImageReader> readers = ImageIO.getImageReadersByFormatName("gif");
            if (!readers.hasNext()) return frames;
            ImageReader reader = readers.next();
            reader.setInput(stream);
            int count = reader.getNumImages(true);
            for (int i = 0; i < count; i++) {
                frames.add(reader.read(i));
            }
            reader.dispose();
        }
        return frames;
    }
}
