package com.customcapes.client.gui;

import com.customcapes.client.CapeEntry;
import com.customcapes.client.CapeManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

import java.io.File;
import java.util.List;

public class CapeLibraryScreen extends Screen {
    private int selectedIndex = 0;
    private int scrollOffset = 0;
    private String statusMessage = "Press [K] anytime to open Cape Studio";

    public CapeLibraryScreen() {
        super(Text.translatable("screen.customcapes.title"));
    }

    @Override
    protected void init() {
        List<CapeEntry> capes = CapeManager.getInstance().getLibrary();
        String activeId = CapeManager.getInstance().getSelectedCapeId();
        for (int i = 0; i < capes.size(); i++) {
            if (capes.get(i).getId().equals(activeId)) {
                selectedIndex = i;
                break;
            }
        }

        int rightPanelX = this.width / 2 + 20;
        int btnWidth = 150;

        // Equip Selected Cape
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Equip Selected Cape"), btn -> {
            List<CapeEntry> list = CapeManager.getInstance().getLibrary();
            if (!list.isEmpty() && selectedIndex >= 0 && selectedIndex < list.size()) {
                CapeEntry chosen = list.get(selectedIndex);
                CapeManager.getInstance().equipLocalCape(chosen);
                statusMessage = "Equipped: " + chosen.getDisplayName();
            }
        }).dimensions(rightPanelX, this.height - 115, btnWidth, 20).build());

        // Create Cape In-Game
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Cape Creator Studio"), btn -> {
            if (this.client != null) {
                this.client.setScreen(new CapeCreatorScreen(this));
            }
        }).dimensions(rightPanelX, this.height - 90, btnWidth, 20).build());

        // Import PNG / GIF from Computer
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Import PNG / GIF"), btn -> openFileDialog())
                .dimensions(rightPanelX, this.height - 65, btnWidth, 20).build());

        // Open Capes Folder
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Open Capes Folder"), btn -> {
            Util.getOperatingSystem().open(CapeManager.getInstance().getCapesDirectory().toFile());
        }).dimensions(20, this.height - 65, 130, 20).build());

        // Reload Library
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Reload"), btn -> {
            CapeManager.getInstance().loadUserFolderCapes();
            statusMessage = "Reloaded capes from folder!";
        }).dimensions(155, this.height - 65, 65, 20).build());

        // Remove Cape
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Remove Cape"), btn -> {
            CapeManager.getInstance().equipLocalCape(null);
            statusMessage = "Cape unequipped.";
        }).dimensions(rightPanelX, this.height - 40, btnWidth, 20).build());

        // Done
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), btn -> this.close())
                .dimensions(20, this.height - 40, 200, 20).build());
    }

    private void openFileDialog() {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            PointerBuffer filters = stack.mallocPointer(2);
            filters.put(stack.UTF8("*.png"));
            filters.put(stack.UTF8("*.gif"));
            filters.flip();

            String path = TinyFileDialogs.tinyfd_openFileDialog(
                    "Select Custom Cape (.png or animated .gif)",
                    "",
                    filters,
                    "Image Files (*.png, *.gif)",
                    false
            );

            if (path != null) {
                File file = new File(path);
                CapeEntry imported = CapeManager.getInstance().importExternalFile(file);
                CapeManager.getInstance().equipLocalCape(imported);
                selectedIndex = CapeManager.getInstance().getLibrary().indexOf(imported);
                statusMessage = "Imported & Equipped: " + imported.getDisplayName();
            }
        } catch (Exception e) {
            statusMessage = "Import failed: " + e.getMessage();
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        List<CapeEntry> capes = CapeManager.getInstance().getLibrary();
        int listX = 20;
        int listY = 45;
        int listW = 200;
        int rowH = 22;
        int visibleRows = Math.max(1, (this.height - 120) / rowH);

        if (mouseX >= listX && mouseX <= listX + listW && mouseY >= listY && mouseY <= listY + visibleRows * rowH) {
            int clickedRow = (int) ((mouseY - listY) / rowH) + scrollOffset;
            if (clickedRow >= 0 && clickedRow < capes.size()) {
                selectedIndex = clickedRow;
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        List<CapeEntry> capes = CapeManager.getInstance().getLibrary();
        int rowH = 22;
        int visibleRows = Math.max(1, (this.height - 120) / rowH);
        int maxScroll = Math.max(0, capes.size() - visibleRows);
        scrollOffset = Math.max(0, Math.min(maxScroll, scrollOffset - (int) Math.signum(verticalAmount)));
        return true;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        super.render(context, mouseX, mouseY, delta);

        // Header
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 14, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(statusMessage), this.width / 2, 28, 0x55FF55);

        // Left Library List
        List<CapeEntry> capes = CapeManager.getInstance().getLibrary();
        int listX = 20;
        int listY = 45;
        int listW = 200;
        int rowH = 22;
        int visibleRows = Math.max(1, (this.height - 120) / rowH);

        context.fill(listX - 2, listY - 2, listX + listW + 2, listY + visibleRows * rowH + 2, 0x88000000);

        for (int i = 0; i < visibleRows && (i + scrollOffset) < capes.size(); i++) {
            int idx = i + scrollOffset;
            CapeEntry entry = capes.get(idx);
            int y = listY + i * rowH;

            boolean isSelected = (idx == selectedIndex);
            boolean isEquipped = entry.getId().equals(CapeManager.getInstance().getSelectedCapeId());

            int bgColor = isSelected ? 0xAA3B82F6 : (i % 2 == 0 ? 0x44222222 : 0x44111111);
            context.fill(listX, y, listX + listW, y + rowH - 1, bgColor);

            String tag = entry.isAnimated() ? " [ANIM]" : "";
            String equippedStar = isEquipped ? "★ " : "";
            context.drawTextWithShadow(this.textRenderer, equippedStar + entry.getDisplayName() + tag, listX + 6, y + 6, isEquipped ? 0xFFFF55 : 0xFFFFFF);
        }

        // Right Cape Preview Box
        int previewX = this.width / 2 + 45;
        int previewY = 55;
        int capeW = 90;
        int capeH = 144;

        context.fill(previewX - 8, previewY - 8, previewX + capeW + 8, previewY + capeH + 24, 0x99111111);

        if (!capes.isEmpty() && selectedIndex >= 0 && selectedIndex < capes.size()) {
            CapeEntry current = capes.get(selectedIndex);
            Identifier tex = current.getCurrentFrameTexture();
            if (tex != null) {
                // Draw front face of cape UV (u=1, v=1, w=10, h=16 on 64x32 texture)
                context.drawTexture(tex, previewX, previewY, capeW, capeH, 1.0f, 1.0f, 10, 16, 64, 32);
            }
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(current.getCategory()), previewX + capeW / 2, previewY + capeH + 8, 0xAAAAAA);
        }
    }
}
