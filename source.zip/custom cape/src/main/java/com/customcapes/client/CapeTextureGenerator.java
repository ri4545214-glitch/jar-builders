package com.customcapes.client;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class CapeTextureGenerator {

    /**
     * Generates a valid 64x32 Minecraft Cape UV texture.
     * Front face: x=[1..10], y=[1..16] (10x16)
     * Back face:  x=[12..21], y=[1..16] (10x16)
     */
    public static BufferedImage generateStaticCape(int primaryArgb, int accentArgb, String pattern) {
        BufferedImage img = new BufferedImage(64, 32, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();

        Color primary = new Color(primaryArgb, true);
        Color accent = new Color(accentArgb, true);

        // Fill cape UV block (0,0 to 22,17)
        g.setColor(primary);
        g.fillRect(0, 0, 22, 17);

        // Draw pattern onto front (1,1) and back (12,1) faces
        drawPatternOnFace(g, 1, 1, primary, accent, pattern);
        drawPatternOnFace(g, 12, 1, primary, accent, pattern);

        g.dispose();
        return img;
    }

    private static void drawPatternOnFace(Graphics2D g, int ox, int oy, Color primary, Color accent, String pattern) {
        g.setColor(accent);
        switch (pattern) {
            case "crest" -> {
                g.drawRect(ox, oy, 9, 15);
                g.fillRect(ox + 3, oy + 4, 4, 6);
                g.fillRect(ox + 4, oy + 3, 2, 8);
            }
            case "eyes" -> {
                g.fillRect(ox + 1, oy + 6, 3, 1);
                g.fillRect(ox + 6, oy + 6, 3, 1);
                g.setColor(Color.WHITE);
                g.fillRect(ox + 2, oy + 6, 1, 1);
                g.fillRect(ox + 7, oy + 6, 1, 1);
            }
            case "creeper" -> {
                g.fillRect(ox + 2, oy + 4, 2, 2);
                g.fillRect(ox + 6, oy + 4, 2, 2);
                g.fillRect(ox + 4, oy + 6, 2, 3);
                g.fillRect(ox + 3, oy + 7, 4, 3);
                g.fillRect(ox + 3, oy + 10, 1, 2);
                g.fillRect(ox + 6, oy + 10, 1, 2);
            }
            case "border" -> {
                g.drawRect(ox, oy, 9, 15);
                g.fillRect(ox + 4, oy + 2, 2, 12);
                g.fillRect(ox + 2, oy + 6, 6, 2);
            }
            case "stripes" -> {
                for (int y = 0; y < 16; y += 3) {
                    g.fillRect(ox, oy + y, 10, 1);
                }
            }
        }
    }

    public static BufferedImage generateAnimatedCapeSheet(String theme, int frameCount) {
        BufferedImage sheet = new BufferedImage(64, 32 * frameCount, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = sheet.createGraphics();

        for (int f = 0; f < frameCount; f++) {
            int yOff = f * 32;
            float phase = (float) f / frameCount;

            for (int y = 0; y < 17; y++) {
                for (int x = 0; x < 22; x++) {
                    Color c = computeAnimatedPixel(theme, x, y, phase);
                    g.setColor(c);
                    g.fillRect(x, yOff + y, 1, 1);
                }
            }
        }
        g.dispose();
        return sheet;
    }

    private static Color computeAnimatedPixel(String theme, int x, int y, float phase) {
        return switch (theme) {
            case "galaxy" -> {
                float wave = (float) Math.sin((x * 0.4) + (y * 0.3) + phase * Math.PI * 2);
                int r = (int) (45 + 55 * (wave * 0.5f + 0.5f));
                int g = (int) (15 + 25 * (wave * 0.5f + 0.5f));
                int b = (int) (110 + 120 * (wave * 0.5f + 0.5f));
                boolean star = ((x * 7 + y * 13 + (int) (phase * 8)) % 29 == 0);
                yield star ? new Color(255, 255, 240) : new Color(r, g, b);
            }
            case "flame" -> {
                float heat = ((16 - y) / 16.0f) + 0.25f * (float) Math.sin(x * 0.8 + phase * Math.PI * 2);
                heat = Math.max(0f, Math.min(1f, heat));
                int r = Math.min(255, (int) (140 + heat * 115));
                int g = Math.min(255, (int) (heat * heat * 230));
                int b = (int) (heat > 0.85f ? 120 : 10);
                yield new Color(r, g, b);
            }
            case "rgb" -> {
                float hue = (phase + (x + y) * 0.04f) % 1.0f;
                yield Color.getHSBColor(hue, 0.85f, 0.95f);
            }
            default -> { // ocean
                float wave = (float) Math.sin((y * 0.5) - phase * Math.PI * 2 + Math.cos(x * 0.4));
                int r = (int) (10 + 30 * (wave * 0.5f + 0.5f));
                int g = (int) (100 + 110 * (wave * 0.5f + 0.5f));
                int b = (int) (180 + 75 * (wave * 0.5f + 0.5f));
                yield new Color(r, g, b);
            }
        };
    }
}
