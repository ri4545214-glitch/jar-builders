package com.customcapes;

import com.customcapes.network.CapeSyncPayload;
import com.customcapes.network.ServerCapeStorage;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.UUID;

public class CustomCapesMod implements ModInitializer {
    public static final String MOD_ID = "customcapes";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing CustomCapes for Minecraft 1.21.11 (MJ Launcher & Multiplayer Ready)");

        // Register custom networking payloads (Client <-> Server)
        PayloadTypeRegistry.playC2S().register(CapeSyncPayload.ID, CapeSyncPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(CapeSyncPayload.ID, CapeSyncPayload.CODEC);

        // Handle incoming cape updates from players
        ServerPlayNetworking.registerGlobalReceiver(CapeSyncPayload.ID, (payload, context) -> {
            ServerPlayerEntity sender = context.player();
            context.server().execute(() -> {
                // Validate payload size (max 512 KB to protect server memory)
                if (payload.pngData().length > 524288) {
                    LOGGER.warn("Player {} sent an oversized cape ({} bytes), rejected.", sender.getName().getString(), payload.pngData().length);
                    return;
                }

                CapeSyncPayload validatedPayload = new CapeSyncPayload(
                        sender.getUuid(),
                        payload.capeName(),
                        payload.animated(),
                        payload.frameCount(),
                        payload.frameDelayMs(),
                        payload.pngData()
                );

                ServerCapeStorage.setPlayerCape(sender.getUuid(), validatedPayload);

                // Broadcast to all connected players
                for (ServerPlayerEntity target : context.server().getPlayerManager().getPlayerList()) {
                    ServerPlayNetworking.send(target, validatedPayload);
                }
            });
        });

        // Send all existing player capes to a newly joined player
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity joiningPlayer = handler.getPlayer();
            for (Map.Entry<UUID, CapeSyncPayload> entry : ServerCapeStorage.getAllCapes().entrySet()) {
                ServerPlayNetworking.send(joiningPlayer, entry.getValue());
            }
        });

        // Clean up player cape cache on disconnect
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerCapeStorage.removePlayerCape(handler.getPlayer().getUuid());
        });
    }
}
