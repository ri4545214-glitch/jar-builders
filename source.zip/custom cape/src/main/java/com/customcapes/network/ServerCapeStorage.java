package com.customcapes.network;

import java.util.Collections;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ServerCapeStorage {
    private static final Map<UUID, CapeSyncPayload> ACTIVE_CAPES = new ConcurrentHashMap<>();

    public static void setPlayerCape(UUID uuid, CapeSyncPayload payload) {
        if (payload.pngData() == null || payload.pngData().length == 0) {
            ACTIVE_CAPES.remove(uuid);
        } else {
            ACTIVE_CAPES.put(uuid, payload);
        }
    }

    public static void removePlayerCape(UUID uuid) {
        ACTIVE_CAPES.remove(uuid);
    }

    public static Map<UUID, CapeSyncPayload> getAllCapes() {
        return Collections.unmodifiableMap(ACTIVE_CAPES);
    }
}
